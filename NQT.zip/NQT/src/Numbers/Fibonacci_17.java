package Numbers;

import java.util.*;

class Fibonacci_17 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		//Fibonacci series = 0, 1, (0+1=1), (1+1=2), (1+2=3), (2+3=5), (3+5=8)
		int a = 0;
		int b = 1;
		int k = 0;
		while(n >= 0) { // 5 > 0 //4 > 0 //3 > 0 //2 > 0 // 1 > 0 //0>=0 //-1>=0
			
			System.out.print(a+ " "); //0 //1  //2 //3 //4 //5
			                       //0 //1  //1 //2 //3 //5 ==>Output
			k = a; //0 //1 //1 //2 //3 //5
			a = b;//1 //1 //2 //3 //5 //8
			b = k+b; //0+1=1 //1+1=2 //1+2=3 //2+3=5 //3+5=8 //5+8=13
			
			
			n -= 1; //5-1=4 //4-1 =3 //3-1=2 //2-1=1 //1-1=0 //0-1=-1
		}
		
		
		
		
		sc.close();
	}
}