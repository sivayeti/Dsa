package Numbers;

import java.util.*;

class NumasSumof2Prime_33 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		//prime numbers are odd numbers,
		
		//Let's print the range of prime numbers
		//solution 1:
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for(int i = 2; i < n; i++) {
			boolean res = true;
			for(int j = 2; j < i; j++) {
				if(i % j == 0 && i != j) {
					res = false;
					break;
				}
			}
			if(res == true) {
				a.add(i);
			}
		}
		
		System.out.println(a);
		
		
		//let's add the each pair of two digits and check their sum equals to the input number,if matches returns true and break the loops, if it not matches then make it is false(not represent as sum of two primes)
		boolean val = false;
		for(int i = 0; i < a.size(); i++) {
			for(int j = i; j < a.size(); j++) {
				System.out.println(a.get(i) + " " + a.get(j) + " = " + (a.get(i) + a.get(j)));
				if(a.get(i) + a.get(j) == n) {
					val = true;
					break;
				}
			}
			if(val == true) {
				break;
			}
		}
		
		System.out.println(val);
		
		
		//solution 2:
		/*
		boolean ans = false;
		if(n == 2 || n == 3 || n == 4) {
			ans = false;
		}else if(n == 5) {
			ans = true;
		}else if( n % 2 == 0) {
			ans = true;
		}
		
		System.out.println(ans);
		*/
		sc.close();
	}
}