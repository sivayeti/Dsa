package Numbers;

import java.util.*;

class RangeSum_29 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int l = sc.nextInt();
		int r = sc.nextInt();
		
		int sum = 0;
		
		for(int i = l; i <= r; i++) {
			sum += i;
		}
		
		System.out.println(sum);
		sc.close();
	}
}