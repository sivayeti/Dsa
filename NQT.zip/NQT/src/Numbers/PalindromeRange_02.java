package Numbers;

import java.util.*;

class PalindromeRange_02 {
	public static void palin(int i) {
		int original = i;
		int reversed = 0;
		int q = 0;
		while(i > 0) { //23 > 0 // 2 > 0
			q = i % 10; //3 //2
			reversed = reversed * 10  + q; //0 + 3 // 30 + 2
			i = i / 10; //2 //0
		}
		
		if(original == reversed) {
				System.out.print(original + " ");
		}
		
		
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int min = sc.nextInt();
		int max = sc.nextInt();
		for(int i = min; i <= max; i++) {
			palin(i);
		}
		sc.close();
	}
}