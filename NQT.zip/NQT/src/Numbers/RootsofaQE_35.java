package Numbers;

import java.util.*;

class RootsofaQE_35 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int d = (b * b) - (4 * a * c);
		int r1 = 0;
		int r2 = 0;
		double i1 = 0;
		//double i2 = 0;
		
		if(d > 0) {
			System.out.println("Roots are real and different");
			r1 = (-b + (int) Math.sqrt(d)) / (2 * a);
			r2 =  (-b - (int) Math.sqrt(d)) / (2 * a);
			System.out.println(r1 + " "+ r2);
		}else if(d == 0) {
			System.out.println("Roots are real and equal");
			r1 = (-b + (int) Math.sqrt(d)) / (2 * a);
			r2 =  (-b - (int) Math.sqrt(d)) / (2 * a);
			System.out.println(r1+ " " + r2);
		}else {
			System.out.println("Roots are complex");
			i1 = (double) Math.sqrt(-1 * d);
			System.out.println( -(float)b/2*a  + "+" + "i" + i1);
			System.out.println( -(double)b/2*a + "-" + "i" + i1);
		}
		sc.close();
	}
}