package Numbers;

import java.util.*;

class LeapYear_14 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//Leap year comes every 4 years once
		//2000, 2004, 2008, 2012, 2016, 2020, 2024, 2028, 2032, 2036, 2040, 2044, and 2048
		int year = sc.nextInt();
		
		/*
		 The year is multiple of 400.
         The year is a multiple of 4 and not a multiple of 100.
		 */
		
		if(year % 400 == 0) {
			System.out.println("Leap Year");
		}else if(year % 4 == 0 && year % 100 != 0) { //1900
			System.out.println("Leap Year");
		}else {
			System.out.println("Not a leap year");
		}
		
		
		sc.close();
	}
}