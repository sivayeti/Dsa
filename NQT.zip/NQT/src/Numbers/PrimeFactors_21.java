package Numbers;

import java.util.*;
    
class PrimeFactors_21 {
	public static void primeFac(int k, int n) { //2,6 //3,6  //2,4
		
    	if( k == 2 || k == 3) {
    	    System.out.print(k+ " ");
    	}else {
    		boolean res = true;
    		for(int i = 2; i < k; i ++) {
    			if(k % i == 0) {
    				res = false;
    				break;
    			}
    		}
    		if(res == true) {
    			System.out.print(k+ " ");
    		}
    	}
    }
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(); //6 //4
		for(int i = 2; i < n; i++) { //2,3,4,5 //2
			if(n % i == 0) {//2,3, //2
				primeFac(i, n);
			}
		}
		sc.close();
	}
}