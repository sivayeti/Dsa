package Numbers;

import java.util.*;

class ArmStrong_05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arm = 0;
		//counting the digits
		int c = 0;
		int q = n;
		int r = 0;
		while(q > 0) { //153 //15 //1
			r = q % 10; // 3 //5  //1
			c += 1;     //1  //2  //3
			q = q / 10; //15 //1  //0
		}
		
		r = 0;
		q = n;
		while( q > 0) { //153 //15 //1 
			r = q % 10; //3 //5 //1
			arm = (int) (arm  + Math.pow(r, c)); //3^3 = 27 //5^3 = 125 //1^3 = 1
			q = q / 10; //15 //1 //0
		}
		if(arm == n) {
			System.out.println("Armstrong Number");
		}else {
			System.out.println("Not an armstrong number");
		}
        sc.close();
	}
}