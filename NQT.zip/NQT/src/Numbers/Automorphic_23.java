package Numbers;

import java.util.*;

class Automorphic_23 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		String s = Integer.toString(n);
		int l = s.length(); // l = 2 > 0
		
		int res = n * n; //5776 = 76 * 76
		//These code is good ,but it will only works for non zero digited numbers, it will gives wrong output for 540 numbers even it is automorphic
		/*
		int val = 0;
		int r = 0;
		int k = 0;
		while(l > 0) { //2  //1 > 0
			r = res % 10; // 6 //7
			res = res / 10; //577 //57
			//val = val * 10 + r; //0 * 10 + 6 //60+7
			val = val + r * (int)Math.pow(10, k); // 6* 10^0 = 6, // 6 + 7 * 10 ^ 1 = 76
			k += 1; // 1 //2
			l -= 1; //1 //0
			
		}
		
		if(n == val) {
			System.out.println("Automorphic");
		}else {
			System.out.println("Not Automorphic");
		}
		
		*/
		
		int val = 0;
		int r = 0;
		//int z = l;
		ArrayList<Integer> a = new ArrayList<>();
		while( l > 0) { //2 //1
			r = res % 10; //6 //7
			res = res / 10; //577 //57
			a.add(r); //6 //7
			l -= 1;//1 //0
		}
		
		System.out.println(a);
		for(int i = a.size()-1; i >= 0; i--) {
			val = val * 10 + a.get(i); // 7 // 70 + 6, 
		}
		
		if(val == n) {
			System.out.println("Automorphic");
		}else {
			System.out.println("Not Automorphic");
		}
		
		//Note: Let's solve these problem in other websites
		sc.close();
	}
}