package Numbers;

import java.util.*;

class Abundant_27 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int sum = 0;
		
		//Every number has its divisors & factors upto its half of its value
		for(int i = 1; i <= n/2; i++) {
			if(n % i == 0) {
				sum += i;
			}
		}
		
		if(sum > n) {
			System.out.println("Abundant Number");
		}else {
			System.out.println("Not Abundant Number");
		}
		sc.close();
		//Abundant Number : the sum of the divisors of a number is greater than original number
		//Strong Number: the sum of the factorials of each digit of a number is equal to the original number
		//Automorphic number: the squared number result should contain the original number at its end part
		//Harshad Number: the original number should divided by all sum of its digits.
		//Armstrong Number: the each digit of original number power to the length of the number , and sum of all the values equal to original number
	}
}