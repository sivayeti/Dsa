package Numbers;

import java.util.*;

class Great2_12 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		float a = sc.nextFloat();
		float b = sc.nextFloat();
		float maxi = 0;
		if(a > b) {
			maxi = a;
		}else {
			maxi = b;
		}
		
		System.out.println(maxi);
		sc.close();
	}
}