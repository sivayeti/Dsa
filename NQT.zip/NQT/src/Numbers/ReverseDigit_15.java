package Numbers;

import java.util.*;

class ReverseDigit_15 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 int a = sc.nextInt();
		 int q = a;
		 int r = 0;
		 int res = 0;
		 //String s = Integer.toString(a);
		 //int l = s.length(); //3
		 while(q > 0) { //153 //15 > 0 //1 > 0 
			 r = q % 10; //3 //5 //1
			 q = q /10;  //15 //1 //0
			 res = res * 10 + r; // 0+3 //30+5 //350+1
			 //res = res + r * (int)Math.pow(10, l-1);
			 //l -= 1; //3->2 //2->1 //1->0
		 }
		 
		 System.out.println(res);
		 sc.close();
	}
}