package Numbers;

import java.text.DecimalFormat;
import java.util.*;

class AreaofCircle_34 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int r = sc.nextInt();
		//double k = (double) 22/7; //3.142
		double k = 3.14;
		//System.out.println(k);
		double area =  (k * r * r);
		//System.out.println(area);
		//Math.round() : function removes all decimal values
		/*
		System.out.println(area);
		double val = Math.round(area * 10) ; //round(785.7) = 786
		System.out.println(val);
		val = val / 10;
		System.out.println(val);
		*/
		
		//area = String.format("%.1f", area);
		/*
		DecimalFormat df = new DecimalFormat("#.#");  // Format for one decimal place
        System.out.println(df.format(area));  // Output: 12.3
        */
		
		System.out.println(area);
		DecimalFormat df = new DecimalFormat("#.#");  // Format for one decimal place
        System.out.println(df.format(area));  // Output: 12.3
        
        /*
         * import java.text.DecimalFormat;
         * DecimalFormat df = new DecimalFormat("#.#");
         * df.format(area);
         */
		sc.close();
		
	}
}