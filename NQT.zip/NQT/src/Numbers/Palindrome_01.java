package Numbers;

import java.util.*;

class Palindrome_01 {
	public static void palin(int n) {
		/*
		//counting digits
		int q = n;
		int r = 0;
		int c = 0;
		
		while(q > 0) {
			//153 > 0 //15 > 0 //1 > 0
			r = q % 10;  //3 // 5  //1
			c += 1;      //1 //2   //3
			
			q = q / 10;  //15 // 1
		}
		
		//check palindrome
		q = n;
		r = 0;
		int res = 0;
		while(q > 0) { //153 > 0 //15 > 0 //1 > 0
			//153
			r = q % 10; //3  //5 //1
			q = q / 10; //15 //1 //0
			res = (int) (res + r * (Math.pow(10, c-1))); // 300 + 50 + 1
			c -= 1; //2 //1
		}
		
		if(res == n) {
			System.out.println("Palindrome");
		}else {
			System.out.println("Not palindrome");
		}
		*/
		
		int reversed = 0;
		int original = n;
		int r = 0;
		while(n > 0) { //153 > 0 //15 > 0 //1 > 0
			r = n % 10; //3 // 5 //1
		    reversed = reversed * 10 + r; // 0 + 3 // 30 + 5 //350 + 1
		    n = n / 10; //15 //1 //0
		}
		
		if(original == reversed) {
			System.out.println("palindrome");
		}else {
			System.out.println("Not palindrome");
		}
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		palin(n);
		sc.close();
	}
}