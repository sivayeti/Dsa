package Numbers;

import java.util.*;

class Factorial_18{
	
	//recursion approach
	public static Integer recursion(int n) {
		
		if(n == 0) {
			return 1;
		}else {
			return n * recursion(n-1); //5 * (4) 
			                           //     4 * (3)
			                           //          3 * (2) 
			                           //               2 * (1)
			                           //                    1 * (0)
			                           //                         1
		}
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int res = 1;
		
		//iterative approach
		/*
		for(int i = n; i >=1 ; i--) {
			res = res * i; //5 *4*3*2*1
			//System.out.println(i);
			//System.out.println(res);
		}*/
		res = recursion(n); 
		System.out.println(res);
		sc.close();
	}
}