package Numbers;

import java.util.*;

class FractionSum_31 {
	public static int gcd(int d1, int d2) {
		int div = d1;
		int dd = d2;
		int r = 1;
		
		while(r != 0) { //3 != 0 //1 != 0 //0 != 0 (0 == 0)
			r = dd % div; // 7 % 4 == 3  // 4 % 3 == 1 //3 % 1 == 0
			dd = div; //4 //3 //1  => here these 1 is our gcd
			div = r; //3 //1  //0
		}
		
		return dd;
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num1 = sc.nextInt();
		int den1 = sc.nextInt();
		
		int num2 = sc.nextInt();
		int den2 = sc.nextInt();
		
		//findout the l.c.m for denominators;
		// l.c.m = a * b / h.c.f
		int hcf = gcd(den1, den2);
		
		int lcm = (den1 * den2) / hcf;
		
		int re1 = lcm / den1;
		int re2 = lcm / den2;
		
		num1 = num1 * re1;
		num2 = num2 * re2;
		
		int num = num1 + num2;
		//To Convery it into simplest form, divide the numerator and denominator both by gcd of den1,den2;
		num = num / hcf;
		lcm = lcm / hcf;
		System.out.println(num + "/"+ lcm);
		sc.close();
	}
}