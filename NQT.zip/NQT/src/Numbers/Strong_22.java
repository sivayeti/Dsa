package Numbers;

import java.util.*;

class Strong_22 {
	//factorial calc for each digit
	public static Integer fact(int r) {
		int a = 1;
		for(int i = 1; i <= r; i++) {
			a *= i;
		}
		return a;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int q = n;
		int r = 0;
		int ans = 0;
		//extraction of digits
		while(q > 0) { //153
			r = q % 10; //3
			q = q / 10; //15
			
			ans += fact(r); //summing factorial value for each digit
		}
		
		System.out.println(ans);
		
		if(ans == n) {
			System.out.println("Strong Number");
		}else {
			System.out.println("Not Strong Number");
		}
		sc.close();
	}
}