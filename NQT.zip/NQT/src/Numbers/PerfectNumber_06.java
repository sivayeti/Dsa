package Numbers;

import java.util.*;

class PerfectNumber_06 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		//any number has divisors upto its half of the value apart from itself
		int sum = 0;
		for(int i = 1; i <= n/2; i++) {
			if(n%i == 0) {
				sum += i;
			}
		}
		
		if(sum == n) {
			System.out.println("Perfect number");
		}else {
			System.out.println("Not a perfect number");
		}
		//System.out.println(n/2); //even/2 , odd-1/2
		sc.close();
		
	}
}