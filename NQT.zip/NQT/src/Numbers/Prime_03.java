package Numbers;

import java.util.*;

class Prime_03 {
	public static void isPrime(int n) {
		int r = 0;
		boolean res = true;
		for(int i = 2; i < n; i++) {
			r = n % i;
			if(r == 0 && i != n ) {
				res = false;
				break;
			}
		}
		if(res == false) {
			System.out.println("No");
		}else {
			System.out.println("Yes");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(); //2, 3, 4
		//prime it should divide by 1 and itself, if it divided by any other number then it is not prime.
		
		
		//nboolean res = true;
		//if ( n == 2 || n == 3){
		 //    System.out.println("prime");
		//}else {
		if( n == 1) {
			System.out.println("No");
		}else {
		    isPrime(n);
		}
	//	}
		
		
		
		sc.close();
	}
}