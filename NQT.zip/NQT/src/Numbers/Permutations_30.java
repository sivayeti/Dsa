package Numbers;

import java.util.*;

class Permutations_30{
	public static int fact(int v) {
		int ans = 1;
		for(int i = 1; i <= v; i++) {
			ans = ans * i;
		}
		return ans;
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//n people can occupy r seats
		//permutations: n! / (n-r)!
		int n = sc.nextInt();
		int r = sc.nextInt();
		
		int q = fact(n);
		int re = fact(n-r);
		int perm = q / re;
		
		System.out.println(perm);
		sc.close();
	}
}