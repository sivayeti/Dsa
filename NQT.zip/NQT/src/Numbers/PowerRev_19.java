package Numbers;

import java.util.*;

class PowerRev_19 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int rev = 0;
		int q = n;
		int r = 0;
		while(q > 0) { //153 //15 //1
			r = q % 10; //3 //5 //1
			q = q / 10; //15 //1 //0
			rev = rev * 10 + r; //3 //30+5 //350+1
		}
		
	    // ans = (int)Math.pow(n, rev); //these will not generate the accurate result
		int mod = 1000000007;
		long ans = 1;
		for(int i = 1; i <= rev; i++) {
			ans *= n;	
			ans %= mod;
		}
		
		System.out.println(rev);
		System.out.println(ans);
		//System.out.println(ans % 1000000007);
		
		sc.close();
	}
}