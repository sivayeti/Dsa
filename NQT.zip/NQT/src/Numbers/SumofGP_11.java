package Numbers;

import java.util.*;

class SumofGP_11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//a = first term
		//r = common ratio
		//n = no.of terms
		//sum = a + ar^1 + ar^2 + ar^3 + .......+ar^n-1
		float a = sc.nextFloat();
		float r = sc.nextFloat();
		int n = sc.nextInt();
		//float a1 = 0;
		float sum = 0;
		/*
		for(int i = 0; i < n; i++) {
			a1 = (float) (a *  Math.pow(r, i));
			System.out.println(a1);
			sum = sum + a1;
		}
		*/
		
		/*
		 Sum of GP = (a(r^n -1)) / (r-1);
		 */
		
		sum = (a*(float)(Math.pow(r, n)-1))/(r-1);
		System.out.println(sum);
		sc.close();
	}
}