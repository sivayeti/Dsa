package Numbers;

import java.util.*;

class Replace0with1s_32 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		//solution 1;
		
		String s = Integer.toString(n); //conversion of Integer to String
		String r = "";
		for(int i = 0; i < s.length(); i++) {
			if(s.charAt(i) == '0') {
				r += '1';
			}else {
				r += s.charAt(i);
			}
		}
		int val = Integer.parseInt(r); //Conversion of String into Integer
		
		System.out.println(val);
		
		
		
		//Solution 2:
		/*
		int q = n;
		int r = 0;
		int ans = 0;
		while(q > 0) { //204  //20 //2
			r = q % 10; //4 //0 //2
			if(r != 0) {
			ans = ans * 10 + r; //4 //41*10 + 2;
			}
			if(r == 0) {
				ans = ans * 10 + 1; //41
			}
			q = q / 10; //20 //2 //0
			
		}
		System.out.println(ans);
		
		//412
		q = ans; //412
		r = 0;
		int val = 0;
		while(q > 0) { //412 //41 //4
			r = q % 10; // 2 //1 //4
			val = val * 10 + r;//2 //20+1 //210 + 4
			q = q / 10; //41 //4 //0
		}
		System.out.println(val);
		*/
		sc.close();
		
	}
}