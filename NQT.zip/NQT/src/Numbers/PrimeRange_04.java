package Numbers;

import java.util.*;

class PrimeRange_04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int min = sc.nextInt();
		int max = sc.nextInt();
		
		for(int i = min; i <= max; i++) {
			if(i == 1) {
				System.out.println("No");
			}else {
				boolean res = true;
				int r = 0;
				for(int j = 2; j < i; j++) {
					 r = i % j;
					 if(r == 0 && i != j ) {
						 res = false;
						 break;
					 }
					 
					 
				}
				if(res == true) {
					System.out.print(i + " ");
				}
				
			}
			
		}
		
		sc.close();
	}
}