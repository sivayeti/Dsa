package Numbers;

import java.util.*;

class SumofAP_10 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//a = first term of AP (2)
		//d = common difference of AP (2)
		//n = Number of Terms in AP (4)
		//AP Series = 2,4,6,8 
		//Sum = 2+4+6+8 = 20
		
		
		int a = sc.nextInt();
		int d = sc.nextInt();
		int n = sc.nextInt();
		int sum = 0;
		/*
		for(int i = 0; i < n; i++ ) {
			sum = sum + a; //i = 0 // sum = 2 //i = 1 //sum = 2+4=6 //i=2 //sum=2+4+6=12 //i=3 //sum=2+4+6+8=20
			a = a + d; // a0=2 //a1=2+2=4  //a2 =4+2=6 //a3=6+2=8 (require upto these terms)   //a4=8+2=10
		}
		*/
		
		/*
		 sum of AP = (n/2)*((2*a)+((n-1)*d));
		 */
		
		sum = (n/2)*((2*a)+((n-1)*d));
		System.out.println(sum);
		
		sc.close();
	}
}