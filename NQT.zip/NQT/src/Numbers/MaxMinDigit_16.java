package Numbers;

import java.util.*;

class MaxMinDigit_16 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		int maxi = 0;
		int r = 0;
		int q = n;
		int mini = 10;
		while(q > 0) { //153
			r = q % 10; //3
			q = q / 10; //15
			maxi = Math.max(maxi, r); //(0,3), (3,5), (5,1) => 5,
			mini = Math.min(mini, r); //(10,3), (3,5), (3,1)  => 1
		}
		
		System.out.println(maxi);
		System.out.println(mini);
		sc.close();
	}
}