package Numbers;

import java.util.*;

class Great3_13 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//float a = sc.nextFloat();
		//float b = sc.nextFloat();
		//float c = sc.nextFloat();
		//float maxi = 0;
		double a = sc.nextDouble();
		double b = sc.nextDouble();
		double c = sc.nextDouble();
		double maxi = 0;
		if( a > b && a > c) {
			maxi = a;
		}else if(b > a && b > c) {
			maxi = b;
		}else {
			maxi = c;
		}
		
		System.out.println(maxi);
		sc.close();
	}
}