package Numbers;

import java.util.*;

class SumDigits_28 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		int q = n;
		int r = 0;
		int ans = 0;
		while(q > 0) { //153 //15 //1
			r = q % 10; //3 //5 //1
			q = q / 10; //15 //1 //0
			ans = ans + r; //3+5+1
		}
		
		System.out.println(ans);
		sc.close();
	}
}