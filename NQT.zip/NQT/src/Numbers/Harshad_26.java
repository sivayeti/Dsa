package Numbers;

import java.util.*;

class Harshad_26 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int q = n;
		int r = 0;
		int div = 0;
		
		while(q > 0) { //378
			r = q % 10; //8 //7 //3
			q = q / 10; //37 //3 //0
			div = div + r; //0 + 8,  //8+7, //8+7+3
			
			
		}
		
		if(n % div == 0) {
			System.out.println("Harshad Number");
		}else {
			System.out.println("Not Harshad Number");
		}
		sc.close();
		
		//Strong Number: sum of the factorial value of each digit is equal to original number
		//Automorphic number: number is squared , the result end part should contain the original number
		//Harshad number: sum of the digits ,the result should divide the original number
		
	}
}