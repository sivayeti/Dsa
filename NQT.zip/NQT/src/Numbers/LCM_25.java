package Numbers;

import java.util.*;

class LCM_25 {
	public static Integer gcd(int a, int b) {
		int r = 1;
		while( r != 0) {
			 r = a % b;
			 a = b;
			 b = r;
		}
		return a;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		int lcm = 0;
		
		lcm = (a * b) / gcd(a,b);
		
		System.out.println(lcm);
		sc.close();
	}
}

/*
Methods to Find LCM
1️⃣ Prime Factorization Method
Steps:

Find the prime factors of both numbers.
Take the highest powers of all prime factors.
Multiply them to get the LCM.
Example:
Find LCM(12, 18).

Prime factors of 12 = 2 × 2 × 3
Prime factors of 18 = 2 × 3 × 3
Take highest powers: 2² × 3²
✅ LCM = 2² × 3² = 36
2️⃣ Division Method
Steps:

Write the numbers side by side.
Divide by the smallest prime number that divides at least one number.
Repeat until all numbers become 1.
Multiply all divisors to get LCM.
Example:
Find LCM(12, 18) using the division method.

2	12	18
2	6	9
3	3	9
3	1	3
1	1
✅ LCM = 2 × 2 × 3 × 3 = 36

3️⃣ Using GCD (Efficient Method)
Formula:

𝐿
𝐶
𝑀
(
𝑎
,
𝑏
)
=
𝑎
×
𝑏
𝐺
𝐶
𝐷
(
𝑎
,
𝑏
)
LCM(a,b)= 

a×b / GCD(a,b)

​
 
Steps:

Find GCD(a, b) using the Euclidean method.
Use the formula to compute LCM.
Example:
Find LCM(12, 18).

GCD(12, 18) = 6
LCM(12, 18) = (12 × 18) / 6 = 216 / 6 = 36 ✅


🔹 Summary of Methods
Method	Best For	Complexity
Prime Factorization	Small numbers	O(log N)
Division Method	Step-by-step breakdown	O(log N)
GCD Formula	Fastest & efficient for large numbers	O(log N)
*/