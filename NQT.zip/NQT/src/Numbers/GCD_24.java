package Numbers;

import java.util.*;

class GCD_24{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int r = 1;
		while( r != 0) { //r == 0;
			r = a % b; //48 % 18 == 12, //18 % 12 == 6 //12 % 6 == 0
			a = b; //18 //12 //6
			b = r; //12 //6  //0
		}
		
		System.out.println("GCD:" + a);
		sc.close();
	}
}

/*
General Methods to Find GCD
1️⃣ Prime Factorization Method
Steps:

Find the prime factors of both numbers.
Identify the common factors between them.
Multiply the common factors to get the GCD.
Example:
Find GCD of 36 and 48.

Prime factors of 36 = 2 × 2 × 3 × 3
Prime factors of 48 = 2 × 2 × 2 × 2 × 3
Common factors = 2 × 2 × 3 = 12
✅ GCD = 12
2️⃣ Division Method
Steps:

Divide the larger number by the smaller number.
Take the remainder.
Repeat the process using the previous divisor and the remainder.
Continue until the remainder is 0. The last divisor is the GCD.
Example:
Find GCD of 48 and 18.

48 ÷ 18 → remainder 12
18 ÷ 12 → remainder 6
12 ÷ 6 → remainder 0 ✅
✅ GCD = 6
3️⃣ Euclidean Algorithm (Efficient Method)
Steps:

If b = 0, then GCD(a, b) = a.
Otherwise, compute GCD(b, a % b) recursively.
Example (Using Euclidean Algorithm):
Find GCD of 48 and 18.

GCD(48,18) = GCD(18, 48 % 18) = GCD(18, 12)
GCD(18,12) = GCD(12, 18 % 12) = GCD(12, 6)
GCD(12,6) = GCD(6, 12 % 6) = GCD(6, 0)
✅ GCD = 6
*/