package NumberSystem;

import java.util.*;

class DectoOct_04 {
	
	//solution 1:
	/*
	public static String DectoBin(int n) {
		int arr[] = new int[32];
		String sol = "";
		int i = 0;
		while(n > 0) { //18 > 0 //9 > 0 // 4 > 0 //2 > 0 //1 > 0 //0 > 0
			arr[i] = n % 2; 
			//0 1 2 3 4 5
			//0 1 0 0 1
			i++;//1 //2 //3 //4 //5
			n = n / 2; //9 //4 //2 //1 //0
			
		}
		
		//Let's reverse the array from where it occupied
		//i = 5
		//4 3 2 1 0 ==>i
		//1 0 0 1 0
		
		for(int j = i - 1; j >= 0; j--) {
			sol += Integer.toString(arr[j]);
		}
		
		return sol;
	}
	
	public static int BintoOct(String s) {
		
		//10010
		int l = s.length(); //5
		int r = l % 3; 
		String s1 = "";
		if(r == 1) {
		   s1 += "00";	
		}else if(r == 2) {
			s1 += "0";
		}
		
		s1 += s;
		//010 010
		
		int l1 = s1.length();
		l1 /= 3; //2
		int j = 0;
		int fval = 0;
		for(int i = 0; i < l1; i++) {
			int ans = 0;
			int base = 4;
			while(j < s1.length()) {
				if(s1.charAt(j) == '1') {
					ans += base;
				}
				
				base = base / 2;
				j += 1;
				if(j == 3) {
					break;
				}
			}
			
			fval = fval * 10 + ans;
		}
		return fval;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		//function to convert decimal to binary
		String s = DectoBin(n);
		
		
		//function to convert binary into octal;
		int val = BintoOct(s);
		
		
		System.out.println(s);
		System.out.println(val);
		
		sc.close();
		*/
	
	//solution 2:
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	ArrayList<Integer> a = new ArrayList<>();
	
	
	int n = sc.nextInt();
	int r = 0;
    int val = 0;
	while( n > 0) { //136 > 0 //17 > 0 // 2 > 0 //0 > 0
		r = n % 8; //0 //1 //2
		n = n / 8; //17 //2 //0
		a.add(r); //0,1,2
		//val = val * 10 + r; 
	}
	
	for(int i = a.size()-1 ; i >= 0; i--) {
		val = val * 10 + a.get(i);
	}
	
	System.out.println(val);
	sc.close();
	}
}