package NumberSystem;

import java.util.*;

class OcttoDec_06 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int r = 0;
		int ans = 0;
		int i = 0;
		
		while(n > 0) {  //345 //34 //3 
			r = n % 10; //5 //4 //3
			n = n / 10; //34 //3 //0
			ans += r * Math.pow(8, i); //5*8^0 + 4* 8^1 +3 * 8^2
			i++; //1 //2 //3
		}
		
		System.out.println(ans);
		sc.close();
	}
}