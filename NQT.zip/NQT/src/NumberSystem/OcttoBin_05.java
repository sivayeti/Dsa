package NumberSystem;

import java.util.*;

class OcttoBin_05 {
	public static int OcttoDec(int n) {
		int val = 0;
		
		int r = 0;
		//String s = Integer.toString(n);
		
		//int l = s.length()-1; //2
		int l = 0;
		while(n > 0) { //345 //34 //3 //0
			r = n % 10; // 5 //4 //3
			n = n / 10; //34 //3 //0
			val = val + r * (int) Math.pow(8, l); //0 //1 //2
			l += 1;  //1 //2 //3
		}
		
		return val;
	}
	
	public static String DectoBin(int val) {
		int n = val;
		int i = 0;
		//int r = 0;
		String ans = "";
		int newarr[] = new int[128];
		while(n > 0) { //18 > 0 //9 > 0  //4 > 0 //2 > 0 //1 > 0 //0 > 0
			newarr[i] = n % 2; //if n is odd it stores 1 or else it stores even;
			//0 1 2 3 4 5
			//0 1 0 0 1
			n = n / 2; //9 //4 //2 //1 //0
			i++; //1 //2 //3 //4 //5
			
		}
		
		for(int j = i-1; j >= 0; j--) {
			ans += Integer.toString(newarr[j]);		
			}
		
		return ans;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//int n = sc.nextInt();
		
		/*
		ArrayList<Integer> a = new ArrayList<>();
		
		
		
		int r = 0;
		while( n > 0) { //345  //34 > 0  //3 > 0  //0 > 0
			r = n % 10; //5  //4  //3 > 0
			n = n/10; //34  //3 //0
			a.add(r); //5, //4  //3
			
		}
		
		int q = 0;
		r = 0;
		ArrayList<Integer> b= new ArrayList<>();
		for(int i = a.size()-1; i >= 0; i--) {
			r = a.get(i) % 2; //s1 //1
			q = a.get(i) / 2; //1 //0
			b.add(r); //1,1
		}
		
		String ans = 
		*/
		
		
		int n = sc.nextInt();
		
		//oct to dec:
		int val = OcttoDec(n);
		
		System.out.println(val);
		
		//dec to binary
		String ans = "";
		
		String ans1 = "";
		ans1 = DectoBin(val);
		if(ans1.length() % 3 == 1) {
			ans += "00";
		}else if(ans1.length() % 3 == 2) {
			ans += "0";
		}
		
		ans = ans + ans1;
		System.out.println(ans);
		sc.close();
	}
}