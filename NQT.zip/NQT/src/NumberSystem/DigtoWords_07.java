package NumberSystem;

import java.util.*;

class DigtoWords_07{
	private static final String[] Below_Twenty = {"", "One", "Two", "Three", "Four", "Five", "Six","Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
	                                           // 0     1      2
	private static final String[] Below_Hundred = {"", "" , "Twenty",  "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
	                                          //   0   1      2
	private static final String[] Thousand = {"", "Thousand"};
	                                       //0     1
	
	public static String numtoWords(int n) {
		if(n == 0) {
			return "Zero";
		}else if (n < 0) {
			return "Negative" + numtoWords(-n);
		}
		
		int i = 0;
		String Words = "";
		//for thousands
		while (n > 0) { //12,345    //12                                //3000
			if(n % 1000 != 0) {
				Words = helper(n % 1000) + Thousand[i] + " " + Words;
				      // <1000 //345
			}
			
			n = n / 1000; //12
			i += 1; //1
			
		}
		return Words.trim();
	}
	
	//less than 1000 
	public static String helper(int r) {
		if(r == 0) {
			return "";
		}else if(r <  20) {
			return Below_Twenty[r] + " ";
			
		}else if(r < 100) {
			return Below_Hundred[r / 10] + " "+ helper(r % 10);
		}else {
			return Below_Twenty[r / 100] + " Hundred " + helper(r % 100);
		}
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		String words = numtoWords(n);
		
		System.out.println(words);
		
		sc.close();
	}
}