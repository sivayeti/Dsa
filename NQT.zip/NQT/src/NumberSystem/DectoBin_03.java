package NumberSystem;

import java.util.*;

class DectoBin_03{
	public static void main(String[] args0) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt(); //18
		
		int[] arr = new int[32];
		int i = 0;
		while(n > 0) { //18 > 0 //9 > 0 //4 > 0 //2 > 0 //1 > 0 //0 > 0
			arr[i] = n % 2; //if n is odd it stores 1 or else 0 
			//0 1 2 3 4 5
			//0 1 0 0 1                   
			i++; //1 //2 //3 //4 //5
			n = n / 2; //9 //4 //2 //1 //0
		}
		
		//lets reverse the array from how much it is stored.
		for(int j = i - 1; j >= 0; j--) {
			//  4  3 2 1 0
			//  1  0 0 1 0
			//  16 0 0 2 0  ==> sum ==> 18
			System.out.print(arr[j]);
		}
		
		sc.close();
	}
}