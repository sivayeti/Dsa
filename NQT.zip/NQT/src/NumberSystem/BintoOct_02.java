package NumberSystem;

import java.util.*;

class BintoOct_02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine(); //1100110
		int l = s.length(); //7
          
		int r = l % 3;  //1 -> 00, 2-> 0
		String news = "";
		if(r == 1) {
			news += "00";
		}else if(r == 2) {
			news += "0";
		}
		
		news += s; //001 100 110
		
		
		int q = news.length() / 3; // 9 / 3 = 3;
		int ans = 0;
		//int v = 0;
        int j = 0;
		for(int i = 0; i < q; i++) { //1
			int base = 4;
			int val = 0;
		
		//	for(int j = v; j < news.length(); j++) {
			while( j < news.length()) {
				if(news.charAt(j) == '1') {
					val = val + base; //4 //1+ //4+
				}
				base = base / 2; //2 //1  //2
			    j =  j+1; //3; //4
				if(j % 3 == 0) {
					break;
				}
				
			}
		//	}
			ans = ans * 10 + val; //1
		}
		
		System.out.println(ans);
		
		
		
		sc.close();
	}
}