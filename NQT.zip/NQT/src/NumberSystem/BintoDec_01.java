package NumberSystem;

import java.util.*;

class BintoDec_01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		
		
		//Solution 1:
		/*
		int val = sc.nextInt();
		String s = Integer.toString(val);
		int n = 0;
		int l = s.length(); //4 //0 ,1 , 2, 3
		int q = val;
		int r = 0;
		int k = 0;
		while(q > 0) { //1011 //101 //10 //1
			r = q % 10; //1 //1 //0 //1
			q = q / 10; //101 //10 //1 //0
			n = n + r * (int) Math.pow(2, k); //0 //1 //2 //3
			//System.out.println(n + " " + r + " " + (int) Math.pow(2, k));
			k += 1; //1 //2 //3 //4
		}
		System.out.println(n);
		*/
		
		String s = sc.nextLine(); //1011
		int base = 1;
		int ans = 0;
		int l = s.length(); //4
		for(int i = l-1; i >= 0; i--) { //1 //1 //0 //1
			if(s.charAt(i) == '1') { //1 //1 //0 //1
				ans = ans + base; //1 + 2 + 0 + 
				                  //1 * 2^0 + 1 * 2^1 +0 * 2^2
			}
			base = base * 2; //1 //1 //0 //1
			                 //0 1    2    3
			//1 2 4 8
		}
		System.out.println(ans);
		sc.close();
	}
}