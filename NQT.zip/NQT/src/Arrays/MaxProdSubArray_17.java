/*
{-2,3,-4,0} 
  0 1  2 3

i=0  0--1    0-1-2    0-1-2-3
{-2} {-2,3} {-2,3,4} {-2,3,-4,0}

i=1   1--2  1--2--3
{3}  {3,-4} {3,-4,0}

i=2   2--3
{-4} {-4,0}

i=3
{0}
*/

package Arrays;
import java.util.*;
class MaxProdSubArray_17 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int maxi = 1;
		int mprod = 1;
		//int k = -1;
		for(int i = 0; i < n; i++) {
			//k += 1;
		   	for(int j = i; j < n; j++) {
		   		System.out.print("{");
		   		mprod = 1;
		   		for(int l = i; l <= j; l++) {
		   			
		   			//System.out.print("{"+l+"}"+ " ");
		   			//System.out.print(l+" ");
		   			
		   			//System.out.print(arr[l]+ " ");
		   			
		   		    mprod = mprod * arr[l];
		   		    //System.out.print(mprod);
		   		
		}
		   		System.out.print(mprod);
		   		System.out.print("}");
		   		if(mprod > maxi) {
		   			maxi = mprod; 
		   		}
		   	}
		   	System.out.println();
	}
		System.out.println("Maximum product: "+ maxi);
		sc.close();
}
}