package Arrays;

import java.util.*;

class large_02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine(); //capturing empty space after integer entry
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int ma = arr[0];
		for(int i = 0; i < n; i++) {
			if(arr[i] > ma) {
				ma = arr[i];
			}
		}
		
		System.out.println("Largest element : " + ma);
		sc.close();
	}
}