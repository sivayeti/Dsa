package Arrays;
import java.util.*;

class SecSmallLarge_03{
	
	public static Integer large(int arr[], int n) {
		int maxi = arr[0];
		for(int i = 0; i < n; i++) {
			if(arr[i] > maxi) {
				maxi = arr[i];
			}
		}
		
		return maxi;
	}
	
	public static Integer SecondLargest(int arr[],int ma, int n) {
		int sma = arr[0];
		for(int i = 0; i < n; i++) {
			if(arr[i] > sma && arr[i] != ma) {
				sma = arr[i];
			}
		}
		return sma;
	}
	
	public static Integer small(int arr[], int n) {
		int mini = arr[0];
		for(int i = 0; i < n; i++) {
			if(arr[i] < mini) {
				mini = arr[i];
			}
		}
		
		return mini;
	}
	
	public static Integer SecondSmallest(int arr[],int mi, int n) {
		int smi = arr[0];
		for(int i = 0; i < n; i++) {
			if(arr[i] < smi && arr[i] != mi) {
				smi = arr[i];
			}
		}
		return smi;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int ma = 0;
		//Large function
		ma = large(arr,n);
		
		int sma = 0;
		//SecondLargest
		sma = SecondLargest(arr, ma, n);
		System.out.println("First Largest Number : " + ma);
		System.out.println("Second Largest Number: " + sma);
		
		int mi = 0;
		//Small function
		mi  = small(arr, n);
		
		int smi = 0;
		//Second minimum
		smi = SecondSmallest(arr, mi, n);
		System.out.println("First Largest Number : " + mi);
		System.out.println("Second Largest Number: " + smi);
		sc.close();
	}
}