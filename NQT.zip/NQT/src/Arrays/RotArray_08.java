package Arrays;

import java.util.*;

class RotArray_08 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int r = sc.nextInt();  //2
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {  //1 2 3 4 5
			arr[i] = sc.nextInt();    //0 1 2 3 4
		}
		int k = 0;
		
		
		int newarr[] = new int[n];    // 0 1 2 3
		for(int i = r; i < n;i++) {   // 3 4 5 1 2
			
			                          // 2 3 4 0 1  
			                          //       0 1 --> i
			                          //       3 4 --> j = 5 - 0 - 2, 5 - 1 - 0.  
			newarr[k] = arr[i];
			k++;
		}
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i] + " ");
		}
		
		for(int i = 0; i < r; i++) {
			newarr[k] = arr[i];
			k++;
		}
		System.out.println();
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i] + " ");
		}
		sc.close();
	}
}