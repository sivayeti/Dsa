package Arrays;

import java.util.*;

class EqIndex_21 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		// 2 3 -1 8 4
		// 0 1 2  3 4
		//i = 2
		//j=0 -->1 = 2+3 => l
		//l
		//k = i+1 --> arr.length = 8 + 4 =>r
		//r
		for(int i = 0; i < n; i++) {
			int rsum = 0;
			int lsum = 0;
			for(int j = 0; j < i; j++) {
				rsum = rsum + arr[j];
			}
			
			for(int k = i+1; k < n; k++) {
				lsum = lsum + arr[k];
			}
			
			if(lsum == rsum) {
				System.out.println(i);
				System.out.println("rsum:" + rsum);
				System.out.println("lsum:" + lsum);
				break;
			}
		}
		sc.close();
	}
}