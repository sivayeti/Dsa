package Arrays;

import java.util.*;

class SortbyFreq_19 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		
		for(int i = 0; i < n; i++) {
			if(!hm.containsKey(arr[i])){
				hm.put(arr[i], 1);
			}else {
				int value = hm.get(arr[i]);
				hm.put(arr[i], value+1);
			}
		}
		
		System.out.println(hm);
		int g = hm.size();
		int[][] newarr = new int[g][2];
		
		int ii = 0;
		for(int l: hm.keySet()) {
			newarr[ii][0] = l;
			newarr[ii][1] = hm.get(l);
			ii+=1; //4
		}
		
		for(int i = 0; i < newarr.length; i++) {
			for(int j = 0; j <= 1; j++) {
			System.out.print(newarr[i][j]);
			}
		}
		
		
		Arrays.sort(newarr, (a,b) -> Integer.compare(b[1], a[1]));
		System.out.println();
		for(int i = 0; i < newarr.length; i++) {
			for(int j = 0; j <= 1; j++) {
			System.out.print(newarr[i][j]);
			}
		}
		
		System.out.println();
		for(int i = 0; i < newarr.length; i++) {
				int p = newarr[i][1];
			    for(int l = 0; l < p; l++) {
			    	System.out.print(newarr[i][0]+ " ");
			    }
		}
		
		sc.close();
		}
	}



/*
class SortbyFreq_19 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		Arrays.sort(arr);
		int newarr[][] = 
	}
}
*/