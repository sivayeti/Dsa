package Arrays;

import java.util.*;

class RotArrayD_20 {
	public static void rotRight(int[] arr, int n, int k, String dir) {
		int newarr[] = new int[n];
		//arr = 1 2 3 4 5 6 7
		//      0 1 2 3 4 5 6
		//newa  0 1 2 3 4 5 6
		//      6 7 1 2 3 4 5
		//              1 2 3
		
		//n[0] = a[7-0] = 7 -2 = 5  , k = 2
		//n[1] = a[7-1] = 6 +0 = 6
		
		// n[0] = a[7-0] = a[7 -3] = a[4] , k = 3
		// n[1] = a[7-1] = 6 -1 = 5
		// n[2] = a[7-2] = 5 +1 = 6
		
		// n[0] = a[7-0] = 7 -4 = 3 , k = 4
		// n[1] = a[7-1] = 6 -2 = 4
		// n[2] = a[7-2] = 5 +0 = 5
		// n[3] = a[7-3] = 4 +2 = 6
		int l = 0;
		for(int i = 0; i < k; i++) {
			newarr[i] = arr[n-k+l];
			l += 1;
		}
		   
		int q = k;
		for(int i = 0 ; i < n-k; i++) {
			newarr[q] = arr[i];
			q = q+1;
		}
		
		for(int i = 0; i < n; i++) {
			System.out.print(newarr[i] + " ");
		}
		
	}
	
	
	public static void rotLeft(int[] arr, int n, int k, String dir) {
		int newarr[] = new int[n];
		//arr = 0 1 2 3 4 5 6
		//      1 2 3 4 5 6 7
		//newa= 0 1 2 3 4 5 6
		//      3 4 5 6 7 1 2   k = 2
		//      4 5 6 7 1 2 3   k = 3
		
		//n[5] = a[0] 
		//n[6] = a[1] 
		
		for(int i = 0; i < k; i++) {
			newarr[n-k+i] = arr[i];
		}
		
		int g =k;     //i < 5
		for(int i = 0; i < n-k; i++) {
			newarr[i] = arr[g]; //g = 2 , g = 3, g = 4, g = 5, g = 6
			g = g + 1;
		}
		
		for(int i = 0; i < n; i++) {
			System.out.print(newarr[i]+ " ");
		}
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		String dir = sc.next();
		sc.nextLine();
		
		int k = sc.nextInt();
		
		//rotate right
		if( dir.equals("right") ) {
		rotRight(arr, n, k, dir);
		}
		
		
		//rotate left
		if(dir.equals("left")) {
		rotLeft(arr, n, k, dir);
		}
		
		sc.close();
	}
}