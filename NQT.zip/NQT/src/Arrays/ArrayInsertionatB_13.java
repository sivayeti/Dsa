package Arrays;
import java.util.*;

class ArrayInsertionatB_13 {
	public static void insertion(int[] arr, int v,int n) {
		int newarr[] = new int[n+1];
		for(int i = n-1; i >=0; i--) {
			newarr[i+1] = arr[i];
		}
		newarr[0] = v;
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i] + " ");
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
	    int arr[] = {1,2,3,4,5};
	    int n = arr.length;
		
		int v = sc.nextInt();
		//insertion at begining
		insertion(arr, v, n);
		sc.close();
	}
}
