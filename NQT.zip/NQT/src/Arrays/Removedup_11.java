package Arrays;
import java.util.*;
class Removedup_11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> Remdup = new HashMap<>();
		for(int i = 0; i < n; i++) {
			if(Remdup.containsKey(arr[i])) {
				int value = 1;
				Remdup.put(arr[i],value);
				
			}else {
				Remdup.put(arr[i], 1);
				
			}
		}
		
		int newarr[] = new int[Remdup.size()];
		int k = 0;
		for(Integer i: Remdup.keySet()) {
			newarr[k]  = i;
			k++;
		}
		
		System.out.println();
		System.out.println(newarr.length);
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i]+ " ");
		}
		sc.close();
	}
}