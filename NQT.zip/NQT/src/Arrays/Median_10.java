package Arrays;
import java.util.*;
import java.util.Arrays;
class Median_10 {
	public static Double odd_median(int arr[], int n) {
		double m = 0;
		m = (double)arr[(n+1)/2-1];
		return m;
	}
	public static Double even_median(int arr[], int n) {
		double m = 0;
		m = (double)arr[n/2-1] + arr[(n/2) + 1-1];
		m = m / 2;
		return m;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		Arrays.sort(arr);
		for(int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}
		double med = 0;
		if( n%2 != 0) {
		//odd_median;
		med = odd_median(arr, n);
		}else {
			//even_median;
			med = even_median(arr, n);
			
		}
		System.out.println("Median: "+ med);
		sc.close();
	}
}