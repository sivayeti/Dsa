package Arrays;
import java.util.*;
class RemovedupUSA_12 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> Remdup = new HashMap<>();
	    ArrayList<Integer> newarr = new ArrayList<>();
		for(int i = 0; i < n; i++) {
			
			if(Remdup.containsKey(arr[i])) {
				int value = 1;
				Remdup.put(arr[i],value);
				
				
			}else {
				Remdup.put(arr[i], 1);
				newarr.add(arr[i]);
			}
		}
		
		System.out.println(newarr);
	
		System.out.println();
		sc.close();
	}
}