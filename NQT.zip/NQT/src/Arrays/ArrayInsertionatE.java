package Arrays;
import java.util.*;

class ArrayInsertionatE {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int v = sc.nextInt();
		
		int newarr[] = new int[arr.length + 1];
		int l = newarr.length;
		newarr[l-1] = v;
		for(int i = 0; i < arr.length; i++) {
			newarr[i] = arr[i];
		}
		
		for(int i = 0; i < l; i++) {
			System.out.print(newarr[i] + " ");
		}
		sc.close();
	}
}