package Arrays;
import java.util.*;

class Rank_18 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int newarr[] = new int[n];
		for(int i = 0; i < n; i++) {
			newarr[i] = arr[i];
		}
		
		Arrays.sort(arr);
		
		ArrayList<Integer> a = new ArrayList<>();
		for(int i = 0; i < arr.length; i++) {
			if(!a.contains(arr[i])) {
			a.add(arr[i]);
			}
		}
		
		
		int rank[] = new int[a.size()];
		for(int i = 0; i < a.size(); i++) {
			rank[i] = i+1;
		}
		
		for(int k: newarr) {
			System.out.print(k+" ");
		}
		System.out.println();
		for(int k: arr) {
			System.out.print(k+" ");
		}
		System.out.println();
		for(int k: a) {
			System.out.print(k+" ");
		}
		System.out.println();
		for(int k: rank) {
			System.out.print(k+" ");
		}
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		for(int i = 0; i < a.size(); i++) {
			
			hm.put(a.get(i), rank[i]);
		
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Output");
		for(int k: newarr) {
			System.out.print(k+" ");
		}
		System.out.println();
		for(int i = 0; i < n; i++) {
			System.out.print(hm.get(newarr[i])+ " ");
		}
		sc.close();
	}
}