package Arrays;
import java.util.*;
class AddElement_13 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number which you want to insert at begining: ");
		int ins = sc.nextInt();
	    System.out.println("Enter the size of array: ");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the elements of array: ");
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}   
		//arr = 1 2 3   (size=3)
		//      0 1 2
		//new = 4 1 2 3 (size=4)
		//      0 1 2 3
		
		int newarr[] = new int[arr.length+1]; 
		newarr[0] = ins;
		for(int i = 1; i < arr.length+1; i++) {
			newarr[i] = arr[i-1];
		}
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i] + " ");
		}
		//System.out.println(newarr);
		sc.close();
	}
}