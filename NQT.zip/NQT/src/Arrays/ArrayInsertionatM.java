package Arrays;
import java.util.*;

class ArrayInsertionatM {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int pos = sc.nextInt(); //5(position in array).
		int val = sc.nextInt(); //5-1 = 4(index in array)
		
		
		int newarr[] = new int[n+1];
		
		for(int i = 0; i < pos-1; i++) {
			newarr[i] = arr[i]; // 0 1 2 3
		}
		newarr[pos-1] = val;
		//arr[i] = 4, 5, 6
		//newarr[i] = 0,1,2,3,7,4,5,6
		for(int i = pos; i < newarr.length; i++) {
			newarr[i] = arr[i-1];
		}
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i] + " ");
		}
		sc.close();
	}
}