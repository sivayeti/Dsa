package Arrays;
import java.util.*;

class RepeatElements_14 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		
		for(int i = 0; i < n; i++) {
			if(hm.containsKey(arr[i])) {
				int val = hm.get(arr[i]);
				hm.put(arr[i], val + 1);
			}else {
				hm.put(arr[i], 1);
			}
		}
		
		for(Integer i: hm.keySet()) {
			if(hm.get(i) > 1) {
				System.out.print(i+" ");
			}
		}
		sc.close();
	}
}