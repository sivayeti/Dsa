package Arrays;
import java.util.*;

class Rearrange_06 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int q = n;
		//Sorting the array
		int j = 0;
		int temp = 0;
		while(q > 0) { //5
		for(int i = 0; i < n-1; i++) { //8 6 4 3 7   // 3 4   6  7 8
			j = i + 1;                 //6 8 4 3 7
			if(arr[i] > arr[j]) {      //6 4 8 3 7
				temp = arr[j]; //6     //6 4 3 8 7
				arr[j] = arr[i]; //8   //6 4 3 7 8   n = 4  
				arr[i] = temp; //6
			}
		}
		q = q - 1;
		}
		
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		
			System.out.println();
		int newarr[] = new int[n];
		for(int i = 0; i < n/2; i++) {
			newarr[i] = arr[i];
		}
		
		int l = 0;
		for(int i = n/2; i < n; i++){
			//3 4 5  --> i
			//5 4 3  --> j = 6 - 3 + 2, 6 - 4 + 2, 6 - 5 + 2 ==> n - i + 2;
			                          
			l = n - i + 2;
			newarr[i] = arr[l];
		}
		
	    for(int i = 0; i < n; i++) {
	    	System.out.print(newarr[i]+ " ");
	    }
	    sc.close();
	}
}