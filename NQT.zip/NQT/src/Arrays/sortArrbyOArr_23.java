package Arrays;

import java.util.*;

class sortArrbyOArr_23 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int n1 = sc.nextInt();
		int[] arr1 = new int[n1];
		for(int i = 0; i < n1; i++) {
			arr1[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		
		for(int i = 0; i < n; i++) {
			if(!hm.containsKey(arr[i])) {
				hm.put(arr[i], 1);
			}else {
				int val = hm.get(arr[i]);
				hm.put(arr[i], val+1);
			}
		}
		
		
		ArrayList<Integer> a = new ArrayList<>();
		for(int i = 0; i < n1; i++) {
	        int k = hm.get(arr1[i]);
	        for(int j = 0; j < k; j++) {
	        	a.add(arr1[i]);
	        }
		}
		
		
		for(int i: hm.keySet()) {
			if(!a.contains(i)) {
				int g = hm.get(i);
				for(int j = 0; j < g; j++) {
					a.add(i);
				}
			}
		}
		
		System.out.println(a);
		
		int[] newarr = new int[a.size()];
		
		for(int i = 0; i < newarr.length; i++) {
			newarr[i] = a.get(i);
			
		}
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i]+ " ");
		}
		
		sc.close();
	}
}