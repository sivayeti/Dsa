package Arrays;
import java.util.*;

class Reverse_04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int j = 0;
		int rev[] = new int[n];
		for(int i = 0; i < n; i++) {
			//0 1 2 3 4 5
			j = n-i-1;
			rev[i] = arr[j];
		}
		
	    System.out.println("Reverse Array: ");
	    for(int i = 0; i < n; i++) {
	    	System.out.print(rev[i] + " ");
	    }
	    
	    sc.close();
	}
}