package Strings;

import java.util.*;

class Ascii_03 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		char s = sc.next().charAt(0);
		//int v = s;
		
		System.out.println((int) s);
		sc.close();
	}
}