package Strings;

import java.util.*;

class Concat_26 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s1 = sc.nextLine();
		String s2 = sc.nextLine();
		
		s1 = s1 + s2;
		
		System.out.println(s1);
		
		sc.close();
	}
}