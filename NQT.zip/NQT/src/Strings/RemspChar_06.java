package Strings;

import java.util.*;

class RemspChar_06 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		String v = "";
		
		for(int i = 0; i < s.length(); i++) {
			if((s.charAt(i) >= 'a' && s.charAt(i) <= 'z') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z')) {
				v += s.charAt(i);
			}
		}
		
		System.out.println(v);
		sc.close();
	}
	
}