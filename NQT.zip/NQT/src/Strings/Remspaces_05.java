package Strings;

import java.util.*;

class Remspaces_05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		String space = "";
		
		for(int i = 0; i < s.length(); i++) {
			if(!(s.charAt(i) == ' ')) {
				space += s.charAt(i);
			}
		}
		
		System.out.println(space);
		
		sc.close();
	}
}