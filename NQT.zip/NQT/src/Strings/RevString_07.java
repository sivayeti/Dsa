package Strings;
import java.util.*;

class RevString_07 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		String v = "";
		
		for(int i = 0; i < s.length(); i++){
			//abc ==>s
			//012
		
			//210
			//012  //3-0-1 = 2 
			       //3-1-1 = 1
			       //3-2-1 = 0
			//cba  ==>v
			v += s.charAt(s.length() -1 -i);
			
		}
		System.out.println(v);
		sc.close();
	}
}