package Strings;

import java.util.*;

class CountWords_23 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		int count = 1;
		if(s.length() == 0) {
			count = 0;
		}else {
			for(int i = 0; i < s.length(); i++) {
				if(s.charAt(i) == ' ') {
					count += 1;
				}
			}
		}
		
		System.out.println(count);
		sc.close();
	}
}