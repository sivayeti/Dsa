package Strings;

import java.util.*;

class CapFLofword_10 {
     public static void main(String[] args) {
    	 Scanner sc = new Scanner(System.in);
    	 
    	 String s = sc.nextLine();
    	 String v = "";
    	 
    	 for(int i = 0; i < s.length(); i++) {
    		 //take u for
    		 //0123456789
    		 if(i == 0 || i == s.length()-1  ) {
    			 v = v +  Character.toUpperCase(s.charAt(i));
    		 }else if (s.charAt(i-1) == ' ' || s.charAt(i+1) == ' ') {
    			 v = v + Character.toUpperCase(s.charAt(i));
    		 }else {
    			 v = v + s.charAt(i);
    		 }
    		 
    	 }
    	 
    	 System.out.println(v);
    	 sc.close();
     }
}