package Strings;

import java.util.*;

class HighRepLet_24 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		//creating arraylist to store each word in string
		ArrayList<String> a = new ArrayList<>();
		String temp = "";
		for(int i = 0; i < s.length(); i++) {
			if(s.charAt(i) != ' ') {
			temp += s.charAt(i);
			}else {
				a.add(temp);
				temp = "";
			}
		}
		
		a.add(temp);
		System.out.println(a);
		
		
		
		
		//int max = 0;
		String ans = "";
		int countMax = 0;
		//int val1 = 0;
		
		for(String k: a) {
			//creating hashmap for each string
			HashMap<Character,Integer> hm = new HashMap<>();
			for(int i = 0; i < k.length(); i++) {
				if(! (hm.containsKey(k.charAt(i)))) {
					hm.put(k.charAt(i), 1);
				}else {
					int val = hm.get(k.charAt(i));
					hm.put(k.charAt(i), val+1);
				}
			}
			
			
			//to findout high frequence in string
			int max = 0;
			int count = 0;
			for(Character c : hm.keySet()){
				if(hm.get(c) > max  ) {
					max = hm.get(c);
					//count += 1;
				}
				
				
			}
			
			//to find out no.of characters with high frequence ( frequence must be greater than 1) in string
			for(Character c: hm.keySet()) {
				if(hm.get(c) == max && max > 1) {
					count += 1;
				}
			}
			
			//int countMax = 0;
			//to filter out which string has more no.of characters with high repetition
			if((count > countMax) && (count > 1)) {
				countMax = count;
				ans = k;
			}
			System.out.println(hm);
		}
		
		
	   if( !(ans.equals("") ) ) {
		   System.out.println(ans);
			 
	   }else {
		   System.out.println(-1);
	   }
	  
		
		sc.close();
		
	}
}