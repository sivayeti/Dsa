package Strings;

import java.util.*;

class SortChar_22 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		ArrayList<Character> a = new ArrayList<>();
		
		for(int i = 0; i < s.length(); i++) {
			a.add(s.charAt(i));
		}
		
		a.sort(null);
		
		String res = "";
		
		for(Character c: a) {
			res += c;
		}
		
		System.out.println(res);
		sc.close();
	}
}