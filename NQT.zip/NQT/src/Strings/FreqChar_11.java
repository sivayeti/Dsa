package Strings;

import java.util.*;

class FreqChar_11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashMap<Character,Integer> hm = new HashMap<>();
		ArrayList<Character> a = new ArrayList<>();
		String s = sc.nextLine();
		for(int i = 0; i < s.length(); i++) {
			if(hm.containsKey(s.charAt(i)) ) {
				int val = hm.get(s.charAt(i));
				hm.put(s.charAt(i), val+1);
			}else {
				hm.put(s.charAt(i), 1);
			}
		}
		
		for(Character c: hm.keySet()) {
			a.add(c);
		}
		//System.out.println(a);
		a.sort(null);
		//System.out.println(a);
		
		for(int i = 0; i < a.size(); i++) {
			char c = a.get(i);
			System.out.print(c);
			System.out.print(hm.get(c));
			System.out.print(" ");
		}
		//System.out.println(hm);
		sc.close();
	}
}