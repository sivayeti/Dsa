package Strings;

import java.util.*;

class CountVCW_02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		//String v = "aeiouAEIOU";
		int vow = 0;
		int con = 0;
		int wsp = 0;
		
		s = s.toLowerCase();
		for(int i = 0; i < s.length(); i++) {
			//for(int j = 0; j < v.length(); j++) {
				//if(s.charAt(i) == v.charAt(j)) {
			    if(s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o' || s.charAt(i) == 'u') {
					vow = vow + 1;
				}else if(s.charAt(i) >='a' && s.charAt(i) <='z') {
					con = con + 1;
				}else if (s.charAt(i) == ' '){
					wsp = wsp + 1;
				}
			//}
		}
		
		System.out.println("Vowels: " + vow);
		System.out.println("Consonants: " + con);
		System.out.println("white spaces: " + wsp);
		
		sc.close();
	}
}