package Strings;

import java.util.*;

class Remvow_04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String  s = sc.nextLine();
	    //sc.nextLine();
	    String v = "";
	    for(int i = 0; i < s.length(); i++) {
	    	if(!(s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'o' || s.charAt(i) == 'u' || s.charAt(i) == 'A' || s.charAt(i) == 'E' || s.charAt(i) == 'O' || s.charAt(i) == 'U' || s.charAt(i) == 'I' || s.charAt(i) == 'i')){
	    		v = v + s.charAt(i);
	    	}
	    }
	    System.out.println(v);
	    sc.close();
	}
}