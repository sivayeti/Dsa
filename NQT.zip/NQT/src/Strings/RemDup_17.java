package Strings;

import java.util.*;

class RemDup_17 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		String v = " ";
		String dup = "";
		boolean res = false;
		//s = bcabc
		//    01234
		//i = 0;
		//b == " " (res = false) => v = " "b
		//i = 1;
		//c == " ",b (res = false) => v = " "bc
		//i = 2;
		//a == " ",b,c (res = false) => v = " "bca
		//i =3
		//b == " ",b,c,a (s.charAt(i=3) == v.charAt(j=1)) ==> res = true , dup = b
		//               (s.charAt(i=3) == v.charAt(j=2) ==> res = false, 
		//                                          j=3
		for(int i = 0; i < s.length(); i++) {
			res = false;
			for(int j = 0; j < v.length(); j++) {
				if(s.charAt(i) == v.charAt(j)) {
					dup += s.charAt(i);
					res = true;
				}
			}
			
			
			
			if(res == false) {
				v += s.charAt(i);
			}
			
		}
		System.out.println(v); //Rem duplicates
		System.out.println(dup); //print duplicates
		sc.close();
	}
}