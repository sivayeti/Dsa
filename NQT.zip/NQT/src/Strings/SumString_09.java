package Strings;

import java.util.*;

class SumString_09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		
		int sum = 0;
		String digits = "";
		
		//1 x y z 23
		for(int i = 0; i < s.length(); i++) {
			if(Character.isDigit(s.charAt(i))) {
				digits = digits + s.charAt(i);
			
			}else {
				sum = sum + Integer.parseInt(digits);
				
				digits = "0";
			}
		}
		
		sum = sum + Integer.parseInt(digits); //for adding last digits in string (1xyz23) ==> +23
		
		System.out.println(sum);
		sc.close();
	}
}