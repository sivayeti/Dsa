package Strings;

import java.util.*;

class Anagram_13 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		String v = sc.nextLine();
		boolean res = false;
		/*
		if(!(s.length() == v.length()) ) {
			res = false;
		}
		*/
		
			//function to verify the letter same or not
			for(int i = 0; i < s.length(); i++) {
				res = false;
				for(int j = 0; j < s.length(); j++) {
					if(s.charAt(i) == v.charAt(j) ) {
						res = true;
						break;
						
					}
					
	
				}
				
				if(res == false) {
					break;
				}
				
			}
		
			
			
			if(res == true && s.length() == v.length()) {
				System.out.println(res);
			}else {
				System.out.println(false);
			}
	
		
		sc.close();
	}
}