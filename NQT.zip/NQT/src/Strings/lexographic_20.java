package Strings;

import java.util.*;

class lexographic_20 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int k = 0;
	int l = 0;
	String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	          //0                       2526                       51
	
	String s1 = sc.nextLine();
	String res = "";
	
			
	for(int i = 0; i < s1.length(); i++) {
		k = s.indexOf(s1.charAt(i));
		if(k == 25) {
			l = 0;
		}else if(k == 51) {
			l = 26;
		}else {
			l = k + 1;
		}
		
		res += s.charAt(l);
	}
	
	System.out.println(res);
	sc.close();
}
}