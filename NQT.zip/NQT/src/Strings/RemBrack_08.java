package Strings;

import java.util.*;

class RemBrack_08 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		String v = "";
		
		for(int i = 0; i < s.length(); i++) {
			if( (s.charAt(i) != '(') && (s.charAt(i) != ')') ) {
				v += s.charAt(i);
			}
		}
		
		System.out.println(v);
		sc.close();
	}
}