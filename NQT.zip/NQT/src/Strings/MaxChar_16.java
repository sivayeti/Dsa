package Strings;

import java.util.*;

class MaxChar_16 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
	
		HashMap<Character,Integer> hm = new HashMap<>();
		
		for(int i = 0; i < s.length(); i++) {
			if(hm.containsKey(s.charAt(i))) {
				int val = hm.get(s.charAt(i));
				hm.put(s.charAt(i), val + 1);
			}else {
				hm.put(s.charAt(i), 1);
			}
		}
		
		int max = 0;
		char res = ' ';
		for(Character c: hm.keySet()) {
			if(hm.get(c) > max) {
				max = hm.get(c);
				res = c;
			}
		}
		
		System.out.println(res);
		
		
		
		sc.close();
	}
}