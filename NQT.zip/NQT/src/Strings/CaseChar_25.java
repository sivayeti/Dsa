package Strings;

import java.util.*;

class CaseChar_25 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		String res = "";
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if(  Character.isLowerCase(c) ) {
				res += Character.toUpperCase(c);
			}else if( Character.isUpperCase(c) ) {
				res += Character.toLowerCase(c);
			}else {
				res += s.charAt(i);
			}
		}
		
		System.out.println(res);
		
		
		sc.close();
	}
}