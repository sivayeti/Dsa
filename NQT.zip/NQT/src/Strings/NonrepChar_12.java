package Strings;

import java.util.*;

class NonrepChar_12 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*
		HashMap<Character,Integer> hm = new HashMap<>();
		
		
		String s = sc.nextLine();
		for(int i = 0; i < s.length(); i++) {
			if( hm.containsKey(s.charAt(i)) ) {
				int val = hm.get(s.charAt(i));
				hm.put(s.charAt(i), val + 1);
			}else {
				hm.put(s.charAt(i), 1);
			}
		}
		
		System.out.println(hm);
		
		for(Character c: hm.keySet()) {
			if(hm.get(c) == 1) {
				System.out.print(c + " ");
			}
		}
		*/
		
		String s = sc.nextLine();
		ArrayList<Character> a = new ArrayList<>();
		ArrayList<Character> b = new ArrayList<>();
		
		for(int i = 0; i < s.length(); i++) {
			if(a.contains(s.charAt(i)) && !b.contains(s.charAt(i))) {
				b.add(s.charAt(i));
			}else {
				a.add(s.charAt(i));
			}
		}
		
		for(Character c: a) {
			if(!b.contains(c)) {
				System.out.print(c + " ");
			}
		}
		sc.close();
	}
}