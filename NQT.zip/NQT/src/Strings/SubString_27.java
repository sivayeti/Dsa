package Strings;

import java.util.*;

class SubString_27 {
	public static boolean check(String s2, String temp) {
		boolean res = false;
		if(temp.equals(s2)) {
			res = true;
		}
		return res;
	}
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		String s1 = sc.nextLine(); //takefufor
		                           //012345678
		String s2 = sc.nextLine(); //for
		                           //012
		
		//sub strings form
		//0-0   0-1   0-1-2  0-1-2-3
		//1-1   1-2   1-2-3
		//2-2   2-3
		//3-3
		
		//Generate all sub strings
		//substring length = s2.length() = 3
		//Generate all substrings with length 3 in brute force and two pointers both way.
		
		
		
		
		
		
		//Bruteforce
		//takefufor
		//012345678
		//substrings:
		//012  123  234 345 456 567 678
		//i=0  1    2   3   4   5   6
		//i+3  4    5   6   7   8   9
	    //i should iterate from 0-7
		/*
		int sl = s2.length();
		int ans = 0;
		for(int i = 0; i < s1.length()-sl+1; i++) {
			//System.out.println(i+ " " + (i+3));
			//String temp = s1.substring(i, i+3);
			String temp = s1.substring(i, i+sl);
			System.out.println(temp);
			boolean r = check(temp, s2);
			if(r == true) {
				ans = i;
				break;
			}else {
				ans = -1;
			}
	
			
		}
		
		
		System.out.println(ans);
		*/
		
		
		
		//Let's try the problem in sliding window two pointers
		int l = 0;
		int r = 0;
		int sl = s2.length();
		String temp = "";
		//r=0 , temp = t
		//r=1 , temp = ta
		//r=2 , temp = tak => we require 3 substring pass to the check function and check matches are not
		//             012
		//r=3 , temp = take=> we don't require strings more than 3 ,then eliminate first char and transform into 3 length character
		//             0123
		boolean val = false;
		int ans = -1;
		for(r = 0; r < s1.length(); r++) {
			temp += s1.charAt(r);
			
			if(r-l == sl) {
				temp = temp.substring(1,temp.length());
				l = l + 1;
			}
			
			if(r-l+1 == sl) {
				
				//System.out.println(temp);
				val = check(s2, temp);
			}
			
			if(val == true) {
				ans = l;
				break;
			}
		}
		System.out.println(ans);
		
		sc.close();
	}
}