package Strings;

import java.util.*;

class Palindrome_01 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		//sc.nextLine();
		
		String v = "";
		
		for(int i = 0; i < s.length(); i++) {
			//ABA => s
			//012
			//012 => v
			//210 => 3-0-1, 3-1-1, 3-2-1
			//           2,     1,     0
			v = v +  s.charAt(s.length() - i -1);
			
		}
		
		if(v.equals(s)) {
			System.out.println("palindrome");
		}else {
			System.out.println("Not palindrome");
		}
		
		sc.close();
	}
}