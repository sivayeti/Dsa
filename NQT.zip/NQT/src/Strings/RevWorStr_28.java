package Strings;

import java.util.*;

class RevWorStr_28 {
	public static String pasteres(String req, String res) {
		String req1 = "";
		for(int i = 0; i < req.length(); i++) {
			req1 += req.charAt(req.length()-1-i);
		}
		
		res += req1;
		
		return res;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		//Hel wor ld 
		//0123456789
		//dl row leH
		//0123456789
		//ld wor Hel
		
		//reach first white space and reverse the obtained string and concat to res string
		String rev = "";
		
		for(int i = 0; i < s.length(); i++) {
			rev += s.charAt(s.length()-1-i);
		}
		
		//System.out.println(rev);
		String req = "";
		String res = "";
		String res1 = "";
		for(int i = 0; i < rev.length(); i++) {
			if(rev.charAt(i) == ' ' ) {
				res1 += pasteres(req, res);
				res1 += ' ';
				//System.out.println(res1);
				req = "";
			}else {
			req += rev.charAt(i);
			};
			
		}
		res1 += pasteres(req, res);
		System.out.println(res1);
		
		sc.close();
	}
}