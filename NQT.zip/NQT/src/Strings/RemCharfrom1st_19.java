package Strings;

import java.util.*;

class RemCharfrom1st_19 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s1 = sc.nextLine();
		String s2 = sc.nextLine();
		
		String re = "";
		
		//abcdef
		//012345
		//cefz
		//0123
		
		//i=0 a j->0-3 not present res.append()
		//i=1 b 
		//i=2 c j->0-3 j=0 present not append
		
		//i=2 c j=0 c 
		  // s1.charAt(i=2) != s2.charAt(j=0)  (==)
		//i=2 c j=1 e
		  // s1.charAt(i=2) != s2.charAt(j=1)  (!=)
		
		//the character should iterate over the second string if it presents in it it should break and start to check go with next character
		
		boolean res = false;
		for(int i = 0; i < s1.length(); i++) {
			res = false;
			for(int j = 0; j < s2.length(); j++) {
				if(s1.charAt(i) == s2.charAt(j)) {
					res = true;
				}
			}
			
			if(res == false) {
				re += s1.charAt(i);
			}
		}
		
		
		System.out.println(re);
		sc.close();
	}
}