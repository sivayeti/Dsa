package Strings;

import java.util.*;

class largestWord_21 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String r = "";
        String a = "";
        
        int maxi = 0;
        
        for(int i = 0; i < s.length(); i++) {
        	
        	if(s.charAt(i) != ' ') {
        		r += s.charAt(i);
        	}else {
        		if(r.length() > maxi) {
        			maxi = r.length();
        			a = r;
        			r = "";
        		}
        	}
        }
        
        System.out.println(a);
		sc.close();
	}
}