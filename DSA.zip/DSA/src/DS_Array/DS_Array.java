package DS_Array;
import java.util.*;

public class DS_Array {

	public static void main(String[] args) {
		
		//In primitive data type, we cant store the n no.of data in single variable, but we can achieve these by using non-primitive data type like array
		int arr[] = {1,2,3,4,5,6,9};
		System.out.println("Array_size: " + arr.length);
		System.out.println("Array_last_index: " + (arr.length - 1));
		//we can access the array elements by using its index values i.e addresses of array elements
		System.out.println("Array_last_element: " + arr[arr.length-1]);
		System.out.println("Array_first_element: " +  arr[0]);
	
		//lets iterate over the first and each element of array, by using their respective index
		for(int i = 0; i < arr.length; i++) {
			System.out.println("index " + i + " :" + arr[i] + " ");
		}
	}
}
