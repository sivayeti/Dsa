package DS_Array;
import java.util.*;

//2D_Array
public class DS_2D_Array {

	public static void main(String[] args) {
	//	Scanner sc = new Scanner(System.in);
		
		/*
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		//Lets store the values in these array
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		for(int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}
		*/
		
		
		//2D_Array
		/*
		int arr[][] = { {1,2,3,4},{5,6,7,8},{0,9,2,4} } ; //n no.of 1D arrays are placed in single array is called 2D array
		
		//System.out.println(arr.length + " :" + arr[0].length);
		//In these array , we have 3 1D arrays
		for(int i = 0; i < arr.length; i++) {
			//while i iterating over each 1D, then after inside each 1D how many elements are tehre
			for(int j = 0; j < arr[0].length; j++) {
				//i -> row, j -> col over row
				//i=0,
				//j=0 {0,0} j=1 {0,1} j = 2 {0,2}
			     System.out.print(arr[i][j] + " ");
				
			}
			System.out.println();
		}
		
		System.out.println(arr[1][2]);
		*/
		
		
		
		//lets take the no.of rows and cols from user and print the 2D array
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int m = sc.nextInt();
		int arr[][] = new int[n][m];
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[0].length; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		
		
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j]+ " ");
			}
			System.out.println();
		}
	}
	
		
}
