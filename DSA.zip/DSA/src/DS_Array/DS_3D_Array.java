package DS_Array;
import java.util.*;

public class DS_3D_Array {

	//3D_Array
	//N 2D_Arrays placed in single array is called 3D array
	public static void main(String[] args) {
	    
		int arr[][][] = {   { {1,2,3},{4,5,6} },  { {1,2,3},{4,5,6} }    };
		
		System.out.println("N no.of 2D_Arrays are available: " + arr.length);
		System.out.println("N no.of 1D_Arrays are avaialble in each 2D array: " + arr[0].length);
		
		System.out.println("N no.of elements in each 1D array: " + arr[0][0].length);
		 
		//Lets iterate over the each element in 3D array
		for(int i = 0; i < arr.length; i++) { //iterating over each 2D array
			for(int j = 0 ; j < arr[0].length; j++) { //iterating over each 1D array in respective 2D array
				for(int k = 0; k < arr[0][0].length; k++) { //iterating over the each element in 1D array.
					System.out.print(arr[i][j][k] + " ");
				}
				System.out.println();
				
			}
			System.out.println();
			
		}
	}
}

//3
//1 2 3  i=0, j=0 , k=0,1,2
//4 5 6  i=0, j=1 , k=0,1,2

//1 2 3  i=1, j=0, k =0,1,2
//4 5 6  i=1, j=1, k =0,1,2

