package DS_Array;
import java.util.*;

public class DS_3D_Array_2 {

	//Lets input the values from user in 3D Array
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();  //n no.of 2D arrays should present in our 3D array
		int m = sc.nextInt(); //n no.of 1D arrays should present in each 2D array
		int l = sc.nextInt(); //n no.of elements should present in each 1D array
	
		int arr[][][] = new int[n][m][l];
		
		for(int i = 0; i < n; i++) { //iterate over each 2D array in 3D array
			for(int j = 0; j < m; j++) { //iterate over each 1D array in each 2D array
				for(int k = 0; k < l; k++) { //iterate over each element in each 1D array
					arr[i][j][k] = sc.nextInt();
				}
				
			}
			
		}
		
		
		for(int i = 0; i < n; i++) { //iterate over each 2D array in 3D array
			System.out.print("{");
			for(int j = 0; j < m; j++) { //iterate over each 1D array in each 2D array
				System.out.print("{");
				for(int k = 0; k < l; k++) { //iterate over each element in each 1D array
					
					System.out.print(arr[i][j][k] + " ");
				}
				System.out.print("}");
				System.out.print(" ");
			}
			System.out.print("}");
			System.out.println();
		}
		
	
		System.out.println(arr[1][0][2]);
	}
	
}

//2D arrays - length
//1D arrays - height
//n elements in 1D - breadth

  
//{{1 2 3 4 } {3 4 5 6 } }  (i = 0)
   //j=0       //j=1
 

//{{1 2 3 4 } {3 4 5 6 } }  (i = 1)
   //j=0       //j=1

///{{1 2 3 4 } {3 4 5 6 } } (i = 2)
   //j=0       //j=1
