package DS_Queue.Day_25;

import java.util.Arrays;
import java.util.NoSuchElementException;

interface Queue2<E>{
	boolean add(E data);
	E remove();
	E element();
}
public class PriorityQueue2<E> implements Queue2<E> {

	//As here we are not implementin the Queue using nodes i.e LinkedList
	//We are implementing the Queue here using array, i.e priority queue.
	static int size = 0;
	static int front;
	static int rear;
    Object[] arr;
    public PriorityQueue2() {
    	arr = new Object[size]; //declaring the size for array like, int arr = new arr[7];
    	front = 0;
    	rear = -1;
    	
    }
    
    //And then i don't want to limit the array size, it should not be static, it should be static, so i want to double the size of array, whenever a new element is comes, to trigger these, i will increment rear, and when rear>=arr.length() that means new element is coming , so i have to double the array size for that i will declare a function growArray
    Object[] growArray(Object[] arr, int size) {
    	//return Arrays.copyOf(arr,  size*2)
         // return Arrays.copyOf(arr, size+35); //how many elements we are adding that value+size = size //or to avoid these just double the size
    	return Arrays.copyOf(arr, size+1);
    	
    }
    
    
    
	@Override
	public boolean add(E data) {
		//Initially rear = -1, arr[] = {}.length => 0
		//When new element encounter rear increments , rear = 1,
		//rear>=arr.length(), triggers new element comes, so double the size of array, then add the new element, passed to arr[rear]
		rear++;
		if(rear >= arr.length) {
			arr = growArray(arr, size); //array size doubled
		    //size = size*2;  //these is crucial to double the size,and we can ive whatever the value for size in growArray
		     size = size + 1; //updated array size is stored in arr,
		                      //but whatever the size is updated that is stored in size variable here, so it ensures, whenever growArray(arr,size), is called that function recieves the size which is correct to its arry size which is previously updated.
		}
		arr[rear] = data;
		
		
		return arr[rear] == data;
	}

	@Override
	public E remove() {
        if(rear < 0) {
        	throw new NoSuchElementException(); //rear<0 means there are no elements in array, and we can't perform the delete operation
        }
        E rem = (E) arr[front]; //as we have to remove the front element in queue i.e arr[0]
        System.arraycopy(arr, 1, arr, 0, arr.length-1);
      //System.arraycopy(old_array, from_which_index_we_want_elements, new_array_name, In_new_array_from_hich index_should_elements(copied from old array)_starts, new_array_size(as we are removing one element form old array, so new array should decrement 1 w.r.t to old array)
        //These method will returns and array from 1 index, and stores in 'arr' named array
		
        //As one element is removed, so rear variable which points the last element index should also decrement
        rear--;
        return rem;
		
		//arr = {0,1,2,3}
		// System.arraycopy(arr, 1, arr, 0, arr.length-1);
		//arr = {1,2,3}
		
	}

	
	@Override
	public E element() {
		if(rear<0) throw new NoSuchElementException();
		return (E)arr[front];
	}

	
	
	public String toString() {
		String ans ="[";
		for(int i = front; i <= rear; i++) {
			if(i == rear) {
				ans = ans + arr[i];
			}else {
				ans = ans + arr[i]+ ",";
			}
		}
		
		//return super.toString();
		return ans+"]";
		
	}
	
	public static void main(String[] args) {
		Queue2<Integer> que = new PriorityQueue2<>();
		
		que.add(1);
		System.out.println(que.add(2));
		que.add(3);
		que.add(4);
		/*
		for(int i = 0; i <= 15 ; i++) {
			que.add(i);
		}
		System.out.println(que.add(16));
		*/
		
		//Lets perform the remove operation
		System.out.println(que.remove());
		
		
		
		//Lets perform the element operation also here only'
		
		System.out.println(que.element());
		
		
		System.out.println(que); //PriorityQueue2@24d46ca6 //to print the elements in que  object lets override the toString();
		
		
		//What ever the code we developed , it will displays the element based on insertion order
		//But in collection 'priority' queue, the elements will not display based on order, and at the same time here the elements removal will not based on the position of elements following FIFO, but the removal of elements based on priority  of insertion i.e which inserts first that will remove first (but not based on the position). here these concept rises because of the priority queue will not displays the element based on the insertion
		//In collections queue, the elements will display based on order,and at same time here the elements removal is based on position of elements following fifo, because the elements are displayed based onthe insertion order.
	}
}
