package DS_Queue.Day_25;
import java.util.*;

public class Collections_PriorityQueue {

	public static void main(String[] args) {
		Queue<Integer> que = new PriorityQueue<>();
		for(int i = 0; i <= 15; i++) {
			que.add(i);
		}
		
		System.out.println(que.add(16));
		System.out.println(que.remove());
		System.out.println(que.remove());
		System.out.println(que.element());
		System.out.println(que.element());
		System.out.println(que);
		
		
		
	}
}
