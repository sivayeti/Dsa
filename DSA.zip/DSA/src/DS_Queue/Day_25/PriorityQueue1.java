package DS_Queue.Day_25;

import java.util.Arrays;

interface Queue1<T> {
 
	 
	 boolean add(T val);
	 T remove();
	 T element();
}

 //By using priorityQueue, lets implement the above Queue Interface
 
 public class PriorityQueue1<T> implements Queue1<T>{ //10 11

	//Here we are implementing the Queue by using Arrays
	 
	static int size = 10;
	static int front;
	static int rear;
	static Object[] arr; //Object type, i.e array can store any type of data in it.
	//constructor to assign the values for properties
	public PriorityQueue1() {
		arr = new Object[size]; //array is created with default size
		front = 0; //1st position of array
		rear =- 1; //if elements are not there rare is -1, if elements are adding the rare should increment
	}
	
	//I want to make the array size as global
	//Automatically increment the array size by these method.
	Object[] growArray(Object[] arr, int size) {
		
		return Arrays.copyOf(arr, size*2);
	}
	
	
	
	
	public boolean add(T val) {
		// TODO Auto-generated method stub
		rear++; //when elements are adding i want to incrment the rare value
		if(rear >= arr.length) {
			arr = growArray(arr,size); //it makes the array size double.
		    size = size*2;
		}
		arr[rear] = val;
		//As rear = -1, when we add the first element, then rear=0, it is >= arr[] empty arr.length.//Then array size doubled and
		//then arr[0] = arr[rear] = 1;
		return arr[rear] == val; //after the  above assigning is successful, we can check that value assigned to arr[rear] = value passed (val), is true or False.
	}

	public T remove() {
		// TODO Auto-generated method stub
		return null;
	}

	public T element() {
		// TODO Auto-generated method stub
		return null;
	}
	 
	
	
	
	
	
	public static void main(String[] args) {
		Queue1<Integer> que = new PriorityQueue1<>();
		
		//Add method
		que.add(1);
		//System.out.println(que.add(1));
		for(int i = 0; i <= 15; i++) {
			que.add(i);
		}
		System.out.println(que.add(16)); //Even we made the static int size = 10 for array, 
		//these statement returns true, because, the array size is increasing globally.
	}
	
 }
