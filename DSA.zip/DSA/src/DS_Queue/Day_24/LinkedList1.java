package DS_Queue.Day_24;

interface Queue1<E>{
	//Lets deifne the Queue Methods here
	boolean add(E data);  //add at tail.
	boolean offer(E data);
	E remove(); //removes the head/front element and  return the removed element
	E poll();
	E element(); //return the top/front element
	E peek();
	
	
	//As it is interface , its methods should implement in its sub class.
	
	
}
//These created LinkedList class should be sub class for Queue Inteface,
//These LinkedList1 sub class should implement the Queue interface or super class.
/*
public class LinkedList1<E> {

	
}
*/ //These LinkedList1<E> class should implements the Queue Interface, that is Queue interface has only method names,and these method execution should be in Queue interface, sub class linkedList1.


public class LinkedList1<E> implements Queue1<E>{

	@Override
	public boolean add(E data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean offer(E data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E remove() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E poll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E element() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E peek() {
		// TODO Auto-generated method stub
		return null;
	}
	
}