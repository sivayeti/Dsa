package DS_Queue.Day_24;


interface Queue2<E>{
	boolean add(E data);
	boolean offer(E data);
	E remove();
	E poll();
	E element();
	E peek();
	
}

public class LinkedList2<E> implements Queue2<E> {

	
	//LinkedList will store the data in node format
	Node<E> head_Front;
	Node<E> tail_Rear;
	class Node<E>{
		E data;
		Node<E> next;
		public Node(E data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	
	//Add - Enqueue() method, -Add at Last to linked List.
	@Override
	public boolean add(E data) {
		
		//Add at Last to LinkedList
		Node<E> node = new Node<>(data);  //node = [1]
		if(head_Front == null) {
			head_Front = node;
			//tail_Rear = node;
		}
		else{//Add the node at last to linkedList
			tail_Rear.next = node;
			//tail_Rear = node;
		}
		tail_Rear = node; //whatever the node we are adding that should be tail at any case
		return true;
	}

	
	
	
	//offer() - add() method both are same, so I am copy pasting the add() method code for offer() method
	@Override
	public boolean offer(E data) {
		//Add at Last to LinkedList
				Node<E> node = new Node<>(data);  //node = [1]
				if(head_Front == null) {
					head_Front = node;
					//tail_Rear = node;
				}
				else{//Add the node at last to linkedList
					tail_Rear.next = node;
					//tail_Rear = node;
				}
				tail_Rear = node; //whatever the node we are adding that should be tail at any case
				return true;
	}

	
	
	@Override
	public E remove() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E poll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E element() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E peek() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	//To print these LinkedList2 class , objects data normally instead of that objects address
	
	public String toString() {
		Node<E> i = head_Front;
		String s1 = "[";
		String s2 = "]";
		
		while(i != null) {
			if(i.next != null) {
				s1 = s1+i.data+ ",";
				
			}else {
				s1 = s1+ i.data;
				
			}
			i = i.next;
		}
		return s1+s2;
	}

}
