package DS_Queue.Day_24;


public class LinkedList2_Test  {

	public static void main(String[] args) {
		Queue2<Integer> q = new LinkedList2<>();
		
		//Lets implement the add method
		q.add(1);
		//System.out.println(q); //These prints the address of the LinkedList which we create.
		 //LinkedList2@372f7a8d from these LisnkedList2 object we will print the data, for that we have to create a function
		q.add(2);
		q.add(3);
		System.out.println(q.toString());
		
		//Lets implement the remove() method, and return the element which you are removing, basically these remove() method reoves the head_Front element.
	}
}
