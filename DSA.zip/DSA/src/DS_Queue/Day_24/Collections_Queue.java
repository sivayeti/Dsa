package DS_Queue.Day_24;
import java.util.*;

public class Collections_Queue {

	public static void main(String[] args) {
		Queue<Integer> q = new LinkedList<>();
		q.add(1);
		q.add(2);
		q.offer(3);
		System.out.println(q.remove());
		System.out.println(q.poll());
		System.out.println(q.element()); //if elements are not there, then element() returns exception
		System.out.println(q.peek()); //if elements are not there , then peek() returns null.
		System.out.println(q);
		System.out.println(q.remove()); //In collections, remove() returns exception when elements are not there
		System.out.println(q.poll());  //In collections, poll() returns null, if elements are not there
		//But poll, remove() methods both are same;
		
	}
}
