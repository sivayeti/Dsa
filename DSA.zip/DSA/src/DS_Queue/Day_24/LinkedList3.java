package DS_Queue.Day_24;

import java.util.NoSuchElementException;

interface Queue3<E> {
	boolean add(E data);
	boolean offer(E data);
	E remove();
	E poll();
	E element();
	E peek();
}


public class LinkedList3<E> implements Queue3<E> {

	Node<E> head_Front;
	Node<E> tail_Rear;
	class Node<E>{
		E data;
		Node<E> next;
		public Node(E data) {
			this.data = data;
			next = null;
		}
	}
	

	@Override
	public boolean add(E data) {
		Node<E> node = new Node<>(data);
		if(head_Front == null) {
			head_Front = node;
			tail_Rear = node;
		}else {
			tail_Rear.next = node;
			tail_Rear = node;
		}
		
		return true;
	}

	@Override
	public boolean offer(E data) {
		// TODO Auto-generated method stub
		Node<E> node = new Node<>(data);
		if(head_Front == null) {
			head_Front = node;
			tail_Rear = node;
		}else {
			tail_Rear.next = node;
			tail_Rear = node;
		}
		
		return true;
	}

	@Override
	public E remove() {
		// TODO Auto-generated method stub
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		Node<E> i = head_Front;
		head_Front = head_Front.next;
		return i.data;
	}

	
	@Override  //Poll() and remove() both are same methods, so  i will just copy paste the remove() code here.
	public E poll() {
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		Node<E> i = head_Front;
		head_Front = head_Front.next;
		return i.data;
	}

	@Override
	public E element() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E peek() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String toString() {
		String s1 = "[";
		String s2 = "]";
		Node<E> i = head_Front;
		while(i != null ) {
			if(i.next != null) {
				s1 = s1 + i.data +",";
			}else {
				s1 = s1+ i.data;
			}
			i = i.next;
		}
		return s1+s2;
	}
	
	public static void main(String[] args) {
		Queue3<Integer> q = new LinkedList3<>();
		
		q.add(1);
		q.offer(2);
		System.out.println(q); //when we print the class object, then that class toString() method will automatically.
		
		//Lets implement the remove()
		q.add(3);
		System.out.println(q.remove()); //FIFO - we have to remove the head_Front, and update it to the respective head_Front.next as head_Front
		System.out.println(q);
	}
    
	
}
