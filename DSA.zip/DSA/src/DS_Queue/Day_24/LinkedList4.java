package DS_Queue.Day_24;

import java.util.NoSuchElementException;

interface Queue4<E>{
	boolean add(E data);
	boolean offer(E data);
	E remove();
	E poll();
	E element();
	E peek();
	
}
public class LinkedList4<E> implements Queue4<E> {

	Node<E> head_Front;
	Node<E> tail_Rear;
	class Node<E>{
		E data;
		Node<E> next;
		public Node(E data) {
			this.data = data;
			next = null;
		}
	}
	

	@Override
	public boolean add(E data) {
		// TODO Auto-generated method stub
		Node<E> node = new Node<>(data);
		if(head_Front == null) {
			head_Front = node;
			tail_Rear = node;
		}else {
			tail_Rear.next = node;
			tail_Rear = node;
		}
		return true;
	}

	@Override
	public boolean offer(E data) {
		Node<E> node = new Node<>(data);
		if(head_Front == null) {
			head_Front = node;
			tail_Rear = node;
		}else {
			tail_Rear.next = node;
			tail_Rear = node;
		}
		return true;
	}

	@Override
	public E remove() {
		// TODO Auto-generated method stub
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		//removeFirst
		Node<E> i = head_Front;
		head_Front = head_Front.next;
		return i.data;
	}

	@Override
	public E poll() {
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		//removeFirst
		Node<E> i = head_Front;
		head_Front = head_Front.next;
		return i.data;
	}

	
	@Override
	public E element() {
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		return head_Front.data;
	}

	@Override
	public E peek() {  //peek() ,element() both methods are same so, i copy ,paste the element() method , in peek() method.
		if(head_Front == null) {
			throw new NoSuchElementException();
		}
		return head_Front.data;
	}
	 
	public String toString() {  //Instead of printing the object reference, to print the object values , we override toString() method.
		String s1 = "[";
		String s2 = "]";
		Node<E> i = head_Front;
		while(i != null) {
			if(i.next != null) {
				s1 = s1+ i.data + ",";
			}else {
				s1 = s1+i.data;
			}
			i = i.next;
		}
		return s1+s2;
	}
	
	
	
	public static void main(String[] args) {
		Queue4<Integer> q = new LinkedList4<>();
		
		
		q.add(1);
		q.add(2);
		System.out.println(q);
		
		System.out.println(q.poll());
		q.add(3);
		System.out.println(q);
		
		//Lets implement the peek() or element() method which returns the head_Front element
		System.out.println(q.element());
	}
}
