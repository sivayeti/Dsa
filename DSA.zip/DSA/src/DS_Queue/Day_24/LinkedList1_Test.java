package DS_Queue.Day_24;

public class LinkedList1_Test {

	public static void main(String[] args) {
		Queue1<Integer> q = new LinkedList1<>();
		//for Interface, we create the object , by using the interface sub class.
		//As we created the interface object ,by using these object we can access the interface methods, which are implemented in the interface sub class.
		
		
		
		//Lets perform the add operation
		
	}
}
