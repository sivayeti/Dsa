package DS_LinkedList;
import java.util.*;

public class LinkedList_RemoveLast {

	Node head;
	class Node {
		String data;
		Node next;
		public Node(String data) {
			this.data = data;
			this.next = null;
		}
	}
	
	//Add First

	void addFirst(String data) {
	Node node = new Node(data); // [Hello] -> null  //[Hi] -> null
	if(head == null) {
		head = node; //Hello
		return;
	}
	node.next = head; //[Hi] -> [Hello]
	head = node; //head = [Hi] //head.next= [Hello]
	}
	
	//Print Linked List
	void printList() {
	  Node i = head;
	  while(i != null) {
		  System.out.print(i.data + " -> ");
		  i = i.next;
	  }
		System.out.println();
	}
	
	//Add at last

	void addLast(String data) {
    Node node = new Node(data); //[Siva] -> null
    Node i = head; //i = ["A"]
    while(i.next != null) { //Here our logic is when i.next == null that means i holds the last node, we can add our created node to these last node which is stored in i, so we made while loop should break when i.next == null , then leaves i holds last node, we can add our created node to these last node
    	            //[A] -> [Hi]  //[Hi] -> [Hello] //[Hello] -> null these loop breaks, having i = [Hello] , means these [Hello] is last node.
    	i = i.next; //i = [Hi] //i = [Hello]
    	
    }
    
    i.next = node;
		
	}
	
	
	
	
	
   //Remove at Last node - My Solution
	/*
   void removeLast() { 
		Node i = head;
		while(i.next != null) { 
			i = i.next;
		} //These loop breaks when i holds last node, then i.next == null, and causes tp break out from loop and leaves i should contain the last node value.
		
		
		//We want the previous node to last node then only we can make the previous node next connection to null, and causes last node to dereference from linked list 
		//i.e A -> Hi -> Hello -> Siva -> null //i = [Siva] last node,but we want [Hello] which is previous to [Siva](i)
		//Then we can make the [Hello] -> null, leads to list = A -> Hi -> Hell0 -> null
		Node j = head;
		while(j.next != i) {
			j = j.next;
		} //these loop breaks, when j.next returns the last node and ensures that j holds previous node to last node i.
		//we can make the j.next connection to null, which causes the breaking of last node connection to its previous node.
		
		j.next = null;
	}
	*/
	

	
	//Remove Last node - Mentor solution
	void removeLast() {
		Node list = head;
		if(list == null) {
			System.out.println("List is Empty");
			return;
		}else if(list.next == null) {
			head = null;
			return;
		}
		Node second_last = head;
		while(list.next != null) { //These loop breaks, when list = lastnode i.e lastnode.next == null.
			second_last = list;
			list = list.next; //list = lastnode. //when list.next returns lastnode, that means list has the previous node to last node.That previous node is stored in second_last
		}
		second_last.next = null;
	}
	
	
   
   
	public static void main(String[] args) {
		LinkedList_RemoveLast list = new LinkedList_RemoveLast();
		
		list.addFirst("Hello");
		list.addFirst("Hi");
		list.addFirst("A");
		list.printList();
		list.addLast("Siva");
		
		list.printList();
		
		list.removeLast();
		
		list.printList();
		
	}

	



	




}
