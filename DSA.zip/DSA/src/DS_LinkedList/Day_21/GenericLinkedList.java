package DS_LinkedList.Day_21;

public class GenericLinkedList<T> {

	//In these I want to implement the logic
	//Here we have to mention the type of linkedlist i.e LinkedList<T>
	//Node type also we have to mention here i.e class Node<T>
	Node<T> head;
	class Node<T>{
		T data ;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	
	//<T> can  be any particular data type int,float,string, if we create a class "GenericLinkedList<Integer> list = new GenericLinkedList<>();" //means whatever the linked list i have created by using GenericLinkedList class, it can only accepts the data of type in integers only.
	//Generic Linked Lists are used to store only one type of data (we have to specify the type)
	//Normal Linked List can used to store different type of data in it.
	
	
	//So as we specified  'T' should be integer in Test class.for these GenericLinkedList<Integer> class object list.
	void addFirst(T data) {
		Node<T> node = new Node<>(data); //node = [1, next(null)]    //node = [0,next(null)]
		if(head == null) {
			head = node; //head = [1, next(null)]
			return;
		}
		node.next = head; //[0, next(Head)=[1,next(null)]
		head = node; //[0(Head), next=[1, next(null)]
	}



    void printData() {
		Node<T> i = head; 
		while(i != null) {
			System.out.print(i.data + " -> ");
			i = i.next;
			
		}
		System.out.println();
	}

	
}
