package DS_LinkedList.Day_21;

public class Test {

	//I want main method in these
	public static void main(String[] args) {
		
		//<T> can  be any particular data type int,float,string, if we create a class "GenericLinkedList<Integer> list = new GenericLinkedList<>();" //means whatever the linked list i have created by using GenericLinkedList class, it can only accepts the data of type in integers only.
		//Generic Linked Lists are used to store only one type of data (we have to specify the type)
		//Normal Linked List can used to store different type of data in it.
		
		GenericLinkedList<Integer> list = new GenericLinkedList<>();
		
		//As list is an object of other class.
		//Objects are used to access the properties and functions of class.
		list.addFirst(1);
		list.addFirst(0);
		
		list.printData();
		//Here we done add First and print the data
		
		
		
		
		
		
		//Lets remove First
		
	}
}
