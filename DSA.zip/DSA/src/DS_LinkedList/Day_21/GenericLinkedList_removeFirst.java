package DS_LinkedList.Day_21;

public class GenericLinkedList_removeFirst<T> {

	Node<T> head;
	class Node<T>{
		T data;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			next = null;
		}
	}

	//add data
    void addFirst(T data) {
		Node<T> node = new Node<>(data);
		if(head == null) {
			head = node;
			return;
		}
		node.next = head;
		head = node;
	}

    //print data
	void printData() {
		Node<T> i = head;
		while(i != null) {
			System.out.print(i.data + " -> ");
			i = i.next;
		}
		System.out.println();
	}

	
	//remove first - My solution
	/*
	public void removeFirst() {
		head = head.next;
	}
    */
	
	//remove first - Mentor Solution
	public void removeFirst() {
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		head = head.next;
		
	}
	
	
	
}
