package DS_LinkedList.Day_21;

public class Test_removeFirst {

	public static void main(String[] args) {
		
		GenericLinkedList_removeFirst<Integer> list = new GenericLinkedList_removeFirst<>();
	
	    list.addFirst(1);
	    list.addFirst(0);
	    
	    list.printData();
	    
	    //Lets implement the remove First
	    list.removeFirst();
	    
	    list.printData();
	}
}

//If we want to store only one type of data in linkedlist, then we have to make LinkedList as generic.
//GenericLinkedList<T> accepts only the data which it is specified in that class.
