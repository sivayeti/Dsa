package DS_LinkedList;
import java.util.*;


public class LinkedList_AddLast {

	Node head;
	class Node{
		String data;
		Node next;
		public Node(String data) {
			this.data = data;
			this.next = null;
		}
	}
	
	//Add First
	void addFirst(String data) {
		Node node = new Node(data); //node = [Hi,null]
		if(head == null) {
			head = node; //head = [Hi,null]
			return;
		}
		node.next = head; //[Hello,null] => [Hello,[Hi,null]]
		head = node; //head = [Hello,Hi]
		
	}
	
	
	//Print the Linked List
     void printList() {
		Node i = head; //[Hello,[Hi,null]
		while(i!=null) {
			System.out.print(i.data + " -> "); //Hello -> Hi ->
			i = i.next; //i = [Hi,null]
			            //i = null.
		}
		System.out.println();
		
	}
     
     //Remove First
     void removeFirst() {
 		// TODO Auto-generated method stub
    	 //Head = [Hello, [Hi,null]]
 		head = head.next; // head = [Hi,null], these also dereference the 'Hello' first node.
 	}
    
     
     
     
    //Add at last.
 	void addLast(String data) {
 	//Here we have to find the last node, that which is pointing to null , at the next to that last node, we have to add the node, and these current node next we have to store the null.
 		
    //For these we have to find the node which is at last
 		Node node = new Node(data); //[Siva,null]
 		Node i = head; //[A] ->  [Hi] -> [Hello] - > null
 		while(i.next != null) { //[Hi] != null //[Hello] != null //null != null (fails) and left list=[Hello] , which means Hello is the last node and points to null.
 			i = i.next; //i = [Hi]
 			            //i = [Hello]
 			//i.next == null that means i is holds last node, at these case, we made while loop to break, and left the i to store the last node value.
 			
 		}
 		
 		//i has last node value, now we have to add the created node 'node' to the next to these last node.
 		i.next = node; //In these way we can achieve the adding node to last node.
 		//Normally created node 'node' will points next to null value.
 		//[A] -> [Hello] -> ['Hi'] -> [Siva] -> null
 	}

     
	public static void main(String[] args) {
		LinkedList_AddLast list = new LinkedList_AddLast();
		
		list.addFirst("Hello");
		list.addFirst("Hi");
		list.addFirst("A");
		
		
		list.printList();
		list.addLast("Siva");
		//list.removeFirst();
		list.printList();
		
		
		
		
	}



	


	

 
}
