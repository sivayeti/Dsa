package DS_LinkedList;
import java.util.*;

public class LinkedList_AddFirst {

	Node head;  //with the defined class Node, declare the head which is first Node in Linked List
	class Node{
		String data;
		Node next; //with the same defined class Node data type, we have to declare a variable to store the other node.
		
		public Node(String data) { //with these constructor function we can assign the data to the node and next node details.
			this.data=data;
			this.next=null; //whenever we created a node, it should stores the next node as null.
		}
	}
	
	
	
//Add first data or add node initial before or head.
    void addFirst(String data) {
	//First we have to create the Node class objects, because we have to store the data in Node data type format.
    Node node = new Node(data);
    if(head==null) { //if head Node doexnot contains any value, then we can assign the data to head node directly.
    	head = node;
    	return; //if head is empty, when the 1st node is created then at the time , the head variable which is of Node data type, and stores the created node. //and function should stop here, thats why we added the 'return' statement here.
    } //if head is already had the data , then before these passed Node data head 
    
    //Now I wnat to add the created node, to before or first to the head, then i want to store the node.next with head,
    node.next = head; //node.next stores current head value (node.next means next node to current created node 'node' with new data 'Hello'), these current created node 'Hello' will be stored in 'head' variable, which is of Node data type.
    head = node; //and then update the head variable with the current node which you want to be set as head to linked list
		
	}
	
    
    
    //print data
    void printList() {  //Here list variable which stores the head which is of Node data type.
      Node list = head;
      while(list!=null) { //As head stores a value, and not having null , executes into code
    	  System.out.print(list.data + " -> "); //head data will be displayed here.
    	  list=list.next; //we are updating the list variable which is of Node data type with the next value of current node, and again initializes while loop, and executes the code, when ever list stores null value, that means it reaches end of the linked list., and get out of the while loop.
      }
	}
    
    
    
    
	public static void main(String[] args) {
		
	
	LinkedList_AddFirst list = new LinkedList_AddFirst(); //Defined the Linked List data structure, by using LinkedList() class, and assigned the name 'list'
	//In linked List data will be stored in Node format, so create a class node. i.e class is a user -defined data type. so  we have to define a class Node, that which can stores the values, and address of their next elements.
	//By using class concept we can define our desired data type, that which can hold data, and pointer which stores the next node address, which is need for Linked list here.
	
	

	//Lets see how we can add the data to the Linked List first to head Node.
	list.addFirst("Hi"); //By using the function
	//These data is head
	list.addFirst("Hello"); //Now these data becomes head based on the functional code we defined
	//The above 'Hi' data will become next node to Hello node which is head now
	
	//To print the linkedList data also create a function
	list.printList();
	}

	


}
