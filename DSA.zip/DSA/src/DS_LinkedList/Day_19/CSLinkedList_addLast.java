package DS_LinkedList.Day_19;
import java.util.*;

public class CSLinkedList_addLast {

	Node head;
	Node tail;
	class Node{
		Object data;
		Node next;
		public Node(Object data) {
			this.data = data;
			next = null;
		}
	}
	
	
	//Add First
	void addFirst(Object data) {
	Node node = new Node(data); //node = [B,null] //node = [A,null]  //node = [C, null]
	if(head == null) {
		head = node;
		head.next = head;
		tail = head;
	}else {
		node.next = head; //before head we are placing the node
		tail.next = node; //making tail next node as current node
		head = node;  //updating the head variable with current node.
	}
	}
	
	
	
	//print data

	void printData() {
		Node i = head; //C
		while(i != null) { //C != null //A != null  // B != null
			System.out.print(i.data + " -> "); //C -> A -> B ->
			i = i.next; //i = A //i = B //i = C
			if( i == head) { //A != head, //B != C, // C == head( i == null) cause break the loop
				i = null;
			}
		}
		System.out.println();
	}
	
	
	
	
	//Add Last - My solution
    //Node = E
	//list = C A B
	//C A B E
	/*
	void addLast(Object data) {
		Node node = new Node(data);
		tail.next = node;
		node.next = head;
		tail = node;
	}
	*/
	
	//Add Last - Mentor solution
	void addLast(Object data) {
		Node node = new Node(data);
		if(head == null) {
			head = node;
			head.next = head;
			tail = node;
			return;
		}
		node.next = head;
		tail.next = node;
		tail = node;
	}
	
	public static void main(String[] args) {
		CSLinkedList_addLast csl = new CSLinkedList_addLast();
		
		csl.addFirst("B");
		csl.addFirst("A");
		csl.addFirst("C");
		
		//Lets print the data
		csl.printData();
		
		//Lets implement the add last
		csl.addLast("E");
		csl.printData();
		
	}






	
}
