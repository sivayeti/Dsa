package DS_LinkedList.Day_19;
import java.util.*;

public class CSLinkedList_addFirst {

	Node head;
	Node tail;
	
	class Node{
		Object data;
		Node next;
		public Node(Object data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	//Add First
	void addFirst(Object data) {
		Node node = new Node(data); //node = [B, null], node = [A,null]
		if(head == null) {
			head = node;
		    head.next = head;
		    tail = head;
		    return;
		}
		
		
		node.next = head; //before head we are placing the node or next to the node we are placing head
		tail.next = node; //whatever the existed tail, it will be connects next node as current node.
	    head = node; //head variable is updated with current node.
	    
	}
	
	
	
	
	//print data
    void printData() {
		Node i = head;  //csl = A -> B
		while(i != null) { //when i has tail, then i.next returns head breaks the loop
			
			System.out.print(i.data + " -> "); //A -> B -> 
			i = i.next; //i = B, i = A
			if(i == head) { // B != head, A==head (i = null) and causes break the loop
				i = null;
			}
		}
		System.out.println();
	}

	
	public static void main(String[] args) {
		CSLinkedList_addFirst csl = new CSLinkedList_addFirst();
		
		//Lets add the data first
		csl.addFirst("B");
		csl.addFirst("A");
		
		csl.printData();
	}

	


	
}
