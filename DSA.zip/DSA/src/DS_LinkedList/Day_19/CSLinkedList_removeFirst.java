package DS_LinkedList.Day_19;
import java.util.*;

public class CSLinkedList_removeFirst {

	Node head;
	Node tail;
	class Node{
		Object data;
		Node next;
		public Node(Object data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	
	//Add First 

    void addFirst(Object data) {
    	Node node = new Node(data); //node = [B] //node = [A]
    	if(head == null) {
    		head = node; //[B] 
    		head.next = head;
    		tail = head; //[B]
    	}
    	
    	node.next = head;
    	tail.next = node;
    	head = node;
		
	}
	
    
    
    //print data
    void printData() {
		Node i = head; //i = B
		while(i != null) { //B != null //A != null
			System.out.print(i.data + " -> "); //B -> A
			i = i.next; //i = A //i = B
			if(i == head) {//A != head //B == head(i = null) and causes loop break
				i = null;
			}
		}
		System.out.println();
	}
    
    
    
    
    //Add Last
    void addLast(Object data) {
		Node node = new Node(data);
		tail.next = node;
		node.next = head;
		tail = node;
	}
    
    
    
    //Remove First - My Solution
    /*
    void removeFirst() {
    	head = head.next;
    	tail.next = head;
	}
	*/
    
    //Remove First - Mentor Solution
    void removeFirst() {
    	if(head == null) {
    		System.out.println("Node is empty");
    	}else if(head.next == head) {
    		head = null;
    	}else {
    		head = head.next;
    		tail.next = head;
    	}
    }
    
	public static void main(String[] args) {
		CSLinkedList_removeFirst csl = new CSLinkedList_removeFirst();
		
		csl.addFirst("B");
		csl.addFirst("A");
		
		csl.printData();
		csl.addLast("C");
		csl.printData();
		
		//Lets implement the remove First
		csl.removeFirst();
		csl.printData();
		
	}



	



	

	


}
