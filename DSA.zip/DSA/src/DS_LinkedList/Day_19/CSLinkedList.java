package DS_LinkedList.Day_19;
import java.util.*;

public class CSLinkedList {

	Node head;
	Node tail;
	class Node{
		Object data;
		Node next;
		public Node(Object data) {
			this.data = data;
			next = null;
		}
	}
	
	
	public static void main(String[] args) {
	CSLinkedList csl = new CSLinkedList();
	
	//In normal LinkedList, we can reference the end node, and perform the addLast(), removeLast()
	//But in Circular Linked List, there is no end node, so for that we have to reference or track the end node by using ‘tail’ variable, based on these tail node we can perform the addLast(), removeLast().

	
	
	//In these way we can implement the Circular Single Linked List
	}
	
}
