package DS_LinkedList.Day_19;
import java.util.*;

public class CSLinkedList_removeLast {

	Node head;
	Node tail;
	class Node{
		Object data;
		Node next;
		public Node(Object data) {
			this.data = data;
			next = null;
		}
	}
	
	
	
	
	//Add First
	void addFirst(Object data) {
		Node node = new Node(data); //node = [B] //node = [A]
		
		if(head == null) {
			head = node;
			head.next = head;
			tail = node;
		}
		node.next = head;
		tail.next = node;
		head = node;
	}
	
	
	
	//print data
	void printData() {
		Node i = head; //i = A
		while(i != null) { //A != null //B != null
			System.out.print(i.data + " -> "); //A -> B ->
			i = i.next; //i = B //i = A
			if(i == head) { //B!=head //A == head (i = null) causes loop break.
				i = null;
			}
		}
		System.out.println();
	}
	
	
	//Add last
	void addLast(Object data) {
		Node node = new Node(data); //node = [c]
		tail.next = node;
		node.next = head;
		tail = node;
	}
	
	
	
	//Remove First
	
	void removeFirst() {
		head = head.next;
		tail.next = head;
	}

	 
	//Remove Last - My Solution
	/*
	void removeLast() {
		Node i = head;
		while(i.next != tail) { //The loop breaks when i has the previous node of tail, then i.next returns tail and causes break of loop
			i = i.next; 
		}
		
		Node prev_node_tail = i;
		prev_node_tail.next = head;
		tail.next = null;
		tail = prev_node_tail;
	}
	*/
	
	//Remove Last - Mentor solution
	void removeLast() {
		if(head == null) {
			System.out.println("Node is Empty");
		}else if(head.next == head) {
			head = null;
		}else {
			Node node = head;
			while(node.next != tail) {
				node = node.next;
			}
			
			node.next = head;
			tail = node;
			
		}
	}
	
	
	
	public static void main(String[] args) {
		CSLinkedList_removeLast csl = new CSLinkedList_removeLast();
		
		csl.addFirst("B");
		csl.addFirst("A");
		
		csl.printData();
		
		csl.addLast("C");
		csl.printData();
		
		csl.removeFirst();
		csl.printData();
		
		csl.removeLast();
		csl.printData();
	}



	



	


	



	



	
}
