package DS_LinkedList.Day_18;
import java.util.*;

public class DoublyLinkedList_addLast {

	Node head;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = null;
			this.data = data;
			next = null;
		}
	}
	
	
    //Add First
	void addFirst(Object data) {
		Node node = new Node(data); //node = [null,BSK,null]  //node = [null,Mahi,null]
		if(head == null) {
			head = node;
			//return;
		}else {
		node.next = head;
		head.prev = node;
		head = node;
		}
		
	}
	
	
	
	
	//print data
    void print() {
		Node i = head; //i = [Mahi], i = [BSK]
		while(i != null) {
			System.out.print(i.data + " -> "); //Mahi -> BSK ->
			i = i.next; //i = BSK, i = null
		}
		System.out.println();
		
		//lets retrive the linked list data from backward
		//for that we want last node
		Node last = head;
		Node j = head;
		while(j != null) {
			last = j;
			j = j.next; //when j has last node, then j.next retrievs null, and breaks loop
		} //last holds last node value
		//By using these last node we can print the data from backward
		
		Node k = last;
		while(k != null) {
			System.out.print(k.data + " <- ");
			k = k.prev;//when k reaches to head, then k.prev returns null value and causes break of loop
		}
		System.out.println();
		
	}

	
    
    
    //Add data at last
    void addLast(Object data) {
		//for these we have to find the last node, and we have to store node in lastnode.next and lastnode in node.prev, as well node.next will be null when we create it.
    	Node node = new Node(data); //node = [null, Hello, null]
    	
    	/*
    	//lets find the last node
    	Node last = head;
    	Node j = head;
    	while(j != null) {
    		last = j;
    		j = j.next; //when j holds the last, then j.next returns null value., so before these line we can store the j (which holds the last node) into last variable
    	} //last variable holds the last node value
    	*/
    	
    	//Another logic to find the last node
    	Node last = head;
    	while(last.next != null) { //whenever last variable contains last node then last.next == null breaks loop and remains last varaible holding last node.
    		last = last.next;
    		} //last variable contains last node
    	
    	
    	last.next = node;
    	node.prev = last;
	}

    
    
	public static void main(String[] args) {
		
		DoublyLinkedList_addLast dd = new DoublyLinkedList_addLast();
		
		dd.addFirst("BSK");
		
		dd.addFirst("Mahi");
		
		dd.addFirst("Hari");
		dd.print();
		
		//Lets perform the addLast
		dd.addLast("Hello");
		dd.print();
	}




	

	



}
