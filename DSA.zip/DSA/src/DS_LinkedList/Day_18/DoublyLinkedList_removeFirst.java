package DS_LinkedList.Day_18;
import java.util.*;

public class DoublyLinkedList_removeFirst {

	Node head;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev  = null;
			this.data = data;
			next = null;
		}
	}
	
	//add First
    void addFirst(Object data) {
	Node node = new Node(data); //node = [null, BSK, null] , //node = [null,Mahi,null]
	if(head == null) {
		head = node;
	}else {
		head.prev = node;
		node.next = head;
		head =node;
	}
		
    
	}
    
    
    
    
    //print the data
    void print() {
     Node i = head;
     Node last = head;
     while(i != null) {
    	 System.out.print(i.data + " -> ");
    	 last = i; //stores last node
    	 i = i.next;
     }
     System.out.println();
		
     //Lets print the data from backward of list
     Node j = last;
     while(j != null) {
    	 System.out.print(j.data + " <- ");
    	 j = j.prev; //when j reaches head node, then only j.prev returns null and causes break loop.
    	 
     }
     System.out.println();
	}
    
    
    
    //Add last
    void addLast(Object data) {
	Node node = new Node(data); //node = [null, Vir, null]
	//to add at last we have to find the last node
	
	//logic to find the last node
	Node last = head;
	while(last.next != null) { //when last holds last node, then only last.node returns null and break the loop and remains last variable holds the last node value.
		last = last.next;
	}
	//last variable has last node value.
	
	last.next = node;
	node.prev = last;
		
	}
	
    
    
    
    //remove First -- My solution
    /*
    void removeFirst() {
	//Here we have to remove the head node, update the head variable with 2nd node, which is previously stored in head.next.
    	
    	head = head.next;
    	head.prev = null;
    	
		
	}*/
    
    //remove First - Mentor solution
    void removeFirst() {
    	Node node = head;
    	if(node == null) {
    		System.out.print("Node is empty");
    	}else if(node.next == null) { //means only one node is there
    	    head = null;
    	}else {
    		head = node.next; //head = head.next (updating the head variable with its next node)
    		head.prev = null; //the second node which we make head , thats previous node we are making null.
    	}
    }
    
	public static void main(String[] args) {
		DoublyLinkedList_removeFirst dd = new DoublyLinkedList_removeFirst();
		
		dd.addFirst("BSK");
		dd.addFirst("Mahi");
		dd.addFirst("Hari");
		
		dd.addLast("Vir");
		dd.print();
		
		
		//Lets perform the removeFirst
		dd.removeFirst();
		dd.print();
	}




	


	


    
}
