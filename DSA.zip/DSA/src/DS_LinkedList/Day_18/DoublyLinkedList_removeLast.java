package DS_LinkedList.Day_18;
import java.util.*;

public class DoublyLinkedList_removeLast {

	Node head;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = null;
			this.data = data;
			next = null;
		}
	}
	
	
	
	//add first
	void addFirst(Object data) {
		Node node = new Node(data); //node = [null,BSK,null]   //node = [null, Mahi, null]
		if(head ==  null) {
			head = node; //head = [null, BSK, null]
			return;
		}
		node.next = head;
		head.prev = node;
		head = node;
		
	}
	
	
	
	//print data
    void print() {
    	Node i = head;
    	Node last = head;
    	while( i != null) {
    		System.out.print(i.data + " -> ");
    		last = i;
    		i = i.next; //when i reaches last node, then i.next returns null and causes to break loop.
    	}
    	System.out.println();
    	
    	//Lets print the data from backward
    	//for that we need last node
    	Node j = last;
    	while(j != null) {
    		System.out.print(j.data + " <- ");
    		j = j.prev; //when j reaches the head, then j.prev returns null and breaks the loop.
    	}
    	System.out.println();
		
	}
	
	
    
    //add Last
    void addLast(Object data) {
    	Node node = new Node(data); //node = [null, "Hari", null]
    	//for these we need to find the last node
    	
    	Node i = head;
    	while(i.next != null) { //i.next returns null and breaks loop , when i holds the last node value, and remains i hold the last node.
    		i = i.next;
    	}
    	
    	i.next = node;
    	node.prev = i;
    	
		
	}
	
	
    
    //remove First
    void removeFirst() {
    	
    	head = head.next; //making second node as head
    	head.prev = null; //making updated node prev node stores null.
		
	}
	
    
    
    //remove last - My solution
    /*
    void removeLast() {
	//for these we need to find the previous node to last node
    Node last = head;
    Node prev_last = head;
    while(last.next != null) { //When last.next returns null breaks while condition, these happens when last have the last node value.
    	prev_last = last; //previous node last node will be stored here.
    	last = last.next; //when here last stores the last node value , then in before these line last has the last node previous one.
    }
    
    prev_last.next = null;
    //last.prev = null;
		
	}
	*/
    
    
    
    //remove last - Mentor solution
    void removeLast() {
    	Node node = head;
    	if(node == null) {
    		System.out.println("Node is Empty");
    	}else if(node.next == null) {
    		head = null;
    	}else {
    		Node secLast = head;
    		while(node.next != null) {
    			secLast = node;
    			node = node.next;
    		}
    		//System.out.println(secLast.data);
    		
    		secLast.next = null; //which ensures to dereference the last element;
    	}
    }
    
    
    
    
    
	public static void main(String[] args) {
		
		DoublyLinkedList_removeLast dd = new DoublyLinkedList_removeLast();
		
		dd.addFirst("BSK");
		dd.addFirst("Mahi"); 
		dd.addFirst("Hari");
		
		dd.addLast("Hello");
		dd.print();
		dd.removeFirst();
		dd.print();
		
		//Lets implement the removeLast
		dd.removeLast();
		dd.print();
	}



	



	



	

}


