package DS_LinkedList.Day_18;
import java.util.*;

public class DoublyLinkedList_addFirst {

	Node head; //Linked list should have head node , define the head node of Node data type(class is a user defined data type).
	class Node{
		Node prev;
		Object data; //Any type of data Linked List can accept i.e int,string, (As we specified here Object data type, it can accept any data int,string)
		Node next;
		//By using the constructor we can initialize the values to the above 3 data members
		public Node(Object data) {
			prev = null;
			this.data = data;
			next = null;
		}
		
	}
	
	
	//Add First
	void addFirst(Object data) {
		Node node = new Node(data); //Node created , node = [null,BSK, null]    //Node created , node = [null, Mahi, null]
		if(head == null) {
			head = node; //head = [null, BSK, null]
			return;
		}
		node.next = head; //store in node.next with head value
		head.prev = node; //store in head.prev with head value.
		head = node; //update the head variable with the created node.As our function executes for addFirst().i.e place the created node at head.
		
		
	}
	
	
	//print data
	 void print() {
			Node i = head; //i = [null,Mahi,BSK]
			while(i != null) { //Mahi != null, Mahi.next(BSK) != null, BSK.next(null) != null (breaks loop)
				System.out.print(i.data + " -> "); //Mahi -> BSK -> 
				i = i.next; //i = BSK //i = BSK.next(null)
			}
			System.out.println();
			
			//In these way we can print the data in forward way.
			
			
			
			
			
			//Lets print the data in back ward way.
			Node last = head; //for that we have to store the last node in last variable.
			Node i1 = head;
			while(i1 != null) {
				last = i1; //we are storing the last node in last variable, in next line i1 which has last node, then i1.next return null into i1, and then while loop breaks, and left last variable holding last node.
				i1 = i1.next; //whenever i1.next(at these case i1 holds last node value) becomes null and null stores in i1
			} //In these way we can find the last node.
			
			
			//By using these last node we can access and retrieval the data in backward direction
			Node j = last;
			while(j != null) {
				System.out.print(j.data + " <- ");
				j = j.prev; //when j reaches head, j.prev returns null to j variable, and causes loop break, in these way we can traverse in backward direction in double linked list.
			}
			
			
		}
	 
	 
	 
	public static void main(String[] args) {
		DoublyLinkedList_addFirst dd = new DoublyLinkedList_addFirst();
		
		//Every data is stored in node, we have to define a data type node by using class concept, which can stores, previous node value which is of same Node data type, current data of the node, next node value by using class concept we have to define the Node datatype, which can stores these 3 data.
		
		//In these way DoublyLinkedList wil be created.
		
		//Lets see how we can add the Data First to Doubly linked list
		dd.addFirst("Bsk"); //These will store in head Node
		
		dd.addFirst("Mahi"); //These  will add before head and become head based on our functionality code
		
		dd.addFirst("Hari");
		//Lets print the DD
		dd.print();
		
		
	}
   
	
}
