package DS_LinkedList.Day_18;
import java.util.*;

public class DoublyLinkedList {

	Node head; //Linked list should have head node , define the head node of Node data type(class is a user defined data type).
	class Node{
		Node prev;
		Object data; //Any type of data Linked List can accept i.e int,string,object
		Node next;
		//By using the constructor we can initialize the values to the above 3 data members
		public Node(Object data) {
			prev = null;
			this.data = data;
			next = null;
		}
		
	}
	public static void main(String[] args) {
		DoublyLinkedList dd = new DoublyLinkedList();
		
		//Every data is stored in node, we have to define a data type node by using class concept, which can stores, previous node value which is of same Node data type, current data of the node, next node value by using class concept we have to define the Node datatype, which can stores these 3 data.
		
		//In these way DoublyLinkedList wil be created.
	}
}
