package DS_LinkedList.Day_20;

public class CDLinkedList_removeLast {

	Node head;
	Node tail;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = tail;
			this.data = data;
			next = head;
		}
	}
	
	
	
	//Add First

	void addFirst(Object data) {
		Node node = new Node(data); //node = [tail(null), B, head(null)],    //node = [tail(B), A, head(B)]
		if(head == null) {
			head = node;
			tail = node;
			node.next = node;
			node.prev = node;
			return;
		}
		head.prev = node;
		tail.next = node;
		head = node;
		
	}
	
	
	
	//print data
	void printData() { //list = C -> A -> B ->
		Node i = head;// i = C
		while(i != null) { //i == C //i == A //i == B
			System.out.print(i.data + " -> "); //C -> A -> B ->
			i = i.next; //i = A //i = B //i = C
			if(i == head) {
				 i = null;
			}
			
			
		}
		System.out.println();
		
		//lets print the nodes in backward
		Node j = tail;
		while(j != null) { //j = B //j = A //j = C
			System.out.print(j.data + " <- "); //B <- A <- C <-
			j = j.prev; //j = A //j = C //B
			if(j == tail) {
				j = null;
			}
			
		}
		System.out.println();
	}
	
	
	//Add Last
	void addLast(Object data) {
		Node node = new Node(data); // node = [prev(tail), E, next(head)]
		
		tail.next = node;
		head.prev = node;
		tail = node;
		
	}
	
	
	//removeFirst
	void removeFirst() {
		head = head.next;
		tail.next = head;
		head.prev = tail;
	}
	
	
	//remove Last - My soultion
	/*
	void removeLast() {
		tail = tail.prev;
		tail.next = head;
		head.prev = tail;
	}
	*/
	
	//removeLast - Mentor solution
	void removeLast() {
		if(head == null) {
			System.out.println("Node is empty");
		}else if(head.next == head) {
			head = null;
			tail = null;
		}else {
			tail = tail.prev;
			tail.next = head;
			head.prev = tail;
		}
	}
	
	
	public static void main(String[] args) {
		CDLinkedList_removeLast cdl = new CDLinkedList_removeLast();
	
	    cdl.addFirst("B");
	    cdl.addFirst("A");
	    cdl.addFirst("C");
	    
	    cdl.printData();
	    
	    cdl.addLast("E");
	    cdl.printData();
	    
	    
	    cdl.removeFirst();
	    cdl.printData();
	    
	    cdl.removeLast();
	    cdl.printData();
	}



	



	



	



}

