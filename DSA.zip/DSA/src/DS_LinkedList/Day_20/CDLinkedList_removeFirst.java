package DS_LinkedList.Day_20;

public class CDLinkedList_removeFirst {

	Node head;
	Node tail;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = tail;
			this.data = data;
			next = head;
		}
	}
	
	
	
	//Add First
    void addFirst(Object data) {
	Node node = new Node(data); //node = [null, B, null] => head = [B, B,B]   //node = [tail(B), A, head(B)]    //node = [tail(B), C, head(A)]
	if(head == null) {
		head = node; //head = [B]
		tail = node; //tail = [B]
		node.next = node;
		node.prev = node;
		return;
	}
	
	head.prev = node;
	tail.next = node;
	head = node;
	
	
    }
    
    
    
    
    
    //Print Data
    
    void printData() { //cdl = C -> A -> B ->
		Node i = head;
		while( i != null) { //C != null //A != null //B != null
			System.out.print(i.data + " -> "); //C -> A -> B ->
			i = i.next; //i = A //i = B //i = C
			while( i == head) {
				i = null;
			}
		} 
		System.out.println();
		
		
		
		//Lets print the data from backward
		
		Node j = tail;
		while(j != null) { //B != Null  //A != null //C != null
			System.out.print(j.data + " <- "); //B <- A <- C <-
			j = j.prev; //j = A  //j = C //j = B
			if(j == tail) {
				j = null;
			}
			
		}
		System.out.println();
		
	}

    
    //Add Last
    void addLast(Object data) {
    	Node node = new Node(data); //node = [prev(tail), E, next(head)]
    	
    	tail.next = node;
    	head.prev = node;
    	tail = node;
	}
    
    
    //remove first - My soultion
    /*
    void removeFirst() {
		head = head.next; 
		tail.next = head;
		head.prev = tail;
	  }
   */ 
    
    //remove First - Mentor solution
   
    void removeFirst() {
    	if(head == null) {
    		System.out.println("Node is empty");
    	}else if(head.next == head) {
    		head = null;
    		tail = null;
    	}else {
    		head = head.next;
    		tail.next  = head;
    		head.prev = tail;
    		
    	}
    }
    
	public static void main(String[] args0) {
		CDLinkedList_removeFirst cdl = new CDLinkedList_removeFirst();
		
		cdl.addFirst("B");
		cdl.addFirst("A");
		cdl.addFirst("C");
		
		
		//cdl.printData();
		cdl.addLast("E");
		//cdl.printData();
		
		cdl.removeFirst();
		cdl.printData();
	}





	
	
}
