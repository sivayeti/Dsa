package DS_LinkedList.Day_20;

public class CDLinkedList_addLast {

	Node head;
	Node tail;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = tail;
			this.data = data;
			next = head;
		}
	}
	
	
	//Add First
	void addFirst(Object data) {
		Node node = new Node(data); //node = [tail, B, head] //as it is first node head ,tail= null    ==> [B, B,B]     //node = [tail(B), A, next(B)]
		if(head == null) {
			head = node;
			tail = node;
			node.next = node;
			node.prev = node;
			return;
		}
		head.prev = node;
		tail.next = node;
		head = node;
	}
	
	
	
	//print data
	void printData() {
		Node i = head;
		while( i != null) {
			System.out.print(i.data + " -> ");
			i = i.next;
			if(i == head) {
				i = null;
			}
		}
		System.out.println();
		
		Node j = tail;
		while( j != null) {
			System.out.print(j.data + " <- ");
			j = j.prev;
			if(j == tail) {
				j = null;
			}
		}
		System.out.println();
	}
	
	
	
	
	//Add Last -M y solution

	/*
	void addLast(Object data) {
		Node node = new Node(data); //[prev, E, next] => [B, E, C]
		tail.next =  node;
		head.prev = node;
		tail = node;
	}
	*/
	

	
	//Add First and Add last both are same because it is circular doubly linked list. 
	//Add First we have to update the head with node, Add Last we have to update the tail with node.
	
	
	
	//Add Last
	void addLast(Object data) {
		Node node = new Node(data);
		if(head == null) {
			head = node;
			tail = node;
			node.next = node;
			node.prev = node;
			return;
		}
		tail.next = node;
	    head.prev = node;
	    tail = node;
	}
	
	
	
	public static void main(String[] args) {
		CDLinkedList_addLast cdl = new CDLinkedList_addLast();
		
		cdl.addFirst("B");
		cdl.addFirst("A");
		cdl.addFirst("C");
		
		cdl.printData();
		
		cdl.addLast("E");
		cdl.printData();
		
	}



	



	
}
