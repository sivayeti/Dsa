package DS_LinkedList.Day_20;

public class CDLinkedList_addFirst {

    Node head;
    Node tail;
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = tail;
			this.data = data;
			next = head;
		}
	}
	
	
	
	
	//Add First
	void addFirst(Object data) {
		Node node = new Node(data); //node = [tail,B, head];  //for first node head,tail = null //node = [ tail, A, head] => [B, A, B]
        if(head == null) {
        	head = node;
        	tail = node;
        	node.next = node;
        	node.prev = node;
        	return;
        }
        head.prev = node;
        tail.next = node;
        head = node;
        
	}
	
	
	
	//print data
	void printData() {
		Node i = head; //i = C
		while( i != null) { //C != null  //A != null //B != null
			System.out.print(i.data + " -> "); //C -> A -> B ->
			i = i.next; //i = A //i = B //i = C
			//As it is circular linked list, it will runs unlimited loop, so we have to break the loop when rotation starts from head and after reaching tail.we have to break the loop(i.e when we reached to head again then rotation over the linked list is done). 
			if(i == head) { //A != head //B != head //C == head (i == null) which breaks the loop
				i = null;
			}
		}
		System.out.println();
		
		//Lets traverse over the linked list from backward
		Node j = tail; //B
		while( j != null) { //B != null //A != null //C != null
			System.out.print(j.data + " <- "); //B <- A <- C
			j  = j.prev; //A //C //B
			//As we start the traversal from tail, when we reached the head our traversal completes, we have to break the loop,
			//for that j.prev returns tail, when j = head, at these time j.prev returns tail, so we make j = null which causes break the loop.
			if(j == tail) {  //A != tail //C != tail //B == tail( j == null) causes break the loop.
				j = null;
			}
		}
		System.out.println();
	}
	
	
	public static void main(String[] args) {
	CDLinkedList_addFirst cdl = new CDLinkedList_addFirst();
	
	//Lets add the node at first
	cdl.addFirst("B");
	cdl.addFirst("A");
	cdl.addFirst("C");
	
	
	//Lets print the data
	cdl.printData();
	}

	


	
	
	
}
