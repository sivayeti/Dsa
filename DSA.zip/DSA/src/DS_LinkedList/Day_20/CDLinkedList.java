package DS_LinkedList.Day_20;

public class CDLinkedList {

	Node head;
	Node tail; //track and monitor the end node.
	class Node{
		Node prev;
		Object data;
		Node next;
		public Node(Object data) {
			prev = tail;
			this.data = data;
			next = head;
		}
	}
	
	
	CDLinkedList cdl = new CDLinkedList();
	//In these way we will implement the Circular Doubly Linked List.
}
