package DS_LinkedList;
import java.util.*;

public class LinkedList_RemoveFirst {

	Node head;
	class Node{
		String data;
		Node next;
		
		public Node(String data) {
			this.data=data;
			this.next=null;
		}
	}
	
	//Add Node at First of Linked List
	 void addFirst(String data) {
		Node node = new Node(data);
		if(head == null) {
			head = node; //if head is empty, then we have to assign the created node to empty head variable which is of type Node class.
		    return;  //As head variable is empty, we have assigned the current created node to head, then we have to stop the function here, otherwise it undergoes looping.
		}
		node.next = head; //current head should have to be stored next to the current created node 'node'
		head = node; //head variable should update with current created node, these ensures the created node to place at begining of linked list.
			
		}
	
	 
	 
	 //Print the Liknked List data

		void printList() {
			
			Node list = head; //store the head in list variable which is of data type class Node
			while(list!=null) { //As head is having value and not equal to null then enters into loop
				System.out.print(list.data + " -> ");
				list = list.next; //if head is only single node in list, then list.next which is of Node data type can stored with null value, and causes breaks out from loop
				//otherwise, if two nodes are there in the linked list, then head.next i.e list.next stores the next node data , that is stored in 'list' variable , then iterate again in while loop body, and prints the next node data.
			}
			System.out.println();
		}
		
		
		/*
		//Remove the First Node of Linked List
		void removeFirst(LinkedList_RemoveFirst list) {
			Node temp = list.head.next; //Hi
			head.next = null; //breaking the connectionf from 'Hello' to 'Hi' by 'Hello' -> null,,   'Hi'(temp)
			head = temp;
			
		}
		*/
		//Remove First data. -- My solution
		/*
		void removeFirst() {
			Node temp = head.next; //Hi (Hello -> Hi -> Null
			head.next = null; //breaking the first node connection with its next node, i.e removing the head node from linked list. (Hello -> Null)
			head = temp; //then update the second node to store in 'head' variable.
			
		}
		*/
		//Remove First data -- Mentor solution
		void removeFirst() {  
			if(head == null) {
				System.out.println("List is Empty");
			}else {
				head = head.next; //head = 'Hi' (list = 'Hello'(head) --> 'Hi' --> null)
			    //we updated the head variable with second element of list,  Here first node will become dereferenced, or removed from the list.
			}
		}
		
		
	public static void main(String[] args) {
		LinkedList_RemoveFirst list = new LinkedList_RemoveFirst();
		
		//As Linked List stores the data in Node format, define a Node class data type, which can stores the data, and next data.
		list.addFirst("Hi");
		//These will be stored in head variable of linked list
		
		list.addFirst("Hello");
		//These becomes head based on our functionality code, and the above node will become the next node to these head node.
		
		list.addFirst("How");
		
		//Lets see how we can remove the First Node
		//list.removeFirst(list);
		
		
		list.printList();
		
		//list.removeFirst(list);
		list.removeFirst();
		
		list.printList();
	}



		



	



	
}
