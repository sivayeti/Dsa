package rec_proj.Day_05;
import java.util.*;

public class rec_10 {
	//10.write a java program to return Nth Fibonacci number by using recursion?
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int n1 = fibonacci(n);
		System.out.println(n1);
	}

	
	/*
	private static int fibonacci(int n) {
		// TODO Auto-generated method stub
		return findFibonacci(n,0,1);
		
	}


	//fibonacci: 0  ,1   ,1   ,2    ,3 ,  5
	          //1st, 2nd , 3rd,4th, 5th, 6th term
                                     // 5     0,      1     //let n = 3(fib = 1)
	private static int findFibonacci(int n, int i, int j) { //let n = 5
		// TODO Auto-generated method stub
		int k = 0;
		if(n == 2) {
			return j;
		}
		n = n -1; //n = 2                  //n = 4   //n = 3   //n = 2
		k = j; //k = 1                     //k = 1   //k = 1   //k = 2
		j = i+j; //j = 1                   //j = 1    //j= 2   //j = 3
		return findFibonacci(n, k ,j);
		                  //2, 1,1         //4,1,1    //3,1,2  //2,2,3
	}
	
	*/
	
	
	
	
	

	//fibonacci: 0  ,1   ,1   ,2    ,3 ,  5
	          //1st, 2nd , 3rd,4th, 5th, 6th term
	
	//mentor's solution
	private static int fibonacci(int n) { //5
		if(n==1) {
			return 0;
		}
		if(n==2) {
			return 1;
		}
		
		return fibonacci(n-1)     +   fibonacci(n-2);  //fibonacci rule: particular element value = sum of its two previous elements
	          //fib(4)            +    fib(3)       
      //fib(3)  +     fib(2)      +    fib(2)        +  fib(1)
//fib(2)+fib(1) +       1         +       1          +    0
// 1    + 0     +                 +      
       
	
	}
	
	
	

}
