package rec_proj.Day_05;
import java.util.*;

public class rec_12 {
   //12.Write a java program to check the string is palindrome or not
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		boolean res = reverse(s);
		if(res==true) {
			System.out.println("String is palindrome");
		}else {
			System.out.println("String is not a palindrome");
		}
	}

	
	//My solution
	
	private static boolean reverse(String s) {
		// TODO Auto-generated method stub
		
		return rever(s,"",0);
	}


	private static boolean rever(String s, String rev, int i ) {
		// TODO Auto-generated method stub
		if(i == s.length()) {
			System.out.println(rev);
			System.out.println(s);
			
		  
			return s.equals(rev);
		}
		
		return rever(s,rev+s.charAt(s.length()-1-i),i+1);
		
	}
}
