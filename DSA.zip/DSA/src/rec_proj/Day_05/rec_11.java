package rec_proj.Day_05;
import java.util.*;

public class rec_11 {
       //11.Write a java program to reverse the string by using recursion?
	   public static void main(String[] args) {
		   
		   Scanner sc = new Scanner(System.in);
		   
		   String s = sc.nextLine();
		   
		   //String s1 = revString(s);
		   //System.out.println(s1);
		   
		   
		   //int i = 0;
		   //String s1 = revString(s, i);
		   //System.out.println(s1);
		   
		   //String ret = reverse(s,s.length()-1,"");
		   String ret = reverse(s);
		   System.out.println(ret);
		   
		   
	   }

	

	

	   /*
	private static String revString(String s) {
		// TODO Auto-generated method stub
		String r = "";
		for(int i = 0; i < s.length(); i++) {
			//s = ant 012
			//r = tna 210
			//    
			
			r += s.charAt(s.length()-1-i);
		}
		return r;
	} */
	   
	   
	   
	  
	   //My solution
	   /*
	   private static String revString(String s, int i) {
			
		   
		    if(i == s.length()) {
		    	return "";
		    }
			return s.charAt(s.length()-1-i)+ revString(s, i+1);
		}
		
	   */
	   
	   
	   
	   
	   //Mentors solution
	   
	   private static String reverse(String s) {
		// TODO Auto-generated method stub
		return rever(s, s.length()-1,"");
	}





	//Mentors solution
	                               //string,endvalueofstring, resultstring
	   private static String rever(String s, int i, String revstring) {
			if(i<0) {  //ant (i=2) //(i=1) //(i=0) //(i=-1)
				       //012
				return revstring;  //tna
			}
			return rever(s,i-1,revstring+s.charAt(i));
			            //ant, 1, ""+s.charAt(2);
			            //ant, 0, t + s.charAt(1);
			            //ant, -1,tn+ s.charAt(0);  ==> tna
			
		}
	   
	   
	   
}
