package rec_proj;
import java.util.*;

//1.program to print the N to one numbers by using recurssion.
public class Main {

	
		
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		
		printNToOne(n);
		System.out.println("***********");
		int n1 = sc.nextInt();
		int i = 1;
		//printOneToN(n1, i); 
		//Another way
		printOneToN(n1);
		System.out.println("************");
		int n2 = sc.nextInt();
		factorial(n2);
		 System.out.println(res);
		
	}
	
	
	//If a method call itself or calls inside its body is called recurssion.
			//It can be used alternative to loops.
	     public static void printNToOne(int n) {  //10 //9 //8 //7 //6 //5 //4 //3 //2 //1
				System.out.println(n); //10 //9 //8 //7 //6 //5 //4 //3 //2  //1
				if(n > 1) { //10 > 1 , 9 > 1, 8 > 1 , 7>1, 6>1, 5>1. 4>1, 3>1 , 2>1, 1>1(breaks)
				printNToOne(n-1); //9 8 7 6 5 4 3 2 1
				}		
			}
	
	     
	     /*
			for(int i = 10; i >= 1; i--) {
				sys.out(i)
			}
			for(int i = 1; i < 10; i++) {
				sys.out(i)
			}
			*/
	     
	     
	 //program to print the One to N by using recursion
	     /*
	    public static void printOneToN(int n1,int  i) { //10
	        
	    	System.out.println(i);
	    	if(i < n1) {
	    	printOneToN(n1, i+1);
	    	}
	    }
	    		*/
	     
	     //Another way to print the One to N by using Recursion
	  
	     public static void printOneToN(int n1) { //4 //3 //2 //1 
	    	 if(n1>1) {  //4 > 1 //3>1  //2>1 //1>!(breaks)
	    		 printOneToN(n1-1); //3 //2 //1
	    	 }
	    	 System.out.println(n1); //1
	    	
	     }
	     
	     
	   //Write a program to calculate the factorial of N using recursion?
	     static int res = 1;
	     public static void factorial(int n2) { 
	    	//5! = 5x4x3x2x1
	    	
	    	if(n2>1) {
	        res *= n2;
	    	
	        factorial(n2-1);
	        
	    	}else if(n2==1||n2==0) {
	    		res = res * 1;
	    	}
	    	
	    	//System.out.println(res);
	    }
	     
	    
}

