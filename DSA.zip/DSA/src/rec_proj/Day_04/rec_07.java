package rec_proj.Day_04;
import java.util.*;

public class rec_07 {
    //1.write a program to check whether the number is prime or not by using recursion.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		//String res = primeorNot(n);
		//System.out.println(res);
		boolean b = isPrime(n);
		if(b==true)
			System.out.println("Prime");
		else
			System.out.println("Not Prime");
	}
	
	public static boolean isPrime(int n) {
		
		/*
		boolean res =  false;
		for(int i = 2; i <= n; i++) {
			//A number is prime, if it is not divisible by any other number except 1 & itself., Any number can have its divisors less than its half of its value
			
			if(n % i == 0 && n != i){
				res = false;
				break;
			}else {
				res = true;
		
		}
		
			
	}
		
		return res;
		*/
		
		
		//recursion way
		//primeorNot()
	    return checkPrime(n,2);
	
}
	

	//n will have the divisors under n/2, exceeding n/2 there wil  be no divisors for n, if the numbers from 2 to n/2 are not able to divide the n then is considered as prime.
	
	private static boolean checkPrime(int n, int i) {
		// TODO Auto-generated method stub
		if(n%i==0)
			return false;  //when compiler reaches to return statement ,then that means , the function execution has stopped here.(These may avoids the continous recurring).(exception: these achiveves only when we didn;t recursively calls the function in return statement).
		if(i>n/2) {
			return true;
		}
		
		return checkPrime(n,i+1);
		
	
	}
	
	//In function, whenever the return statement is reached then, the function execution is done, 
	//Here in these recursion functions, whenever the 'return' statement reached, then it will not go recursion call the function it self again.
	
}
