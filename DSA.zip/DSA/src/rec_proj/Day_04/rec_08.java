package rec_proj.Day_04;
import java.util.*;

public class rec_08 {
    //8.write a java program to check the number is palindrome or not.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		//boolean res = palindrome(n);
		
		//if(res == true) {
		//	System.out.println("It is a palindrome");
		//}else {
		//	System.out.println("It is not a palindrome");
		//}
		
		
		
		//int a = palindrome(n,0);
		//if(a == n) {
		//	System.out.println(a + "It is palindrome");
		//}else {
		//	System.out.println(a+ "It is not palindrome");
		//}
		
		
		boolean a = palindrome(n);
		
		if(a == true) {
			System.out.println("It is a palindrome");
		}else {
			System.out.println("It is a not palindrome");
		}
		
	}

	

	

	/*
	private static boolean palindrome(int n) {
		
		String k = Integer.toString(n);
		int l = k.length();
		
	    int q = 0;
	    int a = 0;
	    int n1 = n;
		for(int i = 1; i <= l; i++) { //153 //15 //1
			q = n % 10;  //3 //5 //1
			a = a * 10 + q; //3 //30+5 //350+1 = 351
			n = n / 10; //15 //1 //0
		}
		if(a == n1) {
		    return true;
		}else {
			return false;
		}
		
		
	}
	
	*/
	
	//try with recursion //153     (153, 0)  (15,3) (1,35)   (0, 351)
	/*
	private static int palindrome(int n,int a) {
		// TODO Auto-generated method stub
		 if(n == 0) {
				return a; //when function reaches the return statement , in that return statemnt , if we didn't recursively call the function, that function, ends here.
			}
		
		int r = n % 10; //3  //5 //1  
		int q = n / 10; //15 //1 //0
		
        
		return palindrome(q, a * 10 + r);
		               //15, 3
		               //1, 30+5
		               //0, 350 + 1
		
		
	}
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	                                //153, 0    (1,35)  (0,351)
	private static boolean palindrome(int n) {
		// TODO Auto-generated method stub
		                         //153,0
			return checkPalindrome(n, 0, n); //3rd parameter is, when the 2nd paramteer stores the reverse vaues, then we have to compare the 2nd parameter value to third parameter, to check palindrome or not.
	}





	private static boolean checkPalindrome(int n, int i, int n2) {
		// TODO Auto-generated method stub
		if(n == 0) {
			return i == n2;
		}
		return checkPalindrome(n/10, i * 10 + n % 10, n2);
		
		
	}
	
	
	
	
}
