package rec_proj.Day_04;
import java.util.*;

public class rec_09 {
    //9.write a java program to findout a number is perfect or not by using recursion.
	//every number has its divisors under its half of its values.
	
	//perfect number: a number is perfect number when its divisors sum is equal to itself.
	//eg: 6 has proper divisors 1, 2 and 3, and 1 + 2 + 3 = 6
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		boolean a = isPerfect(n);
		if(a == true) {
			System.out.println("It is a perfect number");
		}else {
			System.out.println("It is not a perfect number");
		}
		
	}

	

	/*
	private static boolean isPerfect(int n) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int i = 1; i <= n/2; i++) {
			if(n % i == 0) {
				sum += i;
			}
		}
		
		return sum==n;
	}
	*/
	
	
	
	//in recurssion way
	private static boolean isPerfect(int n) {
		// TODO Auto-generated method stub
		return checkPerfect(n,0,1);
	}


                            //(original numner, summing of divisors, incrementing the value and used to verify that these is divisor for n or not)
	private static boolean checkPerfect(int n, int sum, int i) {
		// TODO Auto-generated method stub
	    if(n % i == 0) {
	    	sum += i;
	    }
	    if(i > n/2) {
	    	return sum==n;
	    }
	    
		return checkPerfect(n, sum, i+1);
	}
}
