package rec_proj.Day_06;
import java.util.*;

public class rec_14 {

	//14.Write a java program to reverse the Array by using recursion?
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		//int revArr[] = revArray(arr);
		
		
		//int a[] = new int[n];
		//int revArr[]  = revArray(arr,0, a);
		
		int revArr[] = revArray(arr);
		for(int i = 0; i  < revArr.length; i++) {
			System.out.print(revArr[i]+" ");
		}
	}

	

	
	

	/*
	private static int[] revArray(int[] arr) {
		// TODO Auto-generated method stub
		int a[] = new int[arr.length];
		for(int i = 0; i < arr.length; i++) {
			a[i] = arr[arr.length-1-i];
			
			//0123
			//0123 arr
			//3210 a
			
		}
		return a;
	}
	*/
	
	

	//My solution
	/*
	private static int[] revArray(int[] arr) {
		// TODO Auto-generated method stub
		int[] a = new int[arr.length];
		return rev(arr, 0, a);
	}
	
	
	//recursion way
	private static int[] rev(int[] arr, int i ,int[] a) {
		if(i == arr.length) {
			return a;
		}
		a[i] = arr[arr.length-1-i];
		return rev(arr, i+1, a);
	}
	*/
	
	
	
	//Mentors solution 1
   /*
	private static int[] revArray(int[] arr) {
		// TODO Auto-generated method stub
		return rev(arr, new int[arr.length], arr.length-1);
	}


	private static int[] rev(int[] arr, int[] rev, int i) {
		// TODO Auto-generated method stub
		if(i < 0) {
			return rev;
		}
	 	rev[arr.length-1-i] = arr[i];
	  //rev[3-3=0]   = arr[3]
	  //rev[3-2=1]   = arr[2]
	  //rev[3-1=2]   = arr[1]
	  //rev[3-0=3]   = arr[0]
		return rev(arr, rev, i-1);
	}
	*/
	
	
	private static int[] revArray(int[] arr) {
		// TODO Auto-generated method stub
		return revA(arr, new int[arr.length], arr.length-1, 0);
	}


	private static int[] revA(int[] arr, int[] rev, int end_index, int initial_index) {
		// TODO Auto-generated method stub
		if(end_index < 0) {
			return rev;
		}
		rev[initial_index] = arr[end_index];
		
		return revA(arr, rev, end_index-1, initial_index+1);
	}
	
	
	

	
}
