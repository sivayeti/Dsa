package rec_proj.Day_06;
import java.util.*;

public class rec_15 {
    //15.Write a java program to sum of Array by using recursion?
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int sum = sumArray(arr);
		System.out.println(sum);
		
	}

	

	
	/*
	private static int sumArray(int[] arr) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int i = 0; i < arr.length; i++) {
			sum += arr[i];
		}
		return sum;
	}
	*/
	
	
	//My solution
	private static int sumArray(int[] arr) {
		// TODO Auto-generated method stub
		return sumA(arr, 0);
	}

	private static int sumA(int[] arr, int i) {
		// TODO Auto-generated method stub
		if(i == arr.length) {
			return 0;
		}
		return arr[i]+sumA(arr, i+1);
	}
}
