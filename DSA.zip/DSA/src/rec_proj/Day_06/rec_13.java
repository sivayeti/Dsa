package rec_proj.Day_06;
import java.util.*;
public class rec_13 {
   //13.write a java program to find the Big number in java.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		//int k = arrayMax(arr, 0, 0);  //array, int i, int maxi
		//System.out.println(k);
		
		
		int maxi = maxElement(arr);
		System.out.println(maxi);
	}

	


	/*
private static int arrayMax(int[] arr) {
	// TODO Auto-generated method stub
	int maxi = 0;
	for(int i = 0; i < arr.length; i++) {
		//if(arr[i] > maxi) {
		//	maxi = arr[i];
		//}
		maxi = Math.max(maxi, arr[i]);
	}
	return maxi;
}*/
	
//static int maxi = 0;
//static int i = 0;
	/*
private static int arrayMax(int[] arr, int i, int maxi) {
	// TODO Auto-generated method stub
	if(i == arr.length) {
		return maxi;
	}
	maxi = Math.max(maxi, arr[i]);
	return arrayMax(arr, i+1, maxi);
}
	*/
	
	
	
	
	//Mentors solution
	private static int maxElement(int[] arr) {
		// TODO Auto-generated method stub
		return maxim(arr,arr[0],arr.length-1);
	}




	private static int maxim(int[] arr, int maximu, int j) {
		// TODO Auto-generated method stub
		if(j == 0) {
			return maximu;
		}
		if(maximu < arr[j]) {
			maximu = arr[j];
		}
		return maxim(arr, maximu, j-1);
	}
	
}
