package rec_proj.Day_03;
import java.util.*;

public class rec_06 {
    //6.write a program to print reverse of a number by using recurssion
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int a = revNum(n);
		System.out.println(a);
	}
	
	static int a = 0;
	public static int revNum(int n) {
		String s = Integer.toString(n);
		int l = s.length();
		
		/*
		//153
		int q = 0;
		int a = 0;
		for(int i = 1; i<=l; i++) { //153 //15 //1
			q = n % 10 ; //3 //5 //1
			a = a*10 + q; //3 //35 //351 
			n = n / 10; //15 //1 //0
		}
		*/
		//int a = 0;
		int q = 0;
		//153 , l = 3    //15 , l = 2  //1, l = 1
		if(l >= 1 && n != 0) { //(3>=1), (l=2) , (1= 1)
			q = n % 10;  //3 //5  //1
			n = n / 10; //15 //1 //0
			
			a = a * 10 + q; //3 //30+5 //350+1
			
			revNum(n); //15
		}
		 return a;
	}
}
