package rec_proj.Day_03;
import java.util.*;

public class rec_05 {

	//5.write a program to calculate the N to the Power P by using recursion.
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int p = sc.nextInt();
		
		int q = powerNtoP(n, p);
		System.out.println(q);
	}
	
	
	public static int powerNtoP(int n, int p) { //(2,3) //(2,2) //(2,1)
		
		/*
		int a = 1;
		for(int i = 1 ; i <= p; i++) { //(2,3) (p = 1, p=2, p=3
			a = a * n;   // 2, 2*2, 2*2*2
		}
		*/
		
		//int a = 1;
		
		if(p >= 1) {
			 return n * powerNtoP(n, p-1); //2 * 2 * 2 * 1
		}else  {
			return 1;
		}
		
		//Mentor's solution
		/*
		if(p==0)
			return 1;
		return n*powerNtoP(n,p-1);
		*/
	}
}
