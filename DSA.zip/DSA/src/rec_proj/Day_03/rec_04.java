package rec_proj.Day_03;

import java.util.Scanner;

public class rec_04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		//int sum = 0;
		
		//1.program to print the sum of n natural numbers
		/*
		for(int i = 1; i<=n; i++) {
			sum = sum +i;
		}
		
		System.out.println(sum);
		*/
		
		//Lets solve these by using recursion
		
		sumofN(n);
		System.out.println(sum);
		
	}
	
	static int sum = 0;
	public static void sumofN(int n) { //3 //2 //1 //0
		if(n > 0) {   //3 > 0 //2 > 0 //1 > 0 //0>){breaks
		sum = sum + n;  //3 //3+2 //3+2+1
		sumofN(n-1); //2 //1 //0
		}
		 
		//System.out.println(sum);
	}
	
}
