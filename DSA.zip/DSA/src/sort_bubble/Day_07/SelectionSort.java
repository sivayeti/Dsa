package sort_bubble.Day_07;
import java.util.*;

public class SelectionSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int sort[] = selectionSort(arr);
		

		for(int i = 0; i < n; i++) {
			System.out.print(sort[i]+ " ");
		}
		
	}
                                          //9,10,1,6,0,4
	private static int[] selectionSort(int[] arr) {
		// TODO Auto-generated method stub
		
		for(int i = 0; i < arr.length; i++) {
			int in = i;  //variable to store the smallest element index
			for(int j = i+1; j < arr.length; j++) {
				if(arr[j] < arr[in]) {
				    in = j;
				}
			}
			int temp = arr[i]; //9
			arr[i] = arr[in]; //0
			arr[in] = temp; //9
		}
		return arr;
	}
	
}
