package sort_bubble.Day_07;
import java.util.*;

public class QuickSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int ret[] = quickSort(arr, 0, n-1);
		for(int i = 0; i < n; i++) {
			System.out.print(ret[i] + " ");
		}
		
	}

	private static int[] quickSort(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		if(low < high) {
			int pi = partition(arr, low, high);
			quickSort(arr, low, pi-1);
			quickSort(arr, pi+1, high);
			
		}
		return arr;
	}

	
	
	private static int partition(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		int pivot = arr[low];
		int i = low;
		int j = high;
		
		while(i < j) {
			while(arr[i] <= pivot && i < j) {
				i++;
			}
			while(arr[j] > pivot) {
				j--;
			}
			if(i < j){
				int temp = arr[j];
				arr[j] = arr[i];
				arr[i] = temp;
			}
		}
		arr[low] = arr[j];
		arr[j] = pivot;
		
		
		for(int k = low; k <= high; k++) {
			System.out.print(arr[k] + " ");
		}
		System.out.println();
		return j;
		
		
	}

	
	
	
}
