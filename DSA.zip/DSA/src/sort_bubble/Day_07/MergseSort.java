package sort_bubble.Day_07;
import java.util.*;

public class MergseSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int ret[] = mergeSort(arr, 0, n-1); //(arr, low, high)
		for(int i = 0; i < n; i++) {
			System.out.print(ret[i] + " ");
		}
	}

	private static int[] mergeSort(int[] arr, int low, int high) {
		// TODO Auto-generated method stub
		if(low<high) { //At low=high, we don't these division should proceed because, at that time only element is present.
		int mid = (low+high)/2;
		mergeSort(arr,low, mid);
		mergeSort(arr,mid+1,high);
		
		//In these way we can achieve the divison of array into individual ones, and dividing we have to merge , based on their values.
		merge(arr,low,mid,high);
		}
		return arr;
	}

	private static void merge(int[] arr, int low, int mid, int high) {
		// TODO Auto-generated method stub
		int n1 = mid-low+1; //returns the first division of half of array.
		int n2 = high-mid; //returns the second half of array in first divison.
		
		//Define the left and right arrays with these sizes
		int L[] = new int[n1];
		int R[] = new int[n2];
		
		//write the loops to iterate over the left and right arrays
		for(int i = 0; i < n1; i++) {
			L[i] = arr[low+i]; //while iterating the each box in L[i] array i.e L[0],L[1],L[2], at the same time in thesE boxes we are filling the first half of array values respectively by arr[low+i], i.e arr[0+0],arr[0+1],arr[0+2]
		//These array stores, from low to mid array values
		}
		
		for(int j = 0; j < n2; j++) {
			R[j] = arr[mid+1+j]; //while iterating the each box in R[i] array i.e R[0],R[1],R[2], at the same time in thesE boxes we are filling the Second half of array values respectively by arr[low+i], i.e arr[2+1 +0],arr[2+1 +1],arr[2+1+ +2]
		//These array stores from mid+1 to high array values,
		}
		
		int i = 0,j = 0,k=low;
		//Left array, right array starts with 0, thats why i have taken here i=0,j=0;
		//from the low index we have to perform the sort and store the values. (k= low)
		while(i<n1 && j < n2) {
			if(L[i] < R[j]) {
				arr[k] = L[i];
				i++;//As we already, filled the L[0], element into array after comparsion, we can increment the i.
				k++;//One of the array value got filled then we have to iterate over the array, then increment k, which represents the array index.
			}else {
				arr[k] = R[j];
				j++;
				k++;
			}
		}
		//As 3 elements in L[] and 2 elements in R[] are filled then, or vice versa, then it leads to break the while(i<n1&&j<n2) condition, as i or j based on the arrays, got incremeneted to n1 or n2, then the remaining elementcan be placed at last position of array without checking.
		
		while(i < n1) { //In which the array the left element is there , that is still in the codnition i<n1,we can write these two loops for both left and right arrays, as we don't know that which array has left with element, if left array remained with element these loop executes and fill the remained element at last position, if right array remained with one element then below loop executes and ensures to fill the remained element in last postion of array.
		arr[k] = L[i];
		k++;
		i++; //to break the loop and come outside. otherwise, it will undergoes infinite loop.
		}
		
		while(j < n2) {
			arr[k] = R[j];
			j++;
			k++;
		}
		
		
		for(int l = low; l <= high;l++) {
			System.out.print(arr[l]+" ");
		}
		System.out.println();
		
	}
}
