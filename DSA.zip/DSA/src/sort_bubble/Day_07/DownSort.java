package sort_bubble.Day_07;
import java.util.*;

public class DownSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i= 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		
		int sort[] = downSort(arr);
		

		for(int i= 0; i < n; i++) {
			System.out.print(sort[i] + " ");
		}
		
	}

	private static int[] downSort(int[] arr) {
		// TODO Auto-generated method stub
		
		//How many sections (n elements --> n-1 sections)
		//4 elemenst --> 3 sectiosn
		//i = 0,1,2 (n=4, n-1=3, i < 3(0,1,2)
		for(int i = 0; i <arr.length-1; i++) {
			
			//How many swap verification in each section
			for(int j = i+1; j < arr.length; j++) {
				if(arr[j] < arr[i]) {  //8,0,6,3 (arr[1] < arr[0]) => (0 < 8) -> swap
					int temp = arr[i]; //8
					arr[i] = arr[j]; //0
					arr[j] = temp; //8 ===> 0,8,6,3
					        //In next j=2,3 index values also compared with 0 th index, and brings the smallest element to 0 th place,
					        //after these first section, we will take the array from arr[1]--arr[n-1], and same procedure, among these elements we will bring the smallest to first place.
					
				}
			}
		}
		return arr;
	}
}
