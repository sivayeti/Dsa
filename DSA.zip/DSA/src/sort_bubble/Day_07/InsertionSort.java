package sort_bubble.Day_07;
import java.util.*;

public class InsertionSort {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int ret[] = insertionSort(arr);
		
		for(int i = 0; i < n; i++) {
			System.out.print(ret[i] + " ");
		}
		
	}

	private static int[] insertionSort(int[] arr) {   //3 5 1 4 0 6 9 2
		// TODO Auto-generated method stub
		for(int i = 1; i < arr.length;i++) { //1
			int key = arr[i]; //5
			/*
			int j = i-1; //0
			while(j>=0 && arr[j] > key) { //
				arr[j+1] = arr[j];
				j--;
			}
			arr[j+1] = key;
			*/
			int j =i-1;
			for(j = i-1; j >=0; j--) {
				if(arr[j] > key) {
					arr[j+1] = arr[j];
				}else {
					break;
				}
				
			}
			arr[j+1] = key;
		}
		return arr;
	}

}
