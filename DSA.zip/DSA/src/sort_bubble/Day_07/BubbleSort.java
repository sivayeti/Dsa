package sort_bubble.Day_07;
import java.util.*;

public class BubbleSort {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
			
		
		}
		
		
		int brr[] = bubbleSort(arr);
		
		for(int i = 0; i < n; i++) {
			
			System.out.print(brr[i] + " ");
			
		
		}
		
		
	}

	private static int[] bubbleSort(int[] arr) { //{8,4,6,2} //4 elements, as n elements, we have to go through 3 sections, i.e we have to iterate over 0,1,2{i < (n-1)}, in each section we have to bring the respective highest element to their respective place
		// 0 (1st section) ,  _, _, _, 8  (we have to perform 3 swaps i.e n-1 swaps, which makes the largest element to bring into the last place, even if it is at any place)
		// 1 (2nd section) ,  _, _, 6, 8  (2 times swap) (internal loop should perform these swap in each section, while incrementing each section, no.of swaps should decrement respecively)
		// 2 (3rd section) ,  _, 4, 6, 8  (1 time swap) 
		//2, 4, 6, 8
		
		//How many sections should loop
		for(int i = 0; i < arr.length-1; i++) {
			
			//How many swap verification should done in each section ( As section increase, no.of swaps should decrease respectively)
			for(int j = 0; j < arr.length-1 - i; j++ ) { //these ensure , at 0 (1st section), j = 0 to 2 (3 swaps on array, which makes the largest element to place at last place),  while i incrementing , no.of swaps also decrease respectively
				
				if(arr[j] > arr[j+1]) { //(8 > 4), condition fails(they are not in ascending order, we have to perform swap)
					int temp = arr[j]; //temp = 8
					arr[j] = arr[j+1]; //arr[j] = 4
					arr[j+1] = temp; //arr[j+1] = 8  ==> {4,8,6,2}, 1st swap(j=0) verify is done in 1st section(i=0).
					                    //In the same way{4,6,8,2}, 2nd swap(j=1) verify is done in 1st section(i=0).
					                    //In the same way{4,6,2,8}, 3rd swap(j=2) verify is done in 1st section(i=0).  {which  brings the highest element at last}.
					                   
					                    //As 1st section ,  no.of swaps verification completes, then internal loop will ends, and get into external loop, i=1, which ensure 2nd section. A already one element is sorted, we only have to perform swap verification on 3 elements, i.e two swap verifications needed), so we decrement swap verification values, in next section.
					                    
					                    //i = 1(2nd section} which needs the (n-2) swaps).(4-2=2 swaps)
					                    //{4,6,2,8}, 1st swap(j=0) verify is done in 2nst section(i=1).
					                    //{4,2,6,8}, 2nd swap(j=1) verify is done in 2nst section(i=1). //which ensures to bring 6 as highest elemnt among(4,2,6). at last among these 3.
					
					                          
				}
				System.out.println(i);
				for(int k = 0; k < arr.length; k++) {
					System.out.print(arr[k]+ " ");
				}
				System.out.println();
				
			}
			
		}
		return arr;
	}
}
