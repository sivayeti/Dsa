package DS_Stack.Day_22;

import java.util.ArrayList;
import java.util.EmptyStackException;

public class Stack_pop<T> {

	ArrayList<T> list = new ArrayList<>();

	//Add or Push the data to stack
	T push(T data) {
		list.add(data);
		return data;
	}

	
	
	
	
	//Delete the top element or Pop operation - My Solution
	/*
	T pop() { //Pop() - deletes the top element from stack, (Top element- the element which we add at last time to list)
		      //last time added element or Top element will be stored at ending index of list;
    
		
		
		
	//	
	//int l = list.size(); //size() method returns the length of list.
	                       //By using the length of list we can find the ending index of list by (n-1) where n is length of ArrayList
	//int top_element_index = l-1;
	
	//list.remove(top_element_index); //remove method is used to delete the particular element of list, and ot accepts the argument index of element which we want to delete.
	
	//return list.get(top_element_index);
	//
	

		
	//Instead of all these we can also remove the Top element or last list element by using the removeLast() method of list.
	T top = list.removeLast();

	return top;
   
	}
	*/
	
	
	
	
	//Pop Operation - Mentor Solution
	T pop() {
		if(list.isEmpty()) {
			throw new EmptyStackException();
			
		}
		return list.remove(list.size() - 1);
	}
}
