package DS_Stack.Day_22;

import java.util.ArrayList;

//Lets implement the stack in Generic Type
public class Stack1<T> { //It enables to accept the datatype, on which base these class object is created by user.
	
	//Implement the Stack by using ArrayList
	ArrayList<T> list = new ArrayList<>();
	

}
