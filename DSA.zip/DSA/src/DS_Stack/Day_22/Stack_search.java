package DS_Stack.Day_22;

import java.util.ArrayList;

public class Stack_search<T> {

	ArrayList<T> list = new ArrayList<>();

	//Add data or push operation
	T push(T data) {
		list.add(data);
		return data;
	}

	//Pop operation
	T pop() {
	   return list.removeLast();
	}

	
	//Peek Operation
	T peek() {
		
		return list.get(list.size() - 1);
	}

	//Empty method
	boolean empty() {
		
		return list.isEmpty();
	}

	//Search method - MY Solution
	/*
	int search(T data) {
		int pos = 0;
		int index = list.indexOf(data); //indexOf returns the index value of element in list
		int len = list.size();
		pos = len - index;
		return pos;
	}
	*/
	
	//Search Method - Mentor solution
	int search(T data) {
		if(list.contains(data)) {
			return list.size() - list.indexOf(data);
		}
		return -1;
	}
	
	
	
}
