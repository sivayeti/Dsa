package DS_Stack.Day_22;

import java.util.ArrayList;

public class Stack_empty {

	ArrayList<Integer> list = new ArrayList<>();
	
	
	//Add data or push data to stack
	int push(int data) {
		list.add(data);
		
		return data;
	}
	
	//Remove the top element or Pop operation
	int pop() {
		return list.removeLast();
	}
	
	//Print the top element
	int peek() {
		return list.get(list.size()-1);
	}
	
	
	//Empty - verifies stack is empty or not
	boolean Empty() {
		
		return list.isEmpty();
	}
	
	public static void main(String[] args) {
		Stack_empty st = new Stack_empty();
		
		System.out.println(st.push(1));
		System.out.println(st.push(2));
		System.out.println(st.push(3));
		
		System.out.println();
		
		System.out.println(st.pop());
		
		System.out.println();
		
		System.out.println(st.peek());
		
		System.out.println();
		
		//Lets implement the Empty method of stack;
		System.out.println(st.Empty()); //returns false , if stack is not empty, returns tru if stack is empty
	}

	

	


	

	
}
