package DS_Stack.Day_22;

public class Stack_search_Test {

	public static void main(String[] args) {
		Stack_search<Integer> st = new Stack_search<>();
		
		System.out.println(st.push(1));
		System.out.println(st.push(2));
		System.out.println(st.push(3));
		
		System.out.println();
		
		System.out.println(st.pop());
		
		System.out.println();
		
		System.out.println(st.peek());
		
		System.out.println();
		
		System.out.println(st.empty());
		
		System.out.println();
		
		//Lets implement the search method
		System.out.println(st.search(1)); //These method returns the position of element in stack
		
		
		
		/*
		//list  = {1,2,5,8,9}
		//index {0,1,2,3,4}
		//pos    {5,4,3,2,1}
		Stack 	position	Index value in list   	Pos calc
		9	1	4	5 -4 =1
		8	2	3	5 -3 =2
		5	3	2	5 -2 =3
		2	4	1	5 -1 =4
		1	5 	0	5 -0 =5
		              
		//To find the position of stack element = list.size() – element_Index
		//So to find the position of stack element, first we have to find its index after finding the index , by using the index we have to find the particular position of stack element.
        */
	}
}


//In collections Stack, for defined class stack, we will create the objects and use the defined methods in stack class
//But here, we only prepared the stack class, and prepared the methods

