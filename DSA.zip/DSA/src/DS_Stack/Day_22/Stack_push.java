package DS_Stack.Day_22;

import java.util.ArrayList;

public class Stack_push<T> {

	ArrayList<T> list = new ArrayList<>();

	//Add or Push data to stack
	//push method
	T push(T data) {
		// TODO Auto-generated method stub
		list.add(data); //add is method of ArrayList , which is used to add() the method in to the arrayList.
		return data;
		
	}
}
