package DS_Stack.Day_22;

public class Stack_pop_Test {

	public static void main(String[] args) {
		Stack_pop<Integer> st = new Stack_pop<>();
		
		System.out.println(st.push(1));
		System.out.println(st.push(2));
		System.out.println(st.push(3));
		
		//Lets implement the Pop
		System.out.println(st.pop()); //when we call these Pop method then Top element (i.e whatever the element we add at the last to stack, that should be deleted or removed) should be deleted, and in list the element which we stored at last time  that will be stored at ending index  of list.
	
		/*
		System.out.println();
		for(int i = 0; i < st.list.size(); i++) {
		    System.out.print(st.list.get(i) + " ");
		}
		System.out.println();
		*/
		
		
	}
}
