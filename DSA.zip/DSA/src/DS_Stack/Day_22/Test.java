package DS_Stack.Day_22;

public class Test {

	public static void main(String[] args) {
		Stack1<Integer> st = new Stack1<>();
		
		//In these way we can implement the stack
	}

}
//T push(T) {};  //whatever the method we have to define to perform on stack, we have to return the elements of that type.