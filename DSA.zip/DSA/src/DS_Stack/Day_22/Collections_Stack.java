package DS_Stack.Day_22;
import java.util.*;
public class Collections_Stack {

	public static void main(String[] args) {
		//Using the stack from collections, instead the stack class which we defined based on stack concept.
		
		Stack<String> st = new Stack<>();
		
		//push() method
		System.out.println(st.push("A"));
		System.out.println(st.push("B"));
		st.push("C");
		st.push("D");
		st.push("E");
		//pop() method
		st.pop();
		//peek() method
		System.out.println(st.peek());
		//empty() method
		System.out.println(st.empty());
		
		//search() method
		System.out.println(st.search("F"));
		
		
	}
	
}
