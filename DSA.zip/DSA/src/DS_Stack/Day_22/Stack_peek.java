package DS_Stack.Day_22;

import java.util.ArrayList;
import java.util.EmptyStackException;

public class Stack_peek<T> {

	ArrayList<T> list = new ArrayList<>();
	
	//Add data or Push operation
	void push(T data) {
		list.add(data);
		
	    System.out.println(data);
	}
	
	//Remove data or Pop Operation
	void pop() {
		System.out.println(list.removeLast());
	}
	
	
	//Peek method - My Solution
	/*
	void peek() {
		System.out.println(list.get(list.size() -1 ));
	}
	*/
	
	//Peek method - Mentor Solution
	T peek() {
		if(list.isEmpty()) {
			throw new EmptyStackException();
		}
		return list.get(list.size() - 1);
	}
	
	
	public static void main(String[] args) {
		Stack_peek<Integer> st = new Stack_peek<>();
		
		st.push(1);
		st.push(2);
		st.push(3);
		
		st.pop(); //which removes top element i.e last element in list
		
		
		//st.peek(); //retrieves the top element 
		System.out.println(st.peek());
	}



	
}
