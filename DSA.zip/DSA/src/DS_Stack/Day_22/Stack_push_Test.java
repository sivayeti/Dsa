package DS_Stack.Day_22;

public class Stack_push_Test {

	public static void main(String[] args) {
		Stack_push<Integer> st = new Stack_push<>();
	    
		//Lets implement the push operation in stack, i.e adding the data
		System.out.println(st.push(1)); //push() add the elements to stack.
		System.out.println(st.push(2));
		
		//Lets implement the pop operation
	}
}
