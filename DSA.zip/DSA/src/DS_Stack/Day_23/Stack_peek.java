package DS_Stack.Day_23;

import java.util.EmptyStackException;

public class Stack_peek<T> {

	Node<T> head_top;
	class Node<T>{
	 T val;
	 Node<T> next;
	 public Node(T val) {
		 this.val = val;
		 next = null;
	 }
		
	}
	
	
	//push()
	T push(T val) {
	    Node<T> node = new Node(val);
	    if(head_top == null) {
	    	head_top = node;
	    	return val;
	    }
	    node.next = head_top;
	    head_top = node;
	    return node.val;
		
	}
	
	
	//pop()
    T pop() {
		if(head_top == null) {
			throw new EmptyStackException();
		}
		Node<T> i = head_top;
		head_top = head_top.next;
		return i.val;
	}
    
    
    
    //peek() -My solution
    /*
    T peek() {
    	return head_top.val;
	}
    */
    
    //peek() - Mentor Solution

    T peek() {
    	if(head_top == null) {
    		throw new EmptyStackException();
    	}
    	return head_top.val;
	}
    
    
	public static void main(String[] args) {
		Stack_peek<String> st = new Stack_peek<>();
		
		System.out.println(st.push("B"));
		System.out.println(st.push("A"));
		
		System.out.println(st.pop());
		
		System.out.println(st.push("C"));
		
		
		//Lets implement the peek
		System.out.println(st.peek());
	}

}
