package DS_Stack.Day_23;

import java.util.EmptyStackException;

public class Stack_empty<T> {

	Node<T> head_top;
	class Node<T>{
		T val;
		Node<T> next;
		public Node(T val) {
			this.val = val;
			next = null;
		}
	}
	
	
	//PUSH()
	T push(T val) {
		Node<T> node = new Node<>(val);
		
		if(head_top == null) {
			head_top = node;
			return val;
		}
		node.next = head_top;
		head_top = node;
		return val;
	}
	
	
	//Pop()
	T pop() {
		if(head_top == null) {
			throw new EmptyStackException();
		}
		Node<T> i = head_top;
		head_top = head_top.next;
		return i.val;
	}
	
	
	//peek()
     T peek() {
    	  if(head_top == null) {
    		  throw new EmptyStackException();
    	  }
    	  
    	  return head_top.val;
	}
     
     
     
    //empty() - My solution
     /*
     boolean empty() {
 		if(head_top == null) {
 			return true;
 		}
 		return false;
 	}
     */
     
     //empty() - Mentor Solution
     boolean empty() {
    	 return head_top == null;
     }
    
     
	public static void main(String[] args) {
		Stack_empty<String> st = new Stack_empty<>();
		
		System.out.println(st.push("B"));
		System.out.println(st.push("A"));
		
		System.out.println();
		
		System.out.println(st.pop());
		
		System.out.println();
		
		System.out.println(st.push("C"));
		
		System.out.println();
		
		System.out.println(st.peek());
		
		System.out.println();
		
		System.out.println(st.empty());
		
		//Lets implement the search
		
	}

	



	
}
