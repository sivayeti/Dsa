package DS_Stack.Day_23;

public class Stack_push<T> {

	Node<T> top;
	class Node<T>{
		T val;
		Node<T> next;
		public Node(T val) {
			this.val = val;
			next = null;
		}
	}
	
	//Push() method - My soultion
    /*
	T push(T val) {
	    Node<T> node = new Node<>(val); //node = [A] //node = [A]
	    if(top == null) {
	    	top = node;
	    	return val;
	    }
	    top.next = node;
	    top = node;
		 
		return val;
	}
	*/
	
	//push() - Mentor solution
	T push(T val) {
	    Node<T> node = new Node<>(val); //node = [A] //node = [A]
	    if(top == null) {
	    	top = node;
	    	return val;
	    }
	    node.next = top;
	    top = node;
		 
		return val;
	}
	public static void main(String[] args) {
		Stack_push<String> st = new Stack_push<>();
		
		//Lets perform the push operation
		st.push("A");
		st.push("B");
		
		
	}



}
