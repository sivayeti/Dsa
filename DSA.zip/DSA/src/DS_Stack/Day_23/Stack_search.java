package DS_Stack.Day_23;

import java.util.EmptyStackException;

public class Stack_search<T> {

	Node<T> head_top;
	class Node<T> {
		T val;
		Node<T> next;
		public Node(T val) {
			this.val = val;
			next = null;
		}
	}
	
	
	//push()
	T push(T val) {
		Node<T> node = new Node<>(val);
		if(head_top == null) {
			head_top = node;
			return val;
		}
		node.next = head_top;
		head_top = node;
		return val;
	}
	
	
	//pop()
    T pop() {
		if(head_top == null) {
			throw new EmptyStackException();
		}
		Node<T> i = head_top;
		head_top = head_top.next;
		return i.val;
	}
	
    
    //peek()
    T peek() {
		if(head_top == null) {
			throw new EmptyStackException();
		}
		return head_top.val;
	}
    
    
    //empty()
    boolean empty() {
		
		return head_top == null;
	}

    
    //search() - My solution not worked
    /*
    int search(T val) {
		Node<T> i = head_top;
		int j = 1;
		Node<T> node = new Node<>(val); //node = [B]
		while(i != node) { //these will break when i has the node = [D]
			//As i = head_top, j =1
			//   i = head_top.next, j = 2
			//
			//   i = node, j = node position., loop breaks and remains j with the node position in stack.
			i = i.next;
			j = j + 1;
			
			
		}
		return j;
		
	}
    
    */
    
    
    //search() method - mentor solution
    int search(T val) {
    	Node<T> i = head_top;
    	int j = 1;
    	while(i != null) {
    		if(i.val.equals(val)) {
    			return j;
    		}
    		i = i.next;
    		j = j + 1;
    	}
    	return -1;
    }
    
    
	public static void main(String[] args) {
		Stack_search<String> st = new Stack_search<>();
		
		System.out.println(st.push("B"));
		System.out.println(st.push("A"));
		
		System.out.println();
		System.out.println(st.pop());
		
		System.out.println();
		
		System.out.println(st.push("C"));
		
		System.out.println();
		
		System.out.println(st.peek());
		
		System.out.println();
		
		System.out.println(st.empty());
		
		System.out.println(st.push("D"));
		
		System.out.println(st.search("B")); //returns the position of element in stack
		System.out.println(st.search("C"));
		System.out.println(st.search("D"));
		System.out.println(st.search("E"));
	}


	


	

	


	


	

}
