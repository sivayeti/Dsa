package DS_Stack.Day_23;

import java.util.EmptyStackException;

public class Stack_pop<T> {

	Node<T> top;
	class Node<T>{
		T val;
		Node<T> next;
		public Node(T val) {
			this.val = val;
			next = null;
		}
	}
	
	//PUSH() - My solution
	/*
    T  push(T val) {
		Node<T> node = new Node<>(val); 
		if(top == null) {
			top = node;
			return val;
		}
		top.next = node;
		top = node;
		return val;
	}
	*/

    //push() - mentor solution
	T  push(T val) {
		Node<T> node = new Node<>(val); 
		if(top == null) {
			top = node;
			return val;
		}
		node.next = top;
		top = node;
		return val;
	}
	
	
	//pop() - My solution
	/*
      T pop() {
		Node<T> i = top;  //top = head
		top = top.next;
		
		return i.val;
	}
      */
	
	//pop() - Mentor Solution
	T pop() {
		if(top == null) {
			throw new EmptyStackException();
		}
		Node<T> i = top;
		top = top.next;
		return i.val;
	}
      
	public static void main(String[] args) {
		Stack_pop<String> st  = new Stack_pop<>();
		
		System.out.println(st.push("B"));
		System.out.println(st.push("A"));
		
		//Lets implement the pop 
		System.out.println(st.pop());
	}

	
	
	
}
