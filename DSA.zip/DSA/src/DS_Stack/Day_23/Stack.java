package DS_Stack.Day_23;

public class Stack<T> {

	//Lets implement the stackusing nodes
	class Node<T>{
		T val;
		Node<T> next;
		public Node(T val) {
			this.val = val;
			next = null;
		}
	}

		
	//In these way we will create the stack using nodes
	
}
