package search_Day_13;
import java.util.*;

public class InterpolationSearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int key = sc.nextInt();
		int ans =interpolationSearch(arr, n, key);
		System.out.println(ans);
	}

	private static int interpolationSearch(int[] arr, int n, int key) {
		// TODO Auto-generated method stub
		int low = 0,high=n-1;
		while(low<high && arr[low] <= key && arr[high] >= key) {
			if(low== high) {
				return low;
		}
			int mid = low + ( ((high-low)/(arr[high]-arr[low])) * (key - arr[low]) );
		
			if(arr[mid] == key) {
				return mid;
			}
			else if(arr[mid] < key) {
				low = mid+1;
			}
			else if(arr[mid] > key) {
				high = mid-1;
			}
		}
		return -1; //element not found
	}
}
