package search_Day_13;
import java.util.*;

public class BinarySearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int[] arr = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int element = sc.nextInt();
		//int val = binarySearch(arr, 0, n-1, element);
		int val = binarySearch(arr,  element);
		
			System.out.print(element + " is found at " + val + " index");
		
		
	}

	//private static int binarySearch(int[] arr, int low, int high, int ele) {
	private static int binarySearch(int[] arr, int ele) {
		//if array is not an sorted array
		Arrays.sort(arr); //these will update the array in sort format.
		int low = 0, high=arr.length-1;
	    // TODO Auto-generated method stub
		while(low<=high) {
			int mid=(low+high)/2;
			if(arr[mid] == ele){
				return mid; //element founds
			}else if(arr[mid] > ele) {
				high = mid;
			}else if(arr[mid] < ele) {
				low = mid+1;
			}
		}
		
		return -1; //element not founds
	}
}
