package search_Day_13;
import java.util.*;

public class LinearSearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int ele = sc.nextInt();
		
		int ans = LinearSearch(arr, ele);
		if(ans != -1) {
		System.out.println(ele + " found at "+ ans+ " index " );
		}else {
			System.out.println("element not found");
		}
	}

	private static int LinearSearch(int[] arr, int ele) {
		// TODO Auto-generated method stub
		for(int i =0; i < arr.length;i++) {
			if(arr[i] == ele) {
				return i;
			}
		}
		return -1;
	}
}
