package DS_Tree.Day_30;

public class BinaryTreeCode {

	class Node{
		Node left;
		int data;
		Node right;
		public Node(int data) {
			left = null;
			this.data = data;
			right = null;
		}
	}
	
	
	//Method to make, a binaryTree by using recursion
	static int ind = -1;
	Node binaryTreeMake(int[] nodes) {
		ind++;
		if(nodes[ind] == -1) {
			return null;
		}
		Node node = new Node(nodes[ind]);
		node.left = binaryTreeMake(nodes);
		node.right = binaryTreeMake(nodes);
		return node;
	}
	
	
	//preOrder
	void preOrder(Node root) {
		if(root == null) {
			return;
		}
		System.out.print(root.data + " ");
		preOrder(root.left);
		preOrder(root.right);
	}

	
	//inOrder
	void inOrder(Node root) {
		if(root == null) {
			return;
		}
		inOrder(root.left);
		System.out.print(root.data + " ");
		inOrder(root.right);
		
	}
	
	
	
	//postOrder
    void postOrder(Node root) {
		if(root == null) {
			return;
		}
		postOrder(root.left);
		postOrder(root.right);
		System.out.print(root.data + " ");
		
	}

	public static void main(String[] args) {
		int[] nodes = {3,2,1,-1,-1, -1, 5,4,-1,-1,6,-1,7,-1,-1};
		
		BinaryTreeCode bt = new BinaryTreeCode();
		
		Node root = bt.binaryTreeMake(nodes);
		
		bt.preOrder(root);
		System.out.println();
		bt.inOrder(root);
		System.out.println();
		
		//Lets implement the postOrder traversal = Left,Right,root
		bt.postOrder(root);
	}


	

	

	

	

}
