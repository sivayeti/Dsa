package DS_Tree.Day_28;

public class BinaryTreeCode {

	
	class Node{
		Node left;
		int data;
		Node right;
		public Node(int data) {
			left = null;
			this.data = data;
			right = null;
		}
	}
	
	//Method to construct binaryTree, by using recursion
	static int ind = -1; //By using these index, we can iterate over the each element of array.
	Node binaryTreeMake(int[] nodes) {
		ind++;
		if(nodes[ind] == -1) {
			return null;
		}
		Node node = new Node(nodes[ind]);
		node.left = binaryTreeMake(nodes);
		node.right = binaryTreeMake(nodes);
		return node;
	}
	
	
	//Method to traverse in pre-order on binaryTree 
	void preOrder(Node root) {

		if(root == null) {
			//System.out.print(-1 + " ");
			return;}
		System.out.print(root.data+" "); //3 //2 //1 
		preOrder(root.left); //2  //1 //null
		preOrder(root.right); //null //null //
		
	}
	
	public static void main(String[] args) {
		int[] nodes = {3,2,1,-1,-1,-1,5,4,-1,-1,6,-1,7,-1,-1};
		BinaryTreeCode bt = new BinaryTreeCode();
		
		
		Node root = bt.binaryTreeMake(nodes);

		System.out.println(root.data);
//		System.out.println(root.left.data);
//		System.out.println(root.right.data);
//		System.out.println(root.left.left.data);
		
		//Lets perform the pre-order traversal on the binaryTree which we make.
		//By using the root node, we have to perform the pre-order traversal
		bt.preOrder(root);
	}

	
	

}
