package DS_Tree.Day_34;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTreeCode {

	class Node{
		Node left;
		int data;
		Node right;
		public Node(int data) {
			left = null;
			this.data = data;
			right = null;
		}
	}
	
	
	//Construct a binary Tree, using recurssion
	static int ind = -1;
	Node binaryTreeMake(int[] nodes) {
		ind++;
		if(nodes[ind] == -1) {
			return null;
		}
		Node node = new Node(nodes[ind]);
		node.left = binaryTreeMake(nodes);
		node.right = binaryTreeMake(nodes);
		return node;
	}
	
	
	//pre-order
	void preOrder(Node root) {
		if(root == null) {
			return;
		}
		System.out.print(root.data + " ");
		preOrder(root.left);
		preOrder(root.right);
		
	}
	
	
	//inOrder
	void inOrder(Node root) {
		if(root == null) {
			return;
		}
		inOrder(root.left);
		System.out.print(root.data + " ");
		inOrder(root.right);
		
	}
	
	
	//post Order

	void postOrder(Node root) {
		if(root == null) {
			return;
		}
		postOrder(root.left);
		postOrder(root.right);
		System.out.print(root.data + " ");
		
	}
	
	//levelOrder
	void levelOrder(Node root) {
		Queue<Node> q = new LinkedList<Node>();
		
		q.add(root);
		q.add(null);
		while(!q.isEmpty()) {
			Node cNode = q.remove();
			if(cNode != null) {
				System.out.print(cNode.data + " ");
				if(cNode.left != null) {
					q.add(cNode.left);
				}
				if(cNode.right != null) {
					q.add(cNode.right);
				}
			}else {
				if(!q.isEmpty()) {
					q.add(null);
				}
			}
		}
		
		
	}

	
	
	//count nodes
	int countNodes(Node root) {
		if(root == null) {
			return 0;
		}
		int l = countNodes(root.left);
		int r = countNodes(root.right);
		int count = l + r + 1;
		return count;
	}
	
	//sum of nodes

	int sumOfNodes(Node root) {
		if(root == null) {
			return 0;
		}
		int lsum = sumOfNodes(root.left);
		int rsum = sumOfNodes(root.right);
		int sum = lsum + rsum + root.data;
		return sum;
	}

	
	
	//Height of Binary tree
	int heightOfTree(Node root) {
		if(root == null) {
			return 0;
		}
		int lh = heightOfTree(root.left);
		int rh = heightOfTree(root.right);
		int h = Math.max(lh, rh) + 1;
		return h;
	}

	
	public static void main(String[] args) {
		int nodes[] = {3, 2, 1, -1, -1, -1, 5, 4, -1, -1, 6, -1, 7 , -1, -1};
		
		BinaryTreeCode bt = new BinaryTreeCode();
		
		Node root = bt.binaryTreeMake(nodes);
		
		//preOrder
		bt.preOrder(root);
		System.out.println();
		
		//inOrder
		bt.inOrder(root);
		System.out.println();
		
		//postOrde
		bt.postOrder(root);
		System.out.println();
		
		
		//levelOrder
		bt.levelOrder(root);
		System.out.println();
		
		
		//countNodes
		System.out.println(bt.countNodes(root));
		
        //sumOfNodes
		System.out.println(bt.sumOfNodes(root));
		
		
		//Height of Binary Tree
	    int height = bt.heightOfTree(root);
	    System.out.println(height);
	}


	



	


	


	


	

	

}
