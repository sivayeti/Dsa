package DS_Tree.Day_31;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTreeCode {

	class Node{
		Node left;
		int data;
		Node right;
		public Node(int data) {
			left = null;
			this.data = data;
			right = null;
		}
	}
	
	
	//construct a binary tree by using recurssion
	static int ind = -1;
	Node binaryTreeMake(int[] nodes) {
		ind++;
		if(nodes[ind] == -1) {
			return null;
		}
		Node node = new Node(nodes[ind]);
		node.left = binaryTreeMake(nodes);
		node.right = binaryTreeMake(nodes);
		return node; //returns root node
	}
	
	
	//Lets implement the pre-order
	void preOrder(Node root) {
		if(root == null) {
			return;
		}
		System.out.print(root.data + " ");
		preOrder(root.left);
		preOrder(root.right);
		
	}
	
	//in-order
	void inOrder(Node root) {
		if(root == null) {
			return;
		}
		inOrder(root.left);
		System.out.print(root.data + " ");
		inOrder(root.right);
	}
	
	//post-order
	void postOrder(Node root) {
		if(root == null) {
			return;
		}
		postOrder(root.left);
		postOrder(root.right);
		System.out.print(root.data + " ");
	}
	
	
	
	/*
	//Lets implement the Level Order Traversal
	//To implement Level Order traversal , we need  queue, so for that use the Queue, from Collections.
	//My Solution
	void levelOrder(Node root) {
		Queue<Node> q = new LinkedList<Node>(); //syntax to create queue data structure, from collections, and assigned 'q' name to our Queue data structure which we created.
		
		q.offer(root); // 3
		q.offer(null); // 3 null
		
		levelOrder1(root, q);
		
	}

	

	

   void levelOrder1(Node root, Queue<Node> q) {
	  
//			if(root == null && !q.isEmpty()) {
//				q.add(null);
//				
//				//q.poll();
//				//root = q.peek();
//			}else if (root == null && q.isEmpty()) {
//			     return;
//			}
	        if(root == null) {
	        	q.poll(); //removes null
	        	//System.out.println(); //new level
	        	
	        	if(!q.isEmpty()) {
	        		q.offer(null);
	        		levelOrder1(q.peek(), q);
	        	}
	        	return;
	        }
			
	        
			if(root != null) {
			if(root.left != null) {
				q.offer(root.left);
			}
			if(root.right != null) {
				q.offer(root.right);
			}
			System.out.print(root.data+ " ");
			}
			
			
			q.poll();
			levelOrder1(q.peek(), q);
			
	}
    */
	
	
	//Level Order Traversal - Mentor Solution
	void levelOrder(Node root) {
		Queue<Node> q = new LinkedList<Node>(); //3 null 
		q.add(root); //add root  --> 3
		q.add(null); //add null  --> 3 null
		
		while(!q.isEmpty()) { //until q not becomes empty, these while loop should run
			                  //whenever these queue q becomes empty then , while loop should break.
			Node cNode = q.remove(); // cNode = 3; //cNode = null
			if(cNode != null) {
				System.out.print(cNode.data + " "); //3 -> 2,5  -> 1,4,6 -> 7
				if(cNode.left != null) {
					q.add(cNode.left); // 2 
				}
				if(cNode.right != null) {
					q.add(cNode.right);  //2 5 
				}
			}else {
				System.out.println();
				if(q.isEmpty()) {
					break;
				}else {
					q.add(null); //when cNode becomes null, and queue, becomes not empty then we need to add new null at last to queue.
				}
			}
			
		}
		
	}
	

	public static void main(String[] args) {
		int[] nodes = {3,2,1,-1,-1,-1,5,4,-1,-1,6,-1,7,-1,-1};
		
		BinaryTreeCode bt = new BinaryTreeCode();
		
		

		Node root = bt.binaryTreeMake(nodes);
		
		//Lets implement pre-order traversal
		//bt.preOrder(root);
		System.out.println();
		//Lets implement the in-order traversal
		//bt.inOrder(root);
		System.out.println();
		//Lets implement the post-order traversal
		//bt.postOrder(root);
		
		System.out.println();
		
		
		//Lets implement the Level-Order Traversal
		bt.levelOrder(root);
	}


	


	

	


	


	

	

}
