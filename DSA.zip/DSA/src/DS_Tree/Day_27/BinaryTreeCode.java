package DS_Tree.Day_27;

public class BinaryTreeCode {

	//Every data is stored in Node, in Binary Tree, so a create a user defined datatype Node, by using class concept, that datatype should hold current data, and its left and right node values too.
	class Node{
		int data;
		Node left;
		Node right;
		public Node(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}
	
	 
     //Method to construct binary Tree, and return the root of binary Tree
	 //We will Make the binary Tree, by using recursions.
	 static int ind = -1;
	Node binaryTreeMake(int[] nodes) {
		//Lets Implement the logic to construct binary tree, by using nodes.
		//To construct tree, to which node we should take, we will found out by using 'ind=-1'
		ind++; //-1+1 = 0
		if(nodes[ind] == -1) { //so, iterate , and check the each element we use the ind, variable, on which its first increment ,ind becomes zero, and works as index for array nodes, and retrieves nodes[0] first element, and in second recursion ind becomes 1, and helps to retrieve the nodes[1], which is second element of nodes array, in the same way, we can iterate over all the elements of array
			                   //if any array element value is -1, then we should take not take that element left remained. and then go with right direction to assign nodes.
			return null;
		}
		Node node = new Node(nodes[ind]); //if nodes array, doesn't have -1, then we have to create  a node for the respective nodes[ind] element.
		node.left = binaryTreeMake(nodes);
		node.right = binaryTreeMake(nodes);
		return node;
	}

	
	public static void main(String[] args) {
		
		//nodes to place in binary tree

		int nodes[] = {3,2,1,-1,-1,-1,5,4,-1,-1,6,-1,7,-1,-1};
		//We have to create the tree for these nodes, by following preorder traversal(root,Left,Right).
		
		
		BinaryTreeCode bt = new BinaryTreeCode();
		
		Node root = bt.binaryTreeMake(nodes);
		System.out.println(root.data);
		System.out.println(root.left.data);
		System.out.println(root.right.data);
		System.out.println(root.left.left.data);
		System.out.println(root.right.left.data);
	}


}
