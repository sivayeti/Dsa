package DSA_Graph.Day_39;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Graph {

	
	List<GraphNode> graphNodes = new ArrayList<>();
	
	public Graph(List<GraphNode> graphNodes) {
		this.graphNodes = graphNodes; //Now we assigned the List of graph nodes to graphNodes variable list here.
	}
	
	
    public void addEdges(int i, int j) {
    	
    	
    	GraphNode first = graphNodes.get(i); 
    	GraphNode second = graphNodes.get(j); 
    	
    	first.neighbours.add(second);
    	second.neighbours.add(first);
    	
    }
    
    
    
    
    
    
    @Override
    public String toString() {
 
        return graphNodes.stream().map(g -> g.name + " : " + g.neighbours.stream().map(n -> n.name)
        		.collect(Collectors.joining("->")) + "\n").collect(Collectors.joining(""));
               //stream() will iterate over the each element in graphNodes List, and on that each element map() will take as argument and proccess function on it.
    }

    
    

	
	public void bfs(GraphNode node) {
		Set<GraphNode> visited = new HashSet<GraphNode>(); //0,1,3,5,2,4
		Queue<GraphNode> queue = new LinkedList<GraphNode>();//1,3,5   //3,5,2 //5,2,4 //2,4  //4 //null
		
		queue.add(node);
		visited.add(node);
		
		while(!queue.isEmpty()) { //If queue is not empty then only these loop should executes.
			GraphNode current = queue.poll(); //current = node(0) //stores the first queue node.
			                                  //current = node(1)
			                                  //current = node(3)
			                                  //current = node(5)
			                                  //current = node(2)
			                                  //current = node(4)
			System.out.print(current.name + " "); //0, 1, 3, 5, 2, 4
			//Lets store the neighbours of current node, which are not visited
			for(GraphNode neighbour: current.neighbours) {
				if(!visited.contains(neighbour)) {
					queue.add(neighbour); //1,3,5 ,2, 4
					visited.add(neighbour);//0, 1,3,5, 2, 4
				}
			}
		}
	
	}

}
