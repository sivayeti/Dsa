package DSA_Graph.Day_39;

import java.util.ArrayList;
import java.util.List;

public class GraphNode {

	//These class is used to create the nodes of our graph
	String name;
	int index;
	
	//To store the neighbours of each node, we need a list , for each node to store the neighbour nodes of that node.
	List<GraphNode> neighbours = new ArrayList<>();
	
	public GraphNode(String name,int index) { //Using the constructor we are assigning the name,index for our nodes
		this.name = name;
		this.index = index;
		
		
	}
	
}

//Now to represent the Nodes of Graph Adjaceny List, we created a class, which is used to create the each node in our graph, and each GraphNode class object node of graph have name, index, and their neighbour nodes list

//Our creating our nodes by using these class, to make connections among the nodes ,we use graph class.

