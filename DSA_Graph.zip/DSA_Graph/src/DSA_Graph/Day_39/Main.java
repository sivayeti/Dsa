package DSA_Graph.Day_39;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		
		List<GraphNode> graphNodes = new ArrayList<GraphNode>();
		
		//Lets create all the nodes of graph, and store in graphNodes list
		
		/*//My way
		GraphNode A = new GraphNode("0", 0);
		GraphNode B = new GraphNode("1", 1);
		GraphNode C = new GraphNode("2", 2);
		GraphNode D = new GraphNode("3", 3);
		GraphNode E = new GraphNode("4", 4);
		GraphNode F = new GraphNode("5", 5);
		//All nodes created 
		
		graphNodes.add(A);
		graphNodes.add(B);
		graphNodes.add(C);
		graphNodes.add(D);
		graphNodes.add(E);
		graphNodes.add(F);
		//All created nodes are added to list
		*/
		
		//Mentor way
		graphNodes.add(new GraphNode("0",0));
		graphNodes.add(new GraphNode("1",1));
		graphNodes.add(new GraphNode("2",2));
		graphNodes.add(new GraphNode("3",3));
		graphNodes.add(new GraphNode("4",4));
		graphNodes.add(new GraphNode("5",5));
		//All nodes are created and added to list
		
		//Now pass these list to graph class object, then list of nodes in graph will be ready, and by using addEdges() function we can create the edges between nodes, and to store the edge connection among nodes in adjacency List representation.
		
		Graph graph = new Graph(graphNodes);
		//Now our list of nodes in graph are ready.
		graph.addEdges(0, 1);
		graph.addEdges(0, 3);
		graph.addEdges(0, 5);
		graph.addEdges(1, 2);
		graph.addEdges(1, 3);
		graph.addEdges(2, 3);
		graph.addEdges(3, 4);
		graph.addEdges(4, 5);
		//Now we created all edges among the nodes in graph.
		
		System.out.println(graph);
		
		
		//Lets implement the BFS HERE
		//Set<GraphNode> visited = new HashSet<GraphNode>();
		System.out.println("BFS");
		graph.bfs(graphNodes.get(0));
		
		
		

	}

}
