package DSA_Graph.Day_36;

public class GraphNode {

	public String name; //node name 'A', 'B',
	public int index;
	public GraphNode(String name, int index) {
		this.name = name;
		this.index = index;
	}
}

//These class is used to create the graph for nodes.
