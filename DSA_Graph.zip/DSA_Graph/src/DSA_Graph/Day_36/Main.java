package DSA_Graph.Day_36;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
	 
		//First we need to create the Nodes
		List<GraphNode> nodes = new ArrayList<>(); //created an empty list to store the nodes
		
		/* My Solution to create a graph
		GraphNode A = new GraphNode("A", 0);
		GraphNode B = new GraphNode("B", 1);
		GraphNode C = new GraphNode("C", 2);
		GraphNode D = new GraphNode("D", 3);
		GraphNode E = new GraphNode("E", 4);
		nodes.add(A);
		nodes.add(B);
		nodes.add(C);
		nodes.add(D);
		nodes.add(E);
		
		
		Graph g = new Graph(nodes); //then in Graph class, our List of Nodes, and the empty adjacency matrix will be ready
		
		g.addEdges(A.index, B.index);
		g.addEdges(A.index, D.index);
		g.addEdges(A.index, C.index);
		g.addEdges(B.index, D.index);
		g.addEdges(B.index, E.index);
		g.addEdges(C.index, D.index);
		g.addEdges(D.index, E.index);
		//Now our adjacency Matrix is also ready by defining the edges among nodes by using addEdges() function.
		*/
		
       //Mentor Solution to create a graph
		nodes.add(new GraphNode("A", 0));
		nodes.add(new GraphNode("B", 1));
		nodes.add(new GraphNode("C", 2));
		nodes.add(new GraphNode("D", 3));
		nodes.add(new GraphNode("E", 4));
		
		Graph graph = new Graph(nodes);  //then in Graph class, our List of Nodes, and the empty adjacency matrix will be ready
		graph.addEdges(0, 1);
		graph.addEdges(0, 3);
		graph.addEdges(0, 2);
		
		graph.addEdges(1, 0);
		graph.addEdges(1, 3);
		graph.addEdges(1, 4);
		
		graph.addEdges(2, 0);
		graph.addEdges(2, 3);
		
		graph.addEdges(3, 0);
		graph.addEdges(3, 1);
		graph.addEdges(3, 2);
		graph.addEdges(3, 4);
		
		graph.addEdges(4, 1);
		graph.addEdges(4, 3);
		
		
		//To construct the edges among the nodes we are using the 2D Array, but in 2D array, to access the elements we use indexing, for that we need integers, not Strings, for that each node we are giving another representation or name with integer 0,1,2,3,4
		//A->0,B->1,C->2,D->3,E->4
		
		
		System.out.println(graph.toString()); //here, we are trying to print the Graph class object graph,by using toString() , first toString() returns graph object address, we have to override it.
		
	}

}
