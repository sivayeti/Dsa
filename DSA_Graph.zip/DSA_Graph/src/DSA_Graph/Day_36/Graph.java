package DSA_Graph.Day_36;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Graph {
    //we already created the nodes, by using GraphNode data type class
	//Now we have to defines the edges among the nodes and generate a graph
	
	List<GraphNode> graphNodes; //graphNode = {A0,B1,C2,D3,E4} //TO STORE all the nodes which we created
	
	//we have to store edges between the nodes, for that we use 2D array
	int[][] adjacencyMatrix; //The size of 2D array depends on the no.of nodes , rows = no.of nodes, cols = no.of nodes (size of 2D array --> Nodes x Nodes)
	
	//Now by using  the constructor, we will set the prooerties
	public Graph(List<GraphNode> graphNodes) {
		this.graphNodes = graphNodes;
		this.adjacencyMatrix = new int[graphNodes.size()][graphNodes.size()]; //The size of 2D array depends on the no.of nodes , rows = no.of nodes, cols = no.of nodes.
		
	}
	
	//Now we have to define or give the connections between two nodes, for these we use a function
	public void addEdges(int i, int j) {
		adjacencyMatrix[i][j] = 1;
		adjacencyMatrix[j][i] = 1;
		
	}
	
	
	@Override
	public String toString() {  //These method is to print the adjacencyMatrix , which shows the edges relation among nodes in our graph.
		
		return "   "+ graphNodes.stream().map(e -> e.name).collect(Collectors.joining(" ")) + "\n" //if we apply the stream() on list, then one by one element from list will be retrieved, map() is used to the one by one element which is retrieved is concatened one by one and transforms into single string
	    + IntStream.range(0, adjacencyMatrix.length) //0,1,2,3,4 //IntStream, we used to create the indexes for nodes, based on the adjacencyMatrix length, which was defined by no.of nodes
	    .mapToObj(i -> graphNodes.get(i).name + " [" +Arrays.stream(adjacencyMatrix[i])   //After retrievieng the each index, we are transforming the each index into its name, by using get() in mapToObj().
	    //Array.stream(), is used to convert the array elements into single string ,  
	    .mapToObj(String::valueOf).collect(Collectors.joining(" ")) + "]\n").collect(Collectors.joining(""));
	}
	
	
}
