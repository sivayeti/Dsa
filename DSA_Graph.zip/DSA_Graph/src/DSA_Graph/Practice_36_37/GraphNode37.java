package DSA_Graph.Practice_36_37;

import java.util.ArrayList;
import java.util.List;

public class GraphNode37 {

	public String name;
	public int index;
	
	List<GraphNode37> neighbours = new ArrayList<GraphNode37>();
	
	public GraphNode37(String name, int index) {
		this.name = name;
		this.index = index;
	}
	
	//Lets use a function to store the all connected nodes of particular nodes in their respective neighbours list, in Graph37 class.
	
	
}
