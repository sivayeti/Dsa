package DSA_Graph.Practice_36_37;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Graph37 {

	List<GraphNode37> graphNodes;
	

	public Graph37(List<GraphNode37> graphNodes) {
		this.graphNodes = graphNodes;
	}
	
	
	public void addEdges(int i, int j) {
		//retrieve the first node, from i index in respective graph Node, then 
		GraphNode37 first = graphNodes.get(i);
		//retriev the second node from j index in respective graphNode, 
		GraphNode37 second = graphNodes.get(j);
		
		//Now add the second node in neighbour list of first node, and vice versa.(because, if A-B, A is neighbour to B, B is neighbour to A)
		first.neighbours.add(second);
		second.neighbours.add(first);
	}
	
	//Now we created our graph
	 @Override
	    public String toString() {
	    
	        return graphNodes.stream().map(g -> g.name + " : " + g.neighbours.stream().map(n -> n.name)
	        		.collect(Collectors.joining("->")) + "\n").collect(Collectors.joining(""));
	               //stream() will iterate over the each element in graphNodes List, and on that each element map() will take as argument and proccess function on it.
	    }
	
	 
	 
	public static void main(String[] args) {
		List<GraphNode37> nodes = new ArrayList<GraphNode37>();
		
		nodes.add(new GraphNode37("0", 0));
		nodes.add(new GraphNode37("1", 1));
		nodes.add(new GraphNode37("2", 2));
		nodes.add(new GraphNode37("3", 3));
		nodes.add(new GraphNode37("4", 4));
		nodes.add(new GraphNode37("5", 5));
		
		
		Graph37 g = new Graph37(nodes);
		
		g.addEdges(0, 1);
		g.addEdges(0, 3);
		g.addEdges(0, 5);
		g.addEdges(1, 2);
		g.addEdges(1, 3);
		g.addEdges(2, 3);
		g.addEdges(3, 4);
		g.addEdges(4, 5);
		//Now we created our graph
		
		//Lets print our graph
		
		System.out.println(g);
	}

}
