package DSA_Graph.Day_36_Practice;

public class GraphNode {

	public String name;
	public int index;
	public GraphNode(String name, int index) {
		this.name = name;
		this.index = index;
	}
	
	//Using these class, we will , create the nodes for graphs
}
