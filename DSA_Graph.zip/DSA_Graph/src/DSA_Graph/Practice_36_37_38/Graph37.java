package DSA_Graph.Practice_36_37_38;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Graph37 {

	List<GraphNode37> graphNodes;
	public Graph37(List<GraphNode37> graphNodes) {
		this.graphNodes = graphNodes;
	}
	
	public void addEdges(int i, int j) {
		GraphNode37 first = graphNodes.get(i);
		GraphNode37 second = graphNodes.get(j);
		
		first.neighbours.add(second);
		second.neighbours.add(first);
	}
	
	 @Override
	  public String toString() {
	    
	        return graphNodes.stream().map(g -> g.name + " : " + g.neighbours.stream().map(n -> n.name)
	        		.collect(Collectors.joining("->")) + "\n").collect(Collectors.joining(""));
	               //stream() will iterate over the each element in graphNodes List, and on that each element map() will take as argument and proccess function on it.
	    }
	 
	 
	public static void main(String[] args) {
		List<GraphNode37> graphNodes = new ArrayList<GraphNode37>();
		
		graphNodes.add(new GraphNode37("0", 0));
		graphNodes.add(new GraphNode37("1", 1));
		graphNodes.add(new GraphNode37("2", 2));
		graphNodes.add(new GraphNode37("3", 3));
		graphNodes.add(new GraphNode37("4", 4));
		graphNodes.add(new GraphNode37("5", 5));
		
		Graph37 g = new Graph37(graphNodes);
		
		g.addEdges(0, 1);
		g.addEdges(0, 3);
		g.addEdges(0, 5);
		g.addEdges(1, 2);
		g.addEdges(1, 3);
		g.addEdges(2, 3);
		g.addEdges(3, 4);
		g.addEdges(4, 5);
		
		System.out.println(g);
		
		
		
		//Day_38, Lets implement the dfs here
		Set<GraphNode37> visited = new HashSet<GraphNode37>();
		g.dfs(graphNodes.get(0), visited);
	}

	
	private void dfs(GraphNode37 node, Set<GraphNode37> visited) {
		if(visited.contains(node)) {
			return;
		}
		System.out.print(node.name + " ");
		visited.add(node);
		
		for(GraphNode37 neighbour: node.neighbours) {
			dfs(neighbour, visited);
		}
	}
}
