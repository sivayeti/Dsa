package DSA_Graph.Practice_36_37_38;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Graph36 {

	List<GraphNode36> graphNodes;
	
	int adjacencyMatrix[][];
	
	public Graph36(List<GraphNode36> graphNodes) {
		this.graphNodes = graphNodes;
		this.adjacencyMatrix = new int[graphNodes.size()][graphNodes.size()];
		
	}
	
	
	public void addEdges(int i, int j) {
		adjacencyMatrix[i][j] = 1;
		adjacencyMatrix[j][i] = 1;
	}
	
	
	@Override
	public String toString() {  //These method is to print the adjacencyMatrix , which shows the edges relation among nodes in our graph.
		return "   "+ graphNodes.stream().map(e -> e.name).collect(Collectors.joining(" ")) + "\n" //if we apply the stream() on list, then one by one element from list will be retrieved, map() is used to the one by one element which is retrieved is concatened one by one and transforms into single string
	    + IntStream.range(0, adjacencyMatrix.length) //0,1,2,3,4 //IntStream, we used to create the indexes for nodes, based on the adjacencyMatrix length, which was defined by no.of nodes
	    .mapToObj(i -> graphNodes.get(i).name + " [" +Arrays.stream(adjacencyMatrix[i])   //After retrievieng the each index, we are transforming the each index into its name, by using get() in mapToObj().
	    //Array.stream(), is used to convert the array elements into single string ,  
	    .mapToObj(String::valueOf).collect(Collectors.joining(" ")) + "]\n").collect(Collectors.joining(""));
	}
	
	
	
	public static void main(String[] args) {
		List<GraphNode36> graphNodes = new ArrayList<GraphNode36>();
		
		graphNodes.add(new GraphNode36("A", 0));
		graphNodes.add(new GraphNode36("B", 1));
		graphNodes.add(new GraphNode36("C", 2));
		graphNodes.add(new GraphNode36("D", 3));
		graphNodes.add(new GraphNode36("E", 4));
		
		
		Graph36 g = new Graph36(graphNodes);
		
		g.addEdges(0, 1);
		g.addEdges(0, 2);
		g.addEdges(0, 3);
		g.addEdges(1, 3);
		g.addEdges(1, 4);
		g.addEdges(2, 3);
		g.addEdges(3, 4);
		
		System.out.println(g);
	}
}
