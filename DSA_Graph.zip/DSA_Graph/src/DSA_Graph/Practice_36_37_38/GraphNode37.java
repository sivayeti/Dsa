package DSA_Graph.Practice_36_37_38;

import java.util.ArrayList;
import java.util.List;

public class GraphNode37 {

	public String name;
	public int index;
	
	List<GraphNode37> neighbours = new ArrayList<GraphNode37>();

	public GraphNode37(String name, int index) {
		this.name = name;
		this.index = index;
	}
	
	
}
