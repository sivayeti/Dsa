package DSA_Graph.Practice_36_37_38;

public class GraphNode36 {

	public String name;
	public int index;
	public GraphNode36(String name, int index) {
		this.name = name;
		this.index = index;
	}
}
