package Numbers;
import java.util.*;
public class Leapyear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		if( n % 400 == 0) {
			System.out.println("Leap year");
		}else if( n % 100 != 0 &&  n % 4 == 0) { //2100 //2012
			System.out.println("Leap year");
		}else {
			System.out.println("Not a leap year");
		}
		
	}

}

