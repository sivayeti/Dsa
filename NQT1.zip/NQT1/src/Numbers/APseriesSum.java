package Numbers;
import java.util.*;
public class APseriesSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int a = sc.nextInt();
		int d = sc.nextInt();
		int sum = 0;
		for(int i = 1; i <= n; i++) {
			sum = sum + a; //2 + 4 + 6 + 8
			a = a+d;
		}
			System.out.println(sum);
	}

}
