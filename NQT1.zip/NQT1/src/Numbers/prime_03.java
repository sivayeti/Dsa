package Numbers;
import java.util.*;

public class prime_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        boolean res = true;
        for(int i = 2; i <= n/2; i++) {
        	if(n%i == 0) {
        		System.out.println("It is not a prime");
        		res = false;
        		break;
        	}
        }
        
        if(res = true) {
        	System.out.println("It is a prime");
        }
	}

}
