package Numbers;
import java.util.*;

public class pali_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		int ans = 0;
		//n = 153
		int r = 0;
		int q = n;
		while(q>0) { //153>0 //15>0 //1>0 //0>0
			r = q % 10; //3 //5 //1
			q = q / 10; //15 //1 //0
			System.out.println(q+" " + r);
			ans = ans * 10 + r; //3 //30+5 //350+1
			
		}
		System.out.println(ans);
		if(n == ans) {
			System.out.println("Palindrome");
		}else {
			System.out.println("Not Palindrome");
		}
	}

}
