package Array;
import java.util.*;

public class sortArrbyoArr_24 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n1 = sc.nextInt();
	    int arr1[] = new int[n1];
	    for(int i = 0; i < n1; i++) {
	    	arr1[i] = sc.nextInt();
	    }
	    
	    int n2 = sc.nextInt();
	    int arr2[] = new int[n2];
	    for(int i =0; i < n2; i++) {
	    	arr2[i] = sc.nextInt();
	    }
	    
	    
	    HashMap<Integer,Integer> hm = new HashMap<>();
	    for(int i = 0; i < n1; i++) {
	    	if(hm.containsKey(arr1[i]) ) {
	    		int val = hm.get(arr1[i]);
	    		hm.put(arr1[i], val+1);
	    	}else {
	    		hm.put(arr1[i], 1);
	    	}
	    }
	    
	    ArrayList<Integer> a = new ArrayList<>();
	    //2nd array elements
	    for(int i = 0; i < n2; i++) {
	    	int val = hm.get(arr2[i]);
	    	for(int j = 0; j < val; j++) {
	    		a.add(arr2[i]);
	    	}
	    }
	    
	   

	    //execept 2nd array elements in hashmap adding to array list
	    for(Integer i : hm.keySet()) {
	    	if(!a.contains(i)) {
	    		int val = hm.get(i);
	    		for(int j = 0; j < val; j++) {
	    			a.add(i);
	    		}
	    		
	    	}
	    }
	    
	    System.out.println(a);
	}

}
