package Array;
import java.util.*;

public class Reverse_04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n =  sc.nextInt();
		int arr[] = new int[n];
		for(int i=0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		// 0 1 2 3 - index
		// 3 7 8 9 - old array
		// 9 8 7 3 - new array
		// 3 2 1 0
		int newarr[] = new int[n];
		for(int i = 0; i < n; i++) {
			newarr[i] = arr[n-1-i]; //end_value - index value.
		}
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.print(newarr[i]+" ");
		}
	}
	
}
