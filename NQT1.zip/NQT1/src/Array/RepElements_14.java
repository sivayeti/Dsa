package Array;
import java.util.*;

public class RepElements_14 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		ArrayList<Integer> repArr = new ArrayList<>();
		ArrayList<Integer> nonrepArr =  new ArrayList<>();
		
		for(int i = 0; i < arr.length; i++) {
			
			if(hm.containsKey(arr[i])) {
				int val = hm.get(arr[i]);
				hm.put(arr[i], val+1);
			}else {
				hm.put(arr[i], 1);
			}
		}
		
		
		for(Integer i: hm.keySet()) {
			if(hm.get(i) == 1) {
				nonrepArr.add(i);
			}else {
				repArr.add(i);
			}
		}
		
		System.out.println(nonrepArr);
		System.out.println(repArr);
		
	}
}
