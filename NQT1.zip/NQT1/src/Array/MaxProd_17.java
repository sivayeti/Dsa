package Array;
import java.util.*;

public class MaxProd_17 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		int maxi = Integer.MIN_VALUE;
		int maxip = 1;
		//Lets print all the sub arrays of array , sub array is continous one 
		for(int i = 0; i < n; i++) {
			for(int j = i; j < n; j++) {
				maxip = 1;
				//System.out.print("[");
				for(int k = i; k <= j; k++) {
					System.out.print(arr[k]+",");
					maxip = maxip * arr[k];
				}
				//System.out.print("]   ");
				//System.out.print("-" + maxip);
				if(maxip > maxi) {
					maxi = maxip;
				}
			}
			//System.out.println();
			
		}
		
		System.out.println(maxi);
	}
}
