package Array;
import java.util.*;

public class Rearrange_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		/*
		//Bubble sort - ascending order
		//How many sections we have to go, n-1 sections
		for(int i = 0; i < n-1; i++) {
			for(int j = 0; j < n-1-i; j++) {
				if(arr[j] > arr[j+1]) { //8>5
					int temp = arr[j]; //8
					arr[j] = arr[j+1]; //5
					arr[j+1] = temp; //8 => 5,8
				}
			}
		}
		
		
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		
		for(int i = 0; i < n-1; i++) {
			for(int j = 0; j < n-1-i; j++) {
				if(arr[j] < arr[j+1]) { //5 < 8
					int temp = arr[j]; //5
					arr[j] = arr[j+1]; //8
					arr[j+1] = temp; //5 => 8,5
				}
			}
		}
		System.out.println();
		
		//Descending order
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		*/
		
		Arrays.sort(arr); //o(nlogn) for sorting the array
		for(int i = 0; i < arr.length; i++) { //o(n) for printing the array elements
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		for(int i= n-1; i>=0; i--) {
			System.out.print(arr[i] + " ");
		}
		
		//Time complexity = o(nlogn) + o(n) + o(n) = o(nlogn) + o(2n) = o(nlogn) + o(n);
		//Space complexity = o(1)
	}
}
