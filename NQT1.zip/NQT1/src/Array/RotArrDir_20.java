package Array;
import java.util.*;

public class RotArrDir_20 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i <  n; i++) {
			arr[i] = sc.nextInt();
		}
		
		
		int k = sc.nextInt();
		String dir = sc.next();
		
		int n1arr[] = rotation(arr, k, dir);

		for(int i = 0; i < n1arr.length; i++) {
			System.out.print(n1arr[i] + " ");
		}
	}

	
	
	private static int[] rotation(int[] arr, int k, String dir) {
		int  narr[] = new int[arr.length];
		if(dir.equals("right")) {
			//int  narr[] = new int[arr.length];
			int z = 0;
			for(int i = arr.length-k; i < arr.length; i++) {
				narr[z] = arr[i];  //3 //4
				//0 //1
				z++; //1 //2
			}
			for(int i = 0; i < arr.length-k; i++) {
				narr[z] = arr[i];
				z++;
			}
			
			
		}else if(dir.equals("left")) {
			int z = 0;
			for(int i = k; i < arr.length; i++) {
				narr[z] = arr[i];
				z++;
			}
			
			for(int i = 0; i < k; i++) {
				narr[z] = arr[i];
				z++;
			}
			
		}
		
		return narr;
	}

}
