package Array;
import java.util.*;

public class SecSmallestSecLargest_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		//int maxi = arr[0]; //5 3 7 8 //maxi = 5
		int maxi = Integer.MIN_VALUE;
		for(int i = 0; i < arr.length; i++) {
			//maxi = Math.max(maxi, arr[i]);
			if(arr[i] > maxi) {
				maxi = arr[i];
			}
			
		}
		//maxi = 8
		
		int secMaxi = arr[0];
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] != maxi) { // 5,3,7
				secMaxi = Math.max(secMaxi, arr[i]);
			}
		}
		
		System.out.println(secMaxi);
		
		
		int mini = arr[0];
		for(int i = 0; i < arr.length; i++) {
			mini = Math.min(mini, arr[i]);
		}
		
		int secMini = arr[0];
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] != mini) {
				secMini = Math.min(arr[i], secMini);
			}
		}
		System.out.println(secMini);
	}
	
}
