package Array;
import java.util.*;

public class RemDupUSA_12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for(int i = 0; i < n; i++) {
			if(!a.contains(arr[i])) {
				a.add(arr[i]);
			}
		}
		int newarr[] = new int[a.size()];
		int k = 0;
		for(Integer i: a) {
			newarr[k] = i;
			k++;
		}
		
		for(int i = 0; i < newarr.length; i++) {
			System.out.println(newarr[i]+" ");
		}
		
	}
}
