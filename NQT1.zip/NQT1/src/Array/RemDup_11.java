package Array;
import java.util.*;

public class RemDup_11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		Arrays.sort(arr);
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for(int i = 0; i < arr.length; i++) {
			if(!a.contains(arr[i])) {
				a.add(arr[i]);
			}
		}
		
		
		for(Integer j: a) {
			System.out.println(j+" ");
		}
		
		
		System.out.println(a);
	}

}
