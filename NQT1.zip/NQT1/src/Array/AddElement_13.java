package Array;
import java.util.*;

public class AddElement_13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
			
		}

		int aB = sc.nextInt();
		int arr1[] = addElement(arr, aB);
		for(int i = 0; i  < arr1.length; i++) {
			System.out.print(arr1[i] + " ");
		}
		
		int aE = sc.nextInt();
		int arr2[] = addEnd(arr,aE);
		for(int i = 0; i < arr2.length; i++) {
			System.out.print(arr2[i]+ " ");
		}
		
		
		int aM = sc.nextInt();
		int m = sc.nextInt();
		int arr3[] = addMiddle(arr,aM, m );
		for(int i =0; i < arr3.length; i++) {
			System.out.print(arr3[i] + " ");
		}
	}

	private static int[] addMiddle(int[] arr, int aM, int m) {
	    int l = arr.length;
	    int newarr[] = new int[l+1];
	    int k = 0;
	    //for(int i = 0; i < m; i++) {
	    for(int i = 0; i < m-1; i++) {
	    	newarr[k] = arr[i]; //0, 1
	    	k++; //1
	    }
	    //newarr[m] = aM;
	    newarr[m-1] = aM;
	    k = k+1;
	    for(int i = m-1; i < arr.length; i++) {
	    	newarr[k] = arr[i]; //4,5
	    	k++; //4,5,6
	    	
	    }
		return newarr;
	}

	
	private static int[] addEnd(int[] arr, int aE) {
		int l = arr.length;
		int newarr[] = new int[l+1];
		newarr[newarr.length-1] = aE;
		int k = 0;
		for(int i = 0; i < arr.length; i++) {
			newarr[k] = arr[i];
			k++;
		}
		return newarr;
	}

	private static int[] addElement(int[] arr, int aB) {
		// TODO Auto-generated method stub
		int l = arr.length;
		int newarr[] = new int[l + 1];
		newarr[0] = aB;
		int k = 1;
		for(int i= 0; i < arr.length; i++) {
			newarr[k] = arr[i];
			k++;
		}
		return newarr;
	}

	
	
}
