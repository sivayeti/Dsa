package Array;
import java.util.*;

public class RotArray_08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		//0 1 2 3 4
		//1 2 3 4 5
		//K = 2
		//3 4 5 1 2
		//l = 5
		
		int k = sc.nextInt(); //2
		int z = k;
		int rarr[] = new int[k];
		for(int i = 0; i < k; i++) {
			rarr[i] = arr[i]; 
		}
		
		for(int i = 0; i < rarr.length; i++) {
			System.out.print(rarr[i]+ " ");
		}
		int l = arr.length;
		int larr[] = new int[l-k];
		int v = l-k;
		for(int j = 0; j < v; j++) {
			larr[j] = arr[k];
			k++;
			//k = 2, 2,3,4
			//k = 3, 3,4
			//k = 4, 4
		}
		System.out.println();
		for(int i = 0; i < larr.length; i++) {
			System.out.print(larr[i]+ " ");
		}
		
		int fin[] = new int[n];
		for(int i = 0; i < v; i++) {
			fin[i] = larr[i];
		}
		int a = 0;
		for(int i = z+1; i < n; i++) {
			fin[i] = rarr[a];
			a++;
		}
		
		System.out.println();
		for(int i = 0; i < fin.length; i++) {
			System.out.print(fin[i]+ " " );
		}
	}

}
