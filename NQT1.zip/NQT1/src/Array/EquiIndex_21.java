package Array;
import java.util.*;

public class EquiIndex_21 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		
		for(int i = 0; i < n; i++) {
			int rssum = rs(i, arr);
			int lssum = ls(i, arr);
			if(lssum == rssum) {
				System.out.println(i);
				System.out.println(arr[i]);
				break;
			}
		}
	}

	private static int ls(int i, int[] arr) {
		// TODO Auto-generated method stub
		int lssum = 0;
		if(i == 0) {
			lssum = 0;
		}else {
			for(int k = 0; k < i; k++) {
				lssum += arr[k];
			}
		}
		return lssum;
	}

	private static int rs(int i, int[] arr) {
		int rssum = 0;
		if(i == arr.length-1) {
			rssum = 0;
		}else {
			for(int k = i+1; k < arr.length; k++) {
			  rssum += arr[k];
			}
		}
		return rssum;
	}
}
