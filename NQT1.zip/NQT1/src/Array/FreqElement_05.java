package Array;
import java.util.*;

public class FreqElement_05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		//arr = [5,7,7,5,1]
		
		HashMap<Integer,Integer> hm = new HashMap<>();
		for(int i =0; i < arr.length; i++) {
			if(hm.containsKey(arr[i])) {
				int val = hm.get(arr[i]);
				hm.put(arr[i], val+1);
			}else {
				hm.put(arr[i], 1);
			}
		}
		
		System.out.println(hm);
	
		for(Integer i: hm.keySet()) {
			System.out.println(i+ " occurs " + hm.get(i) + " times");
		}
		
	}
}
