package Array;
import java.util.*;

public class Rank_18 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		int arr[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		
		int narr[] = new int[n];
		for(int i = 0; i < n; i++) {
			narr[i] = arr[i];
		}
		
		Arrays.sort(arr);
		HashMap<Integer,Integer> hm = new HashMap<>();
		
		for(int i = 0; i < arr.length; i++) {
			hm.put(arr[i], i+1);
		}
		
		
		int narr1[] = new int[n];
		for(int i = 0; i < n; i++) {
			narr1[i] = hm.get(narr[i]);
		}
		
		
		for(int i = 0; i < narr1.length; i++) {
		     System.out.print(narr1[i] + " ");
		}
	}
}
