package Array;
import java.util.*;
public class SymPairs_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int arr[][] = new int[n][m];
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < m; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		
        
		int res = 0;
		//ArrayList<Array> a = new ArrayList<>();
		for(int i = 0; i < n-1; i++) {
			for(int j = i+1; j < n; j++) {
		    if( (arr[i][0] ==  arr[j][1]  && arr[i][1] == arr[j][0]) || (arr[i][0] ==  arr[j][0]  && arr[i][1] == arr[j][1] )   ) {
		    	System.out.print("("+arr[j][0]+","+arr[j][1]+")" + " ");
		    }
			}
		}
		
		
	}

}
